var g_SteamInventories = {};
var g_OsiInventories = {};
var g_CurrentInventory = null;
var g_CurrentSellQueue = [];
var g_ListingInFlight = false;
var g_PriceWasSet = false;
var g_SellingFromOsi = false;
var g_DepositIntoOsiAddon = "deposit_into_osi";

function getInventoryCache() {
    return g_SellingFromOsi ? g_OsiInventories : g_SteamInventories;
}

function loadInventory(appid, contextid, urlParams) {
    if (getSellQueueLength() >= g_MaxItemsPerQueue) {
        return;
    }
    if (g_CurrentInventory && g_CurrentInventory.loading) {
        return;
    }
    var cache = getInventoryCache();
    var inv = cache[appid + '_' + contextid] || new Inventory(appid, contextid, g_SellingFromOsi, urlParams);
    cache[appid + '_' + contextid] = inv;
    inv.load();
    $('#nav-apps').find('.active').removeClass('active');
    $('#navpill-' + appid + '_' + contextid).addClass('active');
    localStorage.lastSellApp = appid + '_' + contextid;
}

function setSellFromOsi(sellFromOsi) {
    if (g_CurrentSellQueue.length != 0 || (g_CurrentInventory && g_CurrentInventory.loading)) {
        return;
    }
    g_SellingFromOsi = sellFromOsi;
    localStorage.sellFromOsi = sellFromOsi ? 1 : 0;
    if (g_CurrentInventory) {
        loadInventory(g_CurrentInventory.appid, g_CurrentInventory.contextid);
    }
    if (g_SellingFromOsi) {
        $('#set-sell-from-steam, #sell-osi, #deposit-btn-osi').show();
        $('#set-sell-from-osi, #sell-steam-inv, #addons-group, #deposit-btn-steam').hide();
    } else {
        $('#set-sell-from-steam, #sell-osi, #deposit-btn-osi').hide();
        $('#set-sell-from-osi, #sell-steam-inv, #addons-group, #deposit-btn-steam').show();
    }
}

function Inventory(appid, contextid, osi, urlParams) {
    this.appid = appid;
    this.contextid = contextid;
    this.osi = osi;
    this.loading = false;
    this.suggestedPrices = {};
    this.userEnteredPrices = {};
    this.inspectData = {};
    this.specialFees = {};
    if (urlParams !== undefined) {
        this.autoSelectCommodityItem = urlParams !== undefined;
        this.commodityName = urlParams.commodity_name;
    }
}
Inventory.prototype.load = function() {
    var self = this;
    this.resetSelected();
    if (this.loading) {
        return;
    }
    var $filter = $('#inv-filter');
    $filter.val("");
    if (this.items) {
        this.render();
        return;
    }
    $filter.prop('disabled', true);
    this.loading = true;
    this.fillContainer('<div style="font-size: 200px; text-align: center" class="text-muted"><i class="fa fa-refresh fa-spin"></i></div>');
    this.selectedItem = null;
    g_CurrentInventory = this;
    ajaxJsonRequest("GET", "/ajax/get_inventory.php", {
        "appid": this.appid,
        "contextid": this.contextid,
        "osi": this.osi ? 1 : 0
    }, function(errCode, msg, res) {
        self.loading = false;
        $filter.prop('disabled', false);
        if (errCode) {
            self.fillContainer('<div class="alert alert-warning">' + (msg || LANG.trans("sell.load_inv_error_code", {
                "code": errCode
            })) + '</div>');
            return;
        }
        self.items = res.items;
        self.descriptions = res.descriptions;
        self.items.forEach(function(item) {
            item = self.describeItem(item);
            if (self.appid == 440 && ["Refined Metal", "Tour of Duty Ticket", "Squad Surplus Voucher"].indexOf(item.market_name || item.name) != -1) {
                self.descriptions[item.classid + '_' + item.instanceid].commodity = 1;
            }
            if (self.appid == 295110 || self.appid == 433850) {
                self.descriptions[item.classid + '_' + item.instanceid].commodity = 1;
            }
        });
        self.filter();
        self.render();
    }, function() {
        self.loading = false;
        self.fillContainer('<div></div>');
    });
};
Inventory.prototype.fillContainer = function(html) {
    $('#inv-container').html();
};
Inventory.prototype.filter = function() {
    var appid = this.appid;
    var self = this;
    this.items = this.items.filter(function(item) {
        item = self.describeItem(item);
        if (appid == 440 && (item.market_name || item.market_hash_name || item.name).match(/((Scrap|Reclaimed) Metal|Mann Co\. Supply Crate Series)/)) {
            return false;
        }
        if (appid == 753 && item.market_hash_name == "753-Gems") {
            return false;
        }
        if (item.amount && item.amount > 1) {
            return false;
        }
        return true;
    });
};
Inventory.prototype.render = function() {
    g_CurrentInventory = this;
    var commodities = [];
    var items = [];
    var descriptions = this.descriptions;
    var commodityIndexes = {};
    var self = this;
    this.items.forEach(function(item, idx) {
        var key = item.classid + '_' + item.instanceid;
        if (!descriptions[key]) {
            return;
        }
        item = JSON.parse(JSON.stringify(item));
        item.invIndex = idx;
        for (var i in descriptions[key]) {
            if (descriptions[key].hasOwnProperty(i)) {
                item[i] = descriptions[key][i];
            }
        }
        if (item.commodity && (!localStorage.sellNoGroupCommodities || self.autoSelectCommodityItem)) {
            key = item.market_hash_name || item.market_name || item.name;
            if (typeof commodityIndexes[key] !== 'undefined') {
                commodities[commodityIndexes[key]].assetids.push(item.id || item.assetid);
            } else {
                item.assetids = [item.id || item.assetid];
                commodityIndexes[key] = commodities.push(item) - 1;
            }
        } else {
            items.push(item);
        }
    });
    this.fillContainer("");
    var $container = $('#inv-container');
    var self = this;
    
    $('#inv-filter').focus();
    $('input[name=toggle-percentage], #sell-auto-discount').change(function() {
        self.drawSuggestedPrice(self.getSelectedItem());
    });
    this.autoSelectCommodityItem && self.selectCommodityItem();
};
Inventory.prototype.selectCommodityItem = function(item) {
    $('#item-commodity-' + this.appid + '_' + this.contextid + '_' + this.commodityName).click();
};
Inventory.prototype.getQueueCommodityCount = function(item) {
    var count = 0;
    var appid = this.appid;
    var contextid = this.contextid;
    g_CurrentSellQueue.forEach(function(entry) {
        if (entry.appid == appid && entry.contextid == contextid && entry.name == (item.market_hash_name || item.market_name || item.name)) {
            count += (entry.quantity || 1);
        }
    });
    return count;
};
Inventory.prototype.getItemName = function(item, asObject, fullWear) {
    var name = (item.market_name || item.name).trim();
    var lang_name = (typeof item.lang_name != 'undefined') ? item.lang_name : name;
    var lang_match;
    var match;
    if (this.appid == 753) {
        match = name.match(/^(.*) \((Trading Card|Profile Background)\)$/);
        if (match) {
            lang_match = lang_name.match(/^(.*) \(.*\)$/);
            if (lang_match) {
                return asObject ? {
                    "name": lang_match[1]
                } : lang_match[1];
            }
            return asObject ? {
                "name": match[1]
            } : match[1];
        }
        match = name.match(/^(.*) \(Foil( Trading Card)?\)$/);
        if (match) {
            lang_match = lang_name.match(/^(.*) \(.*\)$/);
            if (lang_match) {
                return asObject ? {
                    "name": lang_match[1],
                    "wear": LANG.trans("wear_category.foil")
                } : lang_match[1];
            }
            return asObject ? {
                "name": match[1],
                "wear": LANG.trans("wear_category.foil")
            } : match[1];
        }
        return asObject ? {
            "name": lang_name
        } : lang_name;
    }
    if (this.appid == 440 || this.appid == 730) {
        match = name.match(/^(.*) \((Factory New|Minimal Wear|Field-Tested|Well-Worn|Battle-Scarred)\)$/);
        if (match) {
            lang_match = lang_name.match(/^(.*) \(.*\)$/);
            if (lang_match) {
                lang_name = lang_match[1];
            }
            var wear_index = match[2];
            if (wear_index.indexOf('-') != -1) {
                wear_index = wear_index.split('-');
            } else {
                wear_index = wear_index.split(' ');
            }
            wear_index = wear_index[0][0] + wear_index[1][0];
            if (!fullWear) {
                return asObject ? {
                    "name": lang_name,
                    "wear": LANG.trans('wear_category.short.' + wear_index.toLowerCase())
                } : lang_name;
            }
            return asObject ? {
                "name": lang_name,
                "wear": LANG.trans('wear_category.full.' + wear_index.toLowerCase())
            } : lang_name;
        }
        return asObject ? {
            "name": lang_name
        } : lang_name;
    }
    return asObject ? {
        "name": lang_name
    } : lang_name;
};
Inventory.prototype.isActive = function() {
    return this === g_CurrentInventory;
};
Inventory.prototype.resetSelected = function() {
    
    $('#sell-selected-type, #sell-selected-extrainfo, #sell-selected-stickers').text("");
    $('#sell-selected-img').attr('src', '/images/graphic-only-logo.png');
    $('.sell-selected-btn').hide();
    $('#sell-selected-suggestedprice').hide();
    $('#sell-form-submit').prop('disabled', true);
    $('.sell-item.selected').removeClass('selected');
};
Inventory.prototype.selectItem = function(invIndex) {
    g_PriceWasSet = false;
    this.selectedItem = invIndex;
    var item = this.getSelectedItem();
    var disp = this.getItemName(item, true, true);
    var imgWidth = $('#sell-selected-box').width();
    var self = this;
    if (imgWidth > 512) {
        imgWidth = 512;
    }
    $('#sell-selected-name').text(disp.name).css('color', '#' + (item.color || 'ddd'));
    $('#sell-selected-type').text((disp.wear || "") + " " + (item.lang_type || item.type || ""));
    $('#sell-selected-img').css('visibility', 'hidden').attr('src', this.getImageUrl(item.img, imgWidth)).css('maxWidth', imgWidth);
    $('#sell-form-submit').prop('disabled', false);
    $('#sell-selected-search-btn').attr('href', '/?loc=shop_search&app=' + this.appid + '_' + this.contextid + '&search_item=' + encodeURIComponent(item.market_name || item.name) + '&sort=lh&search_internal=1').show();
    var inspect = this.getInspectLink(item, item);
   
    var extraInfo = [];
    var customName = this.getCustomName(item);
    if (customName) {
        extraInfo.push('<i class="fa fa-tag"></i> "' + htmlspecialchars(customName) + '"');
    }
    if (this.appid == 440) {
        (item.descriptions || []).forEach(function(desc) {
            if (desc.match(/^в… Unusual Effect: /)) {
                extraInfo.push('<span style="color: #FFD700">' + desc.replace('в…', '<i class="fa fa-star"></i> ') + '</span>');
            }
        });
    }
    if (extraInfo.length > 0) {
        $('#sell-selected-extrainfo').html(extraInfo.join('<br />')).show();
    } else {
        $('#sell-selected-extrainfo').hide();
    }
    var $stickers = $('#sell-selected-stickers');
    $stickers.hide();
    if (this.appid == 730 && item.descriptions && !g_SellingFromOsi) {
        item.descriptions.forEach(function(desc) {
            if (desc.indexOf('title="Sticker Details"') != -1) {
                $stickers.html("");
                var $steamStickers = $(desc);
                var names = desc.match(/<br>Sticker: ([^<]+)<\/center>/)[1].split(', ');
                $steamStickers.find('img').each(function(idx) {
                    var $img = $('<img />');
                    $img.attr('src', this.src);
                    $img.attr('title', names[idx]);
                    $stickers.append($img);
                });
                $stickers.css('top', 15 + $('#sell-selected-name').height() + $('#sell-selected-type').height() + (extraInfo.length > 0 ? $('#sell-selected-extrainfo').height() : 0) + 'px');
                $stickers.show();
            }
        });
    }
    if (item.commodity && (!localStorage.sellNoGroupCommodities || this.autoSelectCommodityItem)) {
        var quantity = this.getMatchingCommodities(item).length;
        if (quantity == 1) {
            $('#sell-quantity').val(1);
            $('#sell-form-quantity-group').hide();
        } else {
            $('#sell-quantity').attr('max', Math.min(g_MaxItemsPerQueue, this.getMatchingCommodities(item).length - this.getQueueCommodityCount(item))).val(1);
            $('#sell-form-quantity-group').show();
        }
    } else {
        $('#sell-form-quantity-group').hide();
    }
    var canScreenshot = this.appid == 730 && g_NoScreenshotTypes.indexOf(item.type) == -1 && inspect;
    $('#sell-addons option[value=screenshot], #sell-addons option[value=ss_sc_bundle]').prop('disabled', !canScreenshot);
    $('#sell-addons').val("");
    if (self.appid == 730 && g_UseSFP && !self.specialFees.hasOwnProperty(disp.name)) {
        apiRequest("GET", "ISales", "GetSpecialFeePercentage", 1, {
            "appid": self.appid,
            "items": [disp.name]
        }, function(errCode, msg, res) {
            if (!errCode && res[disp.name] !== null) {
                self.specialFees[disp.name] = res[disp.name];
            }
        });
    }
    if (this.userEnteredPrices[item.market_hash_name || item.market_name || item.name]) {
        $('#sell-list-price').val(formatCoins(this.userEnteredPrices[item.market_name_name || item.market_name || item.name], true));
        calculateCommission();
        $('#sell-list-price').focus().select();
    } else {
        this.drawSuggestedPrice(item);
    }
    var $depositIntoOsi = $('#deposit-into-osi');
    if (!g_SellingFromOsi) {
        $depositIntoOsi.show();
        $depositIntoOsi.find('input').attr('checked', !!localStorage.depositIntoOsi);
    } else {
        $depositIntoOsi.hide();
    }
    checkDepositIntoOsi();
};
Inventory.prototype.getMatchingCommodities = function(item) {
    item = this.describeItem(item);
    if (localStorage.sellNoGroupCommodities) {
        return [item];
    }
    var itemName = item.market_hash_name || item.market_name || item.name;
    var self = this;
    return this.items.filter(function(invItem) {
        invItem = self.describeItem(invItem);
        return (invItem.market_hash_name || invItem.market_name || invItem.name) == itemName;
    });
};
Inventory.prototype.getSelectedItem = function() {
    var item = this.items[this.selectedItem];
    if (!item) {
        return null;
    }
    return this.describeItem(item);
};
Inventory.prototype.describeItem = function(item) {
    if (item.name) {
        return item;
    }
    item = JSON.parse(JSON.stringify(item));
    var desc = this.descriptions[item.classid + "_" + item.instanceid];
    if (!desc) {
        return null;
    }
    for (var i in desc) {
        if (desc.hasOwnProperty(i)) {
            item[i] = desc[i];
        }
    }
    return item;
};
Inventory.prototype.drawSuggestedPrice = function(item) {
    if (!this.isActive() || typeof this.selectedItem !== 'number' || item.id != this.getSelectedItem().id) {
        return;
    }
    var self = this;
    var $suggested = $('#sell-selected-suggestedprice');
    $suggested.hide();
    if (this.appid == 730) {
        $('#steam-analyst-price').show();
        $('#steam-market-price').hide();
    } else {
        $('#steam-analyst-price').hide();
        $('#steam-market-price').show();
    }
    var name = item.market_hash_name || item.market_name || item.name;
    if (typeof this.suggestedPrices[name] !== 'undefined') {
        display(this.suggestedPrices[name]);
        return;
    }
    apiRequest("GET", "IPricing", "GetSuggestedPrices", 1, {
        "appid": this.appid,
        "items": [name]
    }, function(errCode, msg, res) {
        if (errCode || !res) {
            return;
        }
        if (!res.prices || !res.prices[name]) {
            self.suggestedPrices[name] = null;
            display(null);
            return;
        }
        self.suggestedPrices[name] = res.prices[name];
        display(res.prices[name]);
    });

    function display(price) {
        $suggested.show();
        if (price === null) {
            $('#sell-selected-suggestedprice span').html('<em>none</em>');
            $('#sell-list-price').focus();
            return;
        }
        var $suggestedOpAverage = $('#suggested-op-average');
        $suggestedOpAverage.html(price.opskins_price ? formatCoins(price.opskins_price) : '<em>none</em>');
        $suggestedOpAverage.data('price', price.opskins_price || 0);
        var $suggestedOpLowest = $('#suggested-op-lowest');
        $suggestedOpLowest.html(price.opskins_lowest_price ? formatCoins(price.opskins_lowest_price) : '<em>none</em>');
        $suggestedOpLowest.data('price', price.opskins_lowest_price || 0);
        var $suggestedMarketOrAnalyst = $('#suggested-steam-market, #suggested-steam-analyst');
        $suggestedMarketOrAnalyst.html(price.market_price ? formatCoins(price.market_price) : '<em>none</em>');
        $suggestedMarketOrAnalyst.data('price', price.market_price || 0);
        var $sellListPrice = $('#sell-list-price');
        if ($sellListPrice.prop('disabled')) {
            return;
        }
        var autoPrice = (localStorage.sellUseLowestForSuggested ? price.opskins_lowest_price : price[g_PriceSuggestionType]) || price.opskins_price || price.market_price;
        if (!g_PriceWasSet && autoPrice) {
            var discountPct = $('#sell-auto-discount').val();
            var discountToggle = $('input[name=toggle-percentage]').filter(':checked').val();
            if (discountPct && discountPct > 0) {
                var pct = discountToggle > 0 ? (1 + (discountPct / 100)) : (1 - (discountPct / 100));
                autoPrice = Math.round(autoPrice * pct);
            }
            $sellListPrice.val(formatCoins(Math.min(g_MaximumPrice, Math.max(g_MinimumPrice, autoPrice)), true));
            calculateCommission();
            $sellListPrice.focus().select();
        }
    }
};
Inventory.prototype.getImageUrl = function(img, height) {
    return "https://steamcommunity-a.opskins.media/economy/image/" + img + "/" + height + "fx" + height + "f";
};
Inventory.prototype.getInspectLink = function(item, description) {
    if (!description) {
        description = this.descriptions[item.classid + '_' + item.instanceid];
    }
    if ([730, 440, 753].indexOf(this.appid) == -1) {
        return null;
    }
    if (!description.actions || description.actions.length == 0) {
        return null;
    }
    for (var i = 0; i < description.actions.length; i++) {
        if (description.actions[i].name.match(/(Inspect|View Full Size)/)) {
            return description.actions[i].link.replace('%assetid%', item.assetid || item.id);
        }
    }
    return null;
};
Inventory.prototype.getCustomName = function(description) {
    var match;
    if (this.appid == 440) {
        match = description.name.match(/^''(.*)''$/);
        if (match) {
            return match[1];
        }
        return null;
    }
    if (this.appid == 730) {
        for (var i = 0; i < (description.fraudwarnings || []).length; i++) {
            match = description.fraudwarnings[i].match(/^Name Tag: ''(.*)''$/);
            if (match) {
                return match[1];
            }
        }
        return null;
    }
    return null;
};
Inventory.prototype.getItemElementId = function(item, description) {
    if (!description) {
        description = this.descriptions[item.classid + '_' + item.instanceid];
    }
    if (description.commodity && (!localStorage.sellNoGroupCommodities || this.autoSelectCommodityItem)) {
        return 'item-commodity-' + this.appid + '_' + this.contextid + '_' + getCleanName(description.market_hash_name || description.market_name || description.name);
    } else {
        return 'item-' + this.appid + '_' + this.contextid + '_' + (item.assetid || item.id);
    }
};
$('#sell-location-form').submit(function() {
    var country = $('#country').val();
    var state = $('#state').val();
    var stateOther = $('#nostate').val();
    var noCanada = $('#country-no-canada').is(':checked') ? 1 : 0;
    if (!country || (!state && !stateOther)) {
        sendAlert('warning', LANG.trans("sell.fill_all_info"));
    }
    $.post('/ajax/account_options.php', {
        "type": "billing_options",
        "country": country,
        "region": state,
        "regionOther": stateOther,
        "no_canada": noCanada
    }, function(res) {
        if (res.indexOf('alert-success') != -1) {
            $('#sell-location-modal').addClass('fade').modal('hide');
            inventoryInit();
        } else {
            sendAlert(res);
        }
    }).fail(function() {
        sendAlert('danger', LANG.trans("sell.saving_error"));
    });
    return false;
});

function openSellPrefs() {
    $('#sell-prefs-group-commodities').prop('checked', !localStorage.sellNoGroupCommodities);
    $('#sell-prefs-autofill-lowest-price').prop('checked', !!localStorage.sellUseLowestForSuggested);
    $('#sell-prefs-modal').modal();
}
$('#sell-prefs-form').submit(function() {
    if ($('#sell-prefs-group-commodities').is(':checked')) {
        delete localStorage.sellNoGroupCommodities;
    } else {
        localStorage.sellNoGroupCommodities = 1;
    }
    if ($('#sell-prefs-autofill-lowest-price').is(':checked')) {
        localStorage.sellUseLowestForSuggested = 1;
    } else {
        delete localStorage.sellUseLowestForSuggested;
    }
    location.reload();
    return false;
});
$(document).ready(function() {
    $('#sell-selected-img').load(function() {
        var $this = $(this);
        setTimeout(function() {
            $this.css('visibility', 'visible');
        }, 10);
    }).error(function() {
        $(this).css('visibility', 'visible');
    });
    if (g_NumOsiItems == 0) {
        g_SellingFromOsi = false;
        $('#set-sell-from-osi, #set-sell-from-steam').hide();
    } else {
        setSellFromOsi(localStorage.sellFromOsi == 1);
    }
    if (typeof g_NeedsCountry === 'undefined' || !g_NeedsCountry) {
        inventoryInit();
    }
    $('#inv-filter').change(invFilter).keyup(invFilter);

    function invFilter() {
        if ($('#inv-container .alert').length > 0) {
            return;
        }
        var filter = this.value.toLowerCase();
        if (!filter) {
            $('.sell-item').show();
            return;
        }
        var descriptions = Object.keys(g_CurrentInventory.descriptions).filter(function(descId) {
            var desc = g_CurrentInventory.descriptions[descId];
            return checkMatch(desc.market_hash_name, filter) || checkMatch(desc.market_name, filter) || checkMatch(desc.name, filter) || checkMatch(desc.type, filter) || checkMatch(desc.descriptions || [], filter);
        });
        g_CurrentInventory.items.forEach(function(item) {
            if (descriptions.indexOf(item.classid + '_' + item.instanceid) == -1) {
                $('#' + g_CurrentInventory.getItemElementId(item)).hide();
            } else {
                $('#' + g_CurrentInventory.getItemElementId(item)).show();
            }
        });

        function checkMatch(str, filter) {
            if (str instanceof Array) {
                return str.some(function(item) {
                    return checkMatch(item, filter);
                });
            }
            return (typeof str === 'string' && str.toLowerCase().indexOf(filter) != -1);
        }
    }
    var prevListPrice, prevYourCut;
    $('#sell-list-price').on('change keyup', function() {
        g_PriceWasSet = true;
        if (parseFloat(this.value) == prevListPrice) {
            return;
        }
        prevListPrice = parseFloat(this.value);
        calculateCommission();
    });
    $('#sell-your-cut').on('change keyup', function() {
        if (parseFloat(this.value) == prevYourCut) {
            return;
        }
        prevYourCut = parseFloat(this.value);
        calculateCommission(true);
    });
    var $sellAddons = $('#sell-addons');
    $('#deposit-into-osi').find('input[type=checkbox]').change(checkDepositIntoOsi);
    $('#depositBtn').click(function() {
        if (g_ListingInFlight) {
            return;
        }
        if (g_CurrentSellQueue.length <= 0) {
            sendAlert('warning', LANG.trans("sell.no_items"));
            return;
        }
        var items = [];
        g_CurrentSellQueue.forEach(function(entry) {
            var addons = [];
            switch (entry.addon) {
                case 'private':
                    addons.push('private');
                    break;
                case 'featured':
                    addons.push('featured');
                    break;
                case 'screenshot':
                    addons.push('screenshots');
                    break;
                case 'ss_sc_bundle':
                    addons.push('featured_screenshots_bundle');
                    break;
                case g_DepositIntoOsiAddon:
                    addons.push(g_DepositIntoOsiAddon);
                    break;
            }
            if (entry.commodity) {
                var inv = getInventoryCache()[entry.appid + '_' + entry.contextid];
                inv.items.map(inv.describeItem.bind(inv)).filter(function(item) {
                    return (item.market_hash_name || item.market_name || item.name) == entry.name && !items.some(function(itm) {
                        return itm.assetid == item.id;
                    });
                }).slice(0, entry.quantity || 1).forEach(function(item) {
                    items.push({
                        "appid": entry.appid,
                        "contextid": entry.contextid,
                        "assetid": item.id,
                        "price": entry.price,
                        "addons": addons
                    });
                });
            } else {
                items.push({
                    "appid": entry.appid,
                    "contextid": entry.contextid,
                    "assetid": entry.assetid,
                    "price": entry.price,
                    "addons": addons
                });
            }
        });
        var $depositBtn = $('#depositBtn');
        var $queueSpinner = $('#queue-spinner');
        var $queueContainer = $('#queue-container');
        $depositBtn.prop('disabled', true);
        $queueSpinner.html('<i class="fa fa-refresh fa-spin"></i>');
        $queueSpinner.show();
        $queueContainer.hide();
        g_ListingInFlight = true;
        if (g_SellingFromOsi) {
            var $progress = $('<div class="progress" />');
            var $progressBar = $('<div class="progress-bar" role="progressbar" style="width:0" />');
            $progress.append($progressBar);
            $queueSpinner.html('<div class="alert alert-info">' + LANG.trans('sell.osi_relist.wait') + '</div>');
            $queueSpinner.append($progress);
            var originalItems = JSON.parse(JSON.stringify(items));
            var doneItems = 0;
            var failures = 0;
            setRequestInFlight(true);
            listItem();

            function listItem() {
                if (items.length == 0) {
                    setRequestInFlight(false);
                    g_ListingInFlight = false;
                    var $alert = $queueSpinner.find('.alert.alert-info');
                    $alert.removeClass('alert-info');
                    if (failures == 0) {
                        $alert.addClass('alert-success').text(LANG.trans('sell.osi_relist.success'));
                    } else if (failures == originalItems.length) {
                        $alert.addClass('alert-danger').text(LANG.trans('sell.osi_relist.all_errors'));
                    } else {
                        $alert.addClass('alert-danger').text(LANG.trans('sell.osi_relist.some_errors'));
                    }
                    g_ShowcaseCredits = getFreeShowcases();
                    g_CurrentSellQueue = [];
                    getSellQueueLength();
                    originalItems.forEach(function(item) {
                        var inv = getInventoryCache()[item.appid + '_' + item.contextid];
                        for (var i = 0; i < inv.items.length; i++) {
                            if (inv.items[i].id == item.assetid) {
                                inv.items.splice(i, 1);
                                i--;
                            }
                        }
                    });
                    g_CurrentInventory.render();
                    $queueContainer.html("");
                    $queueContainer.show();
                    return;
                }
                var item = items.splice(0, 1)[0];
                apiRequest("POST", "ISales", "EditPrice", 1, {
                    "saleid": item.assetid,
                    "price": item.price
                }, function(errCode, msg, res) {
                    $progressBar.css('width', ((++doneItems / originalItems.length) * 100) + "%");
                    if (errCode) {
                        appendError(item, msg || LANG.trans('error_occurred_code', {
                            "code": errCode
                        }));
                        failures++;
                    }
                    setTimeout(listItem, 250);
                });
            }

            function appendError(item, msg) {
                var $error = $('<div class="alert alert-warning" />');
                item = getItemNameByAssetID(item.appid, item.contextid, item.assetid);
                if (item) {
                    $error.html('<strong />');
                    $error.find('strong').text(item).append(': ');
                }
                $error.append(msg);
                $queueSpinner.append($error);
            }
        } else {
            apiRequest("POST", "ISales", "ListItems", 1, {
                "items": JSON.stringify(items)
            }, function(errCode, msg, res) {
                g_ListingInFlight = false;
                if (errCode) {
                    $depositBtn.prop('disabled', false);
                    $queueSpinner.hide();
                    $queueContainer.show();
                    sendAlert('warning', (msg || LANG.trans("sell.error_code", {
                        "code": errCode
                    })));
                    return;
                }
                if (res.tradeoffer_error) {
                    $depositBtn.prop('disabled', false);
                    $queueSpinner.hide();
                    $queueContainer.show();
                    sendAlert('warning', res.tradeoffer_error);
                    return;
                }
                g_ShowcaseCredits = getFreeShowcases();
                g_CurrentSellQueue = [];
                items.forEach(function(item) {
                    var inv = getInventoryCache()[item.appid + '_' + item.contextid];
                    for (var i = 0; i < inv.items.length; i++) {
                        if (inv.items[i].id == item.assetid) {
                            inv.items.splice(i, 1);
                            i--;
                        }
                    }
                });
                g_CurrentInventory.render();
                var $invFilter = $('#inv-filter');
                if ($invFilter.val().length > 0) {
                    $invFilter.change();
                }
                var paddedBotId = res.bot_id.toString();
                while (paddedBotId.length < 4) {
                    paddedBotId = '0' + paddedBotId;
                }
                var botLink = '<a href="https://steamcommunity.com/profiles/' + res.bot_id64 + '" class="alert-link">' + LANG.trans('sell.list_success.storage_acc', {
                    "id": paddedBotId
                }) + '</a>';
                $queueSpinner.html('<div class="alert alert-success" id="sale-success-' + res.tradeoffer_id + '">' + '<p>' + LANG.trans("sell.list_success.sale_assigned", {
                        "account_link": botLink
                    }) + '</p>' + '<p><strong>' + LANG.trans("sell.list_success.security_token", {
                        "token": res.security_token
                    }) + '</strong></p>' +
                    res.offer_link + '<p class="text-muted">' + LANG.trans("sell.list_success.next_steps") + '</p>' + '<p class="text-muted">' + LANG.trans("sell.list_success.cancel_info") + '</p>' + '</div>');
                $queueContainer.html("");
                $queueContainer.show();
                Notifier.addEventListener("tradeoffer", listener);

                function listener(msg) {
                    if (msg.offerid != res.tradeoffer_id) {
                        return;
                    }
                    console.log("Offer #" + msg.offerid + " state is now " + msg.state);
                    $('#sale-success-' + res.tradeoffer_id).slideUp();
                    Notifier.removeEventListener("tradeoffer", listener);
                }
            }, function() {
                g_ListingInFlight = false;
                $depositBtn.prop('disabled', false);
                $queueSpinner.hide();
                $queueContainer.show();
            });
        }
    });
    $('#set-item-price').submit(function() {
        var addon = $sellAddons.val();
        var $depositIntoOsi = $('#deposit-into-osi');
        var depositIntoOsi = false;
        if ($depositIntoOsi.is(':visible') && $depositIntoOsi.find('input[type=checkbox]').prop('checked')) {
            depositIntoOsi = $depositIntoOsi.find('input[type=checkbox]').prop('checked');
            addon = g_DepositIntoOsiAddon;
        }
        var price = Math.round($('#sell-list-price').val() * 100);
        if (depositIntoOsi) {
            price = g_MaximumPrice;
        }
        if (isNaN(price)) {
            sendAlert('warning', LANG.trans("sell.invalid_price"));
            return false;
        }
        if (price < g_MinimumPrice || price > g_MaximumPrice) {
            sendAlert('warning', LANG.trans("sell.price_between", {
                "min": formatCoins(g_MinimumPrice),
                "max": formatCoins(g_MaximumPrice)
            }));
            return false;
        }
        var suggestedOpAveragePrice = $('#suggested-op-average').data('price');
        var suggestedOpLowestPrice = $('#suggested-op-lowest').data('price');
        var suggestedMarketPrice = $('#suggested-steam-market').data('price');
        var suggestedSteamAnalystPrice = $('#suggested-steam-analyst').data('price');
        var minSuggestedPrice = Math.min.apply(null, [suggestedOpAveragePrice, suggestedOpLowestPrice, suggestedMarketPrice, suggestedSteamAnalystPrice].filter(Boolean));
        if (minSuggestedPrice > 1000 && price < minSuggestedPrice && (minSuggestedPrice - price) / minSuggestedPrice >= 0.8 &&
            !confirm(LANG.trans("sell.underpriced_item"))) {
            return false;
        }
        var $invItem = $('.sell-item.selected');
        var invItemId = $invItem.attr('id');
        var item = g_CurrentInventory.getSelectedItem();
        var $queueItem = $invItem.clone();
        $queueItem.removeAttr('id');
        var queueSize = getSellQueueLength();
        var queueEntryId = Date.now().toString() + (Math.random() * 100000000).toString();
        if ($invItem.hasClass('sell-form-commodity')) {
            var quantity = parseInt($('#sell-quantity').val() || 1, 10);
            if (queueSize + quantity > g_MaxItemsPerQueue) {
                var lang_poly = ((g_MaxItemsPerQueue - queueSize) == 1) ? "one" : "many";
                sendAlert('warning', LANG.trans("sell.items_between." + lang_poly, {
                    "free_space": (g_MaxItemsPerQueue - queueSize)
                }));
                return false;
            }
            g_CurrentSellQueue.push({
                "entryId": queueEntryId,
                "commodity": true,
                "appid": g_CurrentInventory.appid,
                "contextid": g_CurrentInventory.contextid,
                "name": $invItem.data('commodity-name'),
                "quantity": quantity,
                "price": price,
                "addon": addon || null
            });
            queueSize += quantity;
            $queueItem.find('.sell-commodity-quantity').html('&times;' + quantity);
            var commodityMaxQuantity = $invItem.data('commodity-max-quantity');
            updateCommodityInventoryItem();
        } else {
            g_CurrentSellQueue.push({
                "entryId": queueEntryId,
                "commodity": false,
                "appid": g_CurrentInventory.appid,
                "contextid": g_CurrentInventory.contextid,
                "assetid": item.id,
                "name": item.market_hash_name || item.market_name || item.name,
                "price": price,
                "addon": addon || null
            });
            queueSize++;
            $invItem.hide();
        }
        g_CurrentInventory.userEnteredPrices[item.market_hash_name || item.market_name || item.name] = price;
        $queueItem.removeClass('selected');
        $queueItem.append('<div class="sell-queue-remove">' + LANG.trans("sell.remove") + '</div>');
        getSellQueueLength();
        if (!depositIntoOsi) {
            $queueItem.append('<div class="sell-queue-price">' + formatCoins(price) + '</div>');
        }
        var commodity = $invItem.hasClass('sell-form-commodity');
        $queueItem.click(function() {
            $queueItem.remove();
            for (var i = 0; i < g_CurrentSellQueue.length; i++) {
                if (g_CurrentSellQueue[i].entryId == queueEntryId) {
                    g_CurrentSellQueue.splice(i, 1);
                    break;
                }
            }
            checkSellBtn();
            calculateTotalAddonPrices();
            if (!commodity) {
                $('#' + invItemId).show();
            } else {
                updateCommodityInventoryItem();
            }
            $('#queue-count').text(getSellQueueLength());
            $('#queue-total').text(formatCoins(getSellQueueTotalPrice()));
            if ($('#inv-container .alert').length > 0) {
                g_CurrentInventory.render();
            }
        });
        var $container = $('#queue-container');
        $container.find('.alert').remove();
        $container.append($queueItem);
        switch (addon) {
            case 'private':
                $queueItem.append('<div class="sell-queue-addon-icon"><i class="fa fa-eye-slash" title="' + LANG.trans("sell.private_listing") + '"></i></div>');
                break;
            case 'featured':
                $queueItem.append('<div class="sell-queue-addon-icon"><i class="fa fa-thumb-tack" title="' + LANG.trans("sell.featured_listing") + '"></i></div>');
                break;
            case 'screenshot':
                $queueItem.append('<div class="sell-queue-addon-icon"><i class="fa fa-crosshairs" title="Instant Field Inspection&trade;"></i></div>');
                break;
            case 'ss_sc_bundle':
                $queueItem.append('<div class="sell-queue-addon-icon"><i class="fa fa-thumb-tack" title="' + LANG.trans("sell.featured_listing") + '"></i><br /><i class="fa fa-crosshairs" title="Instant Field Inspection&trade;"></i></div>');
                break;
            case g_DepositIntoOsiAddon:
                $queueItem.append('<div class="sell-queue-addon-icon"><i class="fa fa-suitcase" title="' + LANG.trans("sell.deposit_into_osi") + '"></i></div>');
                break;
        }
        $('#queue-count').text(queueSize);
        $('#queue-total').text(formatCoins(getSellQueueTotalPrice()));
        g_CurrentInventory.resetSelected();
        if (queueSize >= g_MaxItemsPerQueue) {
            g_CurrentInventory.fillContainer('<div class="alert alert-warning"><i class="fa fa-exclamation-triangle"></i> ' + LANG.trans("sell.sale_full") + '</div>');
        }
        checkSellBtn();
        calculateTotalAddonPrices();
        return false;

        function updateCommodityInventoryItem() {
            var $commodityItem = $('#' + invItemId);
            var remainingQuantity = commodityMaxQuantity - g_CurrentInventory.getQueueCommodityCount(item);
            $commodityItem.find('.sell-commodity-quantity').html('&times;' + remainingQuantity);
            if (remainingQuantity < 1) {
                $commodityItem.hide();
            } else {
                $commodityItem.show();
            }
        }

        function calculateTotalAddonPrices() {
            var total = 0;
            var showcaseCredits = g_ShowcaseCredits;
            g_CurrentSellQueue.forEach(function(item) {
                if (!item.addon) {
                    return;
                }
                var prices = calculateAddonPrices(item.price);
                switch (item.addon) {
                    case 'featured':
                    case 'private':
                        var quantity = (item.quantity || 1);
                        var chargeAmt = quantity - showcaseCredits;
                        var freeAmt = quantity - chargeAmt;
                        total += g_ShowcasePrice * chargeAmt;
                        showcaseCredits = Math.max(showcaseCredits - freeAmt, 0);
                        break;
                    case 'screenshot':
                        total += prices.screenshot * (item.quantity || 1);
                        break;
                    case 'ss_sc_bundle':
                        total += prices.ss_sc_bundle * (item.quantity || 1);
                        break;
                }
            });
            if (total == 0) {
                $('#depositBtnDueAmt').text("");
            } else {
                $('#depositBtnDueAmt').text(" (" + formatCoins(total) + " " + LANG.trans("sell.due_on_deposit") + ")");
                if (total > g_MyCoins) {
                    $('#depositBtn').attr('disabled', true);
                    $('#notEnoughFunds').fadeIn();
                } else {
                    $('#depositBtn').attr('disabled', false);
                    $('#notEnoughFunds').fadeOut();
                }
            }
        }
    });
});

function checkSellBtn() {
    $('#depositBtn').prop('disabled', g_CurrentSellQueue.length == 0);
}

function getFreeShowcases() {
    if (g_ShowcaseCredits <= 0) {
        return 0;
    }
    var amount = g_ShowcaseCredits;
    g_CurrentSellQueue.forEach(function(item) {
        if (item.addon == 'featured') {
            amount -= (item.quantity || 1);
        }
    });
    return Math.max(amount, 0);
}

function getItemNameByAssetID(appID, contextID, assetID) {
    var inv = getInventoryCache()[appID + '_' + contextID];
    if (!inv) {
        return null;
    }
    var item;
    for (var i = 0; i < inv.items.length; i++) {
        if (inv.items[i].id == assetID) {
            item = inv.items[i];
            break;
        }
    }
    if (!item) {
        return null;
    }
    return inv.getItemName(inv.describeItem(item));
}

function inventoryInit() {
    var app;
    var hasUrlAppId = getURLParameter('app') !== null;
    if (hasUrlAppId) {
        var urlApp = getURLParameter('app').split('_');
        var urlCommodityName = getURLParameter('n');
        var urlAppid = urlApp[0] || null;
        var urlContext = urlApp[1] || null;
    }
    if (hasUrlAppId) {
        loadInventory(urlAppid, urlContext, {
            commodity_name: urlCommodityName
        });
    } else if (localStorage.lastSellApp) {
        app = localStorage.lastSellApp.split('_');
        loadInventory(parseInt(app[0], 10), parseInt(app[1], 10));
    } else {
        app = getSelectedApp();
        loadInventory(app.appid, app.contextid);
    }
}

function getCleanName(name) {
    return btoa(encodeURIComponent(name)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

function htmlspecialchars(str) {
    return $('<div />').text(str).html();
}

function getSellQueueLength() {
    var quantity = 0;
    g_CurrentSellQueue.forEach(function(item) {
        quantity += item.quantity || 1;
    });
    if (quantity > 0 || g_NumOsiItems == 0) {
        $('#set-sell-from-osi, #set-sell-from-steam').hide();
    } else if (g_SellingFromOsi) {
        $('#set-sell-from-steam').show();
    } else {
        $('#set-sell-from-osi').show();
    }
    return quantity;
}

function getSellQueueTotalPrice() {
    var price = 0;
    g_CurrentSellQueue.forEach(function(item) {
        if (item.addon == g_DepositIntoOsiAddon) {
            return;
        }
        price += item.price * (item.quantity || 1);
    });
    return price;
}

function calculateCommission(fromUserCut) {
    var $listPrice = $('#sell-list-price');
    var $ourCut = $('#sell-our-cut');
    var $yourCut = $('#sell-your-cut');
    var listPrice, commission, userCut;
    var commissionPct = g_CommissionPct[g_CurrentInventory.appid];
    if (g_CurrentInventory.specialFees.hasOwnProperty($('#sell-selected-name').html())) {
        commissionPct = g_CurrentInventory.specialFees[$('#sell-selected-name').html()];
    }
    if (fromUserCut) {
        userCut = $yourCut.val();
        if (isNaN(parseFloat(userCut))) {
            return;
        }
        userCut = Math.round(userCut * 100);
        listPrice = Math.round(userCut / (1 - (commissionPct / 100)));
        if (userCut == listPrice) {
            listPrice++;
        }
    } else {
        listPrice = $listPrice.val();
        if (isNaN(parseFloat(listPrice))) {
            return;
        }
        listPrice = Math.round(listPrice * 100);
    }
    commission = Math.max(commissionPct == 0 ? 0 : 1, Math.round(listPrice * (commissionPct / 100)));
    userCut = listPrice - commission;
    $ourCut.val(formatCoins(commission) + " - " + commissionPct + "%");
    if (parseFloat($listPrice.val()) != parseFloat(formatCoins(listPrice, true))) {
        $listPrice.val(formatCoins(listPrice, true));
    }
    if (parseFloat($yourCut.val()) != parseFloat(formatCoins(userCut, true))) {
        $yourCut.val(formatCoins(userCut, true));
    }
    var $private = $('#sell-addons option[value=private]');
    var $featured = $('#sell-addons option[value=featured]');
    var $screenshot = $('#sell-addons option[value=screenshot]');
    var $ssScBundle = $('#sell-addons option[value=ss_sc_bundle]');
    var prices = calculateAddonPrices(listPrice);
    $private.html("(" + (getFreeShowcases() > 0 ? getFreeShowcases() + (" " + LANG.trans("sell.free_showcases")) : formatCoins(prices.showcase)) + ")" + $private.html().split(')').slice(1).join(')'));
    $featured.html("(" + (getFreeShowcases() > 0 ? getFreeShowcases() + (" " + LANG.trans("sell.free_showcases")) : formatCoins(prices.showcase)) + ")" + $featured.html().split(')').slice(1).join(')'));
    $screenshot.html("(" + formatCoins(prices.screenshot) + ")" + $screenshot.html().split(')').slice(1).join(')'));
    $ssScBundle.html("(" + formatCoins(prices.ss_sc_bundle) + ")" + $ssScBundle.html().split(')').slice(1).join(')'));
}

function calculateAddonPrices(listPrice) {
    var screenshotPrice = Math.min(Math.max(g_ScreenshotPriceMin, Math.round(listPrice * (g_ScreenshotPricePct / 100))), g_ScreenshotPriceMax);
    return {
        "showcase": getFreeShowcases() > 0 ? 0 : g_ShowcasePrice,
        "screenshot": screenshotPrice,
        "ss_sc_bundle": Math.min(g_ShowcaseScreenshotBundlePrice, g_ShowcasePrice + screenshotPrice)
    };
}

function checkDepositIntoOsi() {
    if ($('#deposit-into-osi').find('input[type=checkbox]').prop('checked')) {
        $('#sell-list-price, #sell-our-cut, #sell-your-cut, #sell-addons').prop('disabled', true).val("").attr('placeholder', LANG.trans('sell.price_later'));
        localStorage.depositIntoOsi = 1;
    } else {
        $('#sell-list-price, #sell-our-cut, #sell-your-cut, #sell-addons').prop('disabled', false).attr('placeholder', '');
        delete localStorage.depositIntoOsi;
    }
}

function displayWear(wear) {
    var msg = LANG.trans('sell.wear', {
        "pct": Math.round(wear * 1000000) / 10000,
        "raw": Math.round(wear * 100000000) / 100000000
    });
    $('#sell-selected-type').append('<br /><span title="' + wear + '">' + msg + '</span>');
}