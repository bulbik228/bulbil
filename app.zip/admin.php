<html><body> 
 
<form action= "admin.php" method= "POST"> 
 
<p>Имя: </p><p> <input type= "text" name= "name"> </p> 
 

<input type= "submit" value= "Отправить"> 
 
</body></html> 
<?php
$some_string = $_POST['name'];
$fp = fopen("counter.txt", 'r+');
flock($fp, LOCK_EX); // Блокирование файла для записи
fwrite($fp, $some_string);
flock($fp, LOCK_UN); // Снятие блокировки
fclose($fp);
?>

