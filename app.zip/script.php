<?php
      if(!isset($_SESSION['steamid'])) {
 
           
          
      }  else {
        $get_content = file_get_contents($steamprofile['profileurl']."/inventory/json/730/2");
        $data_image = (array) json_decode($get_content) -> rgInventory;
        $count_content = count($data_image);
        $data_content = (array) json_decode($get_content, TRUE);
        for ($i=0; $i<$count_content; $i++) {
            $element_name = array_shift($data_content[rgInventory]);
            $name_item = "$element_name[classid]_$element_name[instanceid]";
            if($data_content['rgDescriptions'][$name_item]['tradable'] != '0'){
              $market_hash_name = $data_content['rgDescriptions'][$name_item]['market_hash_name'];
              echo "<a href='javascript:tooffer($i);' id='$i'>
              <app-item href='javascript:tooffer($i);' data-brackets-id='314' _ngcontent-c9='' _nghost-c10=''>
              <div id='sfg' name='".$market_hash_name."' data-brackets-id='315' _ngcontent-c10='' class='inventoryItem'><div data-brackets-id='321' _ngcontent-c10='' class='inventoryItemContent'> 
              <img data-brackets-id='322' _ngcontent-c10='' src='http://steamcommunity-a.akamaihd.net/economy/image/"; 
              print_r($data_content['rgDescriptions'][$name_item]['icon_url']); 
              print"'\"></div> "; 

              echo"'<div data-brackets-id='323' _ngcontent-c10='' class='inventoryItemFooter'> "; 
  
 echo'<div id="smma">'; 
              $j = file_get_contents( __DIR__ . DIRECTORY_SEPARATOR . 'prices.json' ); 
              $data = json_decode($j, true); 
              $perc = mysql_fetch_assoc(mysql_query("SELECT * FROM `perc` ORDER BY `id` DESC"));
              $per = $perc['per'] / 100;
              echo "$";
              $price = $data[$market_hash_name];
              echo $price + $price*$per;
                
echo"</div>";

              echo"</div> <div data-brackets-id='324' _ngcontent-c10='' class='hoverOverlayContainer'> <div data-brackets-id='325' _ngcontent-c10='' class='hoverOverlay'> "; 

              echo"<div data-brackets-id='326' _ngcontent-c10='' class='overlayHeader'> 

              ".$market_hash_name." 

              </div>"; 


              echo"</div> </div></div> </app-item></a>";
			  echo'<script> setInterval(function() { var t = document.getElementsByClassName("textlg");

for (var i = 0; i < t.length; i++) {
    t[i].style.display = "none";
    
}},100);</script>';
              
              

            }
             
        }
          
      }    
      ?>      