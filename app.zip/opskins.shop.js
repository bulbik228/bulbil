var ErrorCode = {
    "OK": 1,
    "GENERIC_USER_ACCOUNT_ERROR": 1000,
    "NOT_ENOUGH_COINS": 1001,
    "ACCESS_DENIED": 1002,
    "NOT_LOGGED_IN": 1003,
    "LISTING_LIMIT_EXCEEDED": 1004,
    "NEEDS_TWOFACTOR": 1005,
    "INVALID_PASSWORD": 1006,
    "PASSWORD_UNSET": 1007,
    "TOO_MANY_PASSWORD_ATTEMPTS": 1008,
    "UNACCEPTABLE_PASSWORD": 1009,
    "TWOFACTOR_INCORRECT": 1010,
    "USERNAME_TAKEN": 1011,
    "UNACCEPTABLE_USERNAME": 1012,
    "EMAIL_UNVERIFIED": 1013,
    "NO_MORE_FREE_USES": 1014,
    "UNACCEPTABLE_EMAIL": 1015,
    "NOT_ALLOWED_IN_COUNTRY": 1016,
    "NEEDS_EMAIL_CODE": 1017,
    "EMAIL_UNSET": 1018,
    "WHITELIST_REQUIRED": 1019,
    "NEEDS_PHONE_CODE": 1020,
    "TRADE_URL_UNSET": 1021,
    "INVENTORY_FULL": 1022,
    "ACCOUNT_NOT_SETUP": 1023,
    "GENERIC_INTERNAL_ERROR": 2000,
    "DATABASE_ERROR": 2001,
    "NOT_FOUND": 2002,
    "BAD_STATE": 2003,
    "NO_MATCHING_ITEMS_FOUND": 2004,
    "BOT_UNAVAILABLE": 2005,
    "PAYMENT_GATEWAY_UNAVAILABLE": 2006,
    "CANNOT_CREATE_DIRECTORY": 2007,
    "FILE_UPLOAD_ERROR": 2008,
    "FILE_UPLOAD_ALREADY_EXISTS": 2009,
    "CANNOT_DELETE_FILE": 2010,
    "BOT_FULL": 2011,
    "ALREADY_IN_THAT_STATE": 2012,
    "LOCKED": 2013,
    "PRICE_HAS_CHANGED": 2014,
    "ENCRYPTION_KEY_INVALID": 2015,
    "DISABLED": 2016,
    "MALFORMED_RESPONSE": 2017,
    "EXPIRED": 2018,
    "BAD_INPUT": 3000,
    "UNACCEPTABLE_ITEM": 3001,
    "DUPLICATE_ITEM": 3002,
    "UNACCEPTABLE_PRICE": 3003,
    "DIFFERENT_BOTS_NOT_ALLOWED": 3004,
    "BAD_REQUEST": 3005,
    "TOO_MANY_REDEMPTIONS": 3006,
    "CAPTCHA_INVALID": 3007,
    "RATE_LIMIT_EXCEEDED": 3008,
    "NOT_PURCHASABLE": 3009,
    "EMPTY_CART": 3010,
    "BUYERS_CLUB_ONLY": 3011,
    "MISSING_DEPENDENCY": 3012,
    "CART_TOTAL_CHANGED": 3013,
    "REQUEST_OR_FILE_TOO_LARGE": 3014,
    "UNACCEPTABLE_FILE_TYPE": 3015,
    "SUPPORT_TICKET_ALREADY_CREATED": 3016,
    "STEAM_UNAVAILABLE": 4000,
    "STEAM_LIMIT": 4001,
    "STEAM_UNAVAILABLE_CACHED": 4002,
    "THIRD_PARTY_UNAVAILABLE": 4003,
    "STEAM_OFFER_FAILURE": 4004,
    "ORDER_UNFULFILLED": 4005
};
$.ajaxSetup({
    "headers": {
        "X-CSRF": getCsrfToken(),
        "X-OP-UserID": g_UID
    }
});

function analytics(type, data) {
    data.type = type;
    $.post('/ajax/analytics.php', data);
}
var g_RequestsInFlight = 0;
var g_RSAKeyData = null;
var g_RSAFailures = 0;
var g_LoadedScripts = [];
var g_InvisibleCaptcha = null;
var g_UploadMaxSize = null;

function loadScript(src, callback) {
    if (g_LoadedScripts.indexOf(src) != -1) {
        callback(null);
        return;
    }
    var script = document.createElement("script");
    script.type = "text/javascript";
    script.onerror = function() {
        callback(new Error("Cannot load script"));
    };
    script.onload = function() {
        g_LoadedScripts.push(src);
        callback(null);
    };
    script.async = true;
    $('body').append(script);
    script.src = src;
}

function executeInvisibleCaptcha(callback) {
    if (typeof grecaptcha !== 'undefined') {
        doExecute();
    } else {
        setRequestInFlight(true);
        loadScript("https://www.google.com/recaptcha/api.js", function(err) {
            if (err) {
                sendAlert('danger', LANG.trans('captcha_unavailable'));
            } else {
                var interval = setInterval(function() {
                    if (typeof grecaptcha !== 'undefined') {
                        setRequestInFlight(false);
                        doExecute();
                        clearInterval(interval);
                    }
                }, 100);
            }
        });
    }

    function doExecute() {
        if (!g_InvisibleCaptcha) {
            var $div = $('<div />');
            $('body').append($div);
            g_InvisibleCaptcha = {};
            g_InvisibleCaptcha.id = grecaptcha.render($div[0], {
                "sitekey": g_ReCaptchaSiteKeyInvisible,
                "size": "invisible",
                "callback": function() {
                    g_InvisibleCaptcha.callback(grecaptcha.getResponse(g_InvisibleCaptcha.id));
                    grecaptcha.reset(g_InvisibleCaptcha.id);
                }
            });
        }
        g_InvisibleCaptcha.callback = callback;
        grecaptcha.execute(g_InvisibleCaptcha.id);
    }
}

function apiRequest(httpMethod, iface, method, version, data, callback, errCb, background) {
    ajaxJsonRequest(httpMethod, location.protocol + "//api." + getBaseDomain() + "/" + iface + "/" + method + "/v" + version + "/", data, callback, errCb, background);
}

function apiRSARequest(httpMethod, iface, method, version, data, encryptedFields, callback, errCb, background) {
    ajaxJsonRSARequest(httpMethod, location.protocol + "//api." + getBaseDomain() + "/" + iface + "/" + method + "/v" + version + "/", data, encryptedFields, callback, errCb, background);
}

function ajaxJsonRSARequest(method, endpoint, data, encryptedFields, callback, errCb, background) {
    var hasEncryptedField = false;
    for (var i = 0; i < encryptedFields.length; i++) {
        if (data[encryptedFields[i]]) {
            hasEncryptedField = true;
            break;
        }
    }
    if (!hasEncryptedField) {
        finish();
        return;
    }
    var args = Array.prototype.slice.call(arguments);
    loadScript("/js/jsencrypt.min.js", function(err) {
        if (err) {
            ajaxJsonRequest(method, endpoint, data, callback, errCb, background);
            return;
        }
        if (g_RSAKeyData === null || g_RSAKeyData.retry) {
            apiRequest("GET", "ISecurity", "GetRSAKey", 1, function(errCode, msg, res) {
                if (errCode) {
                    console.log("Got error code " + errCode + " when trying to get RSA key. Not using crypto.");
                    g_RSAKeyData = false;
                    finish();
                } else if (g_RSAKeyData && g_RSAKeyData.serial == res.serial && ++g_RSAFailures >= 2) {
                    console.log("Got same public key as last time. Not using crypto.");
                    g_RSAKeyData = false;
                    finish();
                } else {
                    g_RSAKeyData = res;
                    if (res.__time) {
                        g_RSAKeyData.timeOffset = Math.floor(Date.now() / 1000) - res.__time;
                    }
                    encryptAndFinish();
                }
            });
        } else {
            encryptAndFinish();
        }
    });

    function encryptAndFinish() {
        if (!g_RSAKeyData || !window.JSEncrypt) {
            finish();
            return;
        }
        data = JSON.parse(JSON.stringify(data));
        var encrypt = new JSEncrypt();
        encrypt.setPublicKey(g_RSAKeyData.key);
        var nonce = Math.floor(Date.now() / 1000) - (g_RSAKeyData.timeOffset || 0);
        for (var i = 0; i < encryptedFields.length; i++) {
            data[encryptedFields[i]] = encrypt.encrypt(nonce + data[encryptedFields[i]] + nonce);
        }
        data.rsakey_serial = g_RSAKeyData.serial;
        data.rsa_nonce = nonce;
        finish();
    }

    function finish() {
        ajaxJsonRequest(method, endpoint, data, function(errCode, msg, res) {
            if (res && res.__time) {
                g_RSAKeyData.timeOffset = Math.floor(Date.now() / 1000) - res.__time;
            }
            if (errCode == ErrorCode.ENCRYPTION_KEY_INVALID) {
                g_RSAKeyData.retry = true;
                ajaxJsonRSARequest.apply(null, args);
                return;
            } else if (!errCode) {
                g_RSAFailures = 0;
            }
            executeAjaxCallback(callback, errCode, msg, res);
        }, errCb, background);
    }
}

function ajaxJsonRequest(method, endpoint, data, callback, errCb, background) {
    if (typeof data === 'function') {
        callback = data;
        data = {};
    }
    if (background !== true) {
        setRequestInFlight(true);
    }
    var isApi = endpoint.match(/api\./);
    var prevHeaders = $.ajaxSettings.headers;
    if (isApi) {
        if (method.toUpperCase() == "POST") {
            if (data instanceof FormData) {
                data.append('csrf', getCsrfToken());
            } else {
                data.csrf = getCsrfToken();
            }
        }
        $.ajaxSettings.headers = {};
    }
    var ajaxOpts = {
        "type": method.toUpperCase(),
        "url": endpoint,
        "data": data,
        "xhrFields": endpoint.match(/api\./) ? {
            "withCredentials": true
        } : undefined,
        "success": function(response) {
            if (background !== true) {
                setRequestInFlight(false);
            }
            if (typeof response !== 'object') {
                console.log("Didn't get a JSON response back from ajaxJsonRequest");
                sendAlert('danger', LANG.trans('error_occurred'));
                if (errCb) {
                    errCb();
                }
                return;
            }
            if (typeof response.response === 'object' && response.time) {
                response.response.__time = response.time;
            }
            if (typeof response.balance !== 'undefined' && (typeof g_BalanceHidden === 'undefined' || !g_BalanceHidden)) {
                $('.op-count').html(formatCoins(response.balance).replace('$', ''));
            }
            if (typeof response.credits !== 'undefined') {
                $('.op-credits-count').html(formatCredits(response.credits));
            }
            executeAjaxCallback(callback, response.status == 1 ? null : response.status, response.message || null, response.response);
        },
        "error": function(e) {
            console.log(e);
            if (background !== true) {
                setRequestInFlight(false);
                
            }
            if (errCb) {
                errCb();
            }
        }
    };
    if (data instanceof FormData) {
        ajaxOpts.contentType = false;
        ajaxOpts.processData = false;
    }
    $.ajax(ajaxOpts);
    $.ajaxSettings.headers = prevHeaders;
}

function executeAjaxCallback(callback, errCode, msg, res) {
    if (callback.length == 1) {
        if (errCode) {
            msg = msg || (LANG.keywordExists('steam_error_codes.' + errCode) ? LANG.trans('steam_error_codes.' + errCode) : LANG.trans('error_occurred'));
            sendAlert('<div class="alert alert-danger">' + msg + '</div>');
        } else {
            callback(res);
        }
    } else if (callback.length == 2) {
        callback(errCode, res);
    } else {
        callback(errCode, msg, res);
    }
}

function ajaxAlertRequest(method, endpoint, data, callback) {
    if (typeof data === 'function') {
        callback = data;
        data = {};
    }
    setRequestInFlight(true);
    $.ajax({
        "type": method.toUpperCase(),
        "url": endpoint,
        "data": data,
        "success": function(response) {
            setRequestInFlight(false);
            var doSendAlert = true;
            if (callback) {
                callback(response, function skipSendAlert() {
                    doSendAlert = false;
                });
            }
            if (doSendAlert) {
                sendAlert(response);
            }
        },
        "error": function() {
            setRequestInFlight(false);
            sendAlert('<div class="alert alert-danger">' + LANG.trans('error_occurred') + '</div>');
            if (callback) {
                callback();
            }
        }
    });
}

function setRequestInFlight(inFlight) {
    if (inFlight) {
        g_RequestsInFlight++;
    } else {
        g_RequestsInFlight--;
    }
    if (g_RequestsInFlight < 0) {
        g_RequestsInFlight = 0;
    }
    if (g_RequestsInFlight > 0) {
        $('html').addClass('request-in-flight');
    } else {
        $('html').removeClass('request-in-flight');
    }
}

function uploadUserFile(inputFile, category, callback, progressCallback, errCb) {
    if (!g_UID) {
        callback(ErrorCode.NOT_LOGGED_IN, LANG.trans("upload.sign_in"));
        return;
    }
    if (!inputFile) {
        callback(ErrorCode.BAD_INPUT, LANG.trans("upload.no_file"));
        return;
    }
    if (!g_UploadMaxSize) {
        apiRequest("GET", "ISupport", "GetMaxUploadSize", 1, function(errCode, msg, res) {
            if (errCode) {
                executeAjaxCallback(callback, errCode, msg, res);
                return;
            }
            g_UploadMaxSize = res.max_size_bytes;
            finishUpload();
        });
    } else {
        finishUpload();
    }

    function finishUpload() {
        if (inputFile.size > g_UploadMaxSize) {
            executeAjaxCallback(callback, ErrorCode.REQUEST_OR_FILE_TOO_LARGE, LANG.trans("upload.too_big", {
                "filename": inputFile.name,
                "file_size": humanFileSize(inputFile.size, false),
                "max_size": humanFileSize(g_UploadMaxSize, false)
            }));
            return;
        }
        var form = new FormData();
        form.append('category', category);
        form.append('file', inputFile);
        if (progressCallback) {
            var oldXhr = $.ajaxSettings.xhr.bind($.ajaxSettings);
            $.ajaxSettings.xhr = function() {
                var xhr = oldXhr();
                if (xhr.upload) {
                    xhr.upload.addEventListener("progress", progressCallback, false);
                }
                $.ajaxSettings.xhr = oldXhr;
                return xhr;
            };
        }
        apiRequest("POST", "ISupport", "UploadImage", 1, form, callback, errCb);
    }
}

function createModal(title, noCloseButton) {
    var $modal = $('<div class="modal confirmModal fade" role="dialog" />');
    var $dialog = $('<div class="modal-dialog" role="document" />');
    var $content = $('<div class="modal-content ssModalContainer infoModal" />');
    $modal.append($dialog);
    $dialog.append($content);
    var $header = $('<div class="modal-header" />');
    if (!noCloseButton) {
        $header.append('<button type="button" class="close" data-dismiss="modal" aria-label="Close" id="modalClose"><span aria-hidden="true">&times;</span></button>');
    }
    $header.append('<h4 class="modal-title">' + (title || "") + '</h4>');
    var $body = $('<div class="modal-body" />');
    var $footer = $('<div class="modal-footer" />');
    $footer.append('<button type="button" class="btn btn-default" data-dismiss="modal" id="modalClose">' + LANG.trans('caption.dismiss') + '</button>');
    $content.append($header);
    $content.append($body);
    $content.append($footer);
    return $modal;
}

function useItem(i) {
    $('#shopSellShowcase, #privateListing,#screenshot').prop('checked', false);
    var item = '#userItem' + i;
    var tradable = $(item).data('tradable');
    var img = $(item).data('img');
    var nametag = $(item).data('nametag');
    var color = $(item).data('color');
    var marketName = $(item).data('name');
    var item_type = $(item).data('type');
    var marketHashName = $(item).data('marketname');
    var stickers = $(item).find('.opskins-stickers-icon').attr('data-original-title') || "";
    var discount = $('#pOff').val();
    var previewHtml = '';
    var $item = $(item);
    if ($item.attr('data-inspect')) {
        var link = $item.attr('data-inspect');
        previewHtml += "<div style='position:absolute; right:2px; bottom:2px; z-index:2;'>" + "<a class='btn btn-primary btn-sm' " +
            (link.match(/^https?:\/\//) ? "target='_blank' " : "") + "href='" + link + "'>" + LANG.trans('caption.inspect') + "</a></div>";
    }
    previewHtml += '<div style="position: absolute; left: 2px; bottom: 2px; z-index: 2">' + '<a class="btn btn-primary btn-sm" target="_blank" href="/?loc=shop_search&app=' + $item.data('appid') + '_' + $item.data('contextid') + '&search_item=' + encodeURIComponent(marketName) + '&sort=lh&search_internal=1">' + LANG.trans('caption.search') + '</a></div>';
    $('#marketPrice').html('');
    if (nametag != '') {
        var nameTagHtml = "<div style='position:absolute; left:2px; bottom:80px; z-index:2;'><span class='market-name'>" + LANG.trans('shop.name_tag') + ": " + nametag + "</span></div>";
    } else {
        nameTagHtml = '';
    }
    $('#sellItem').html("<div class='featured-item'><span class='market-name'>" + marketName + "</span><div class='op-item-stickers'>" + stickers + "</div>" + nameTagHtml + previewHtml + "<img style='margin-top:-25px;' src='//steamcommunity-a.opskins.media/economy/image/" + img + "/256fx256f' /><div class='item-add'><div class='item-amount'><div class='market-name' style='padding-bottom:0.3em;'><span id='marketPrice'></span></div></div></div>");
    var $sellBtn = $('#sellBtn');
    if (tradable === 0) {
        $sellBtn.html(LANG.trans('shop.not_tradable_item'));
        $sellBtn.attr('disabled', true);
        return false;
    } else {
        $sellBtn.html(LANG.trans('shop.place_item_in_queue'));
        $sellBtn.attr('disabled', false);
    }
    $('#uItem').val(i);
    $.ajax({
        type: 'POST',
        url: '/ajax/shop_sell_item_multi.php',
        data: {
            type: 'lookup',
            name: marketName,
            marketName: marketHashName,
            pOff: discount,
            appid: selectedAppId
        },
        success: function(data) {
            var html;
            if (selectedAppId === 440) {
                html = '<i class="stm stm-backpack-tf" title="Backpack.tf"></i> <a href="http://backpack.tf" target="_blank" style="color: inherit">' + data.analystString + '</a>';
                if (marketName.match(/unusual/i) || marketName.match(/killstreak/i)) {
                    html += '*<br /><small style="font-weight:normal;">' + LANG.trans('shop.effects_not_included') + '</small>';
                }
            } else {
                var opskins = '<i class="icon-logo" style="font-size:1.7em;" title="' + LANG.trans('shop.7_days_average') + '"></i> ' + data.opString;
                html = opskins + '<br /><i class="stm stm-steam" title="' + (selectedAppId === 730 ? LANG.trans('shop.steam_analyst') : LANG.trans('shop.steam_community_market')) + '"></i> ' + data.analystString;
            }
            $('#marketPrice').html(html);
            if (getUserPrice(marketName) !== null) {
                $('#shopSellAmt').val(getUserPrice(marketName));
            } else {
                $('#shopSellAmt').val(data['autoPrice'] / 100);
            }
            updateCom();
            if (can_screenshot(selectedAppId, item_type)) {
                $('#screenshot, #SsScBundle').prop('disabled', false);
            } else {
                $('#screenshot, #SsScBundle').prop('disabled', true);
            }
        },
        error: function(xhr) {
            if (xhr && xhr.status && xhr.status == 403) {
                location.reload();
            }
        }
    });
}

function can_screenshot(AppId, type) {
    if (AppId != g_appid_csgo) {
        return false;
    }
    for (var i = 0; i < g_NoScreenshotTypes.length; i++) {
        if (type.indexOf(g_NoScreenshotTypes[i]) != -1) {
            return false;
        }
    }
    return true;
}

function updateCom(event) {
    var commissionPct = parseFloat($('#comPrice').val());
    var userPct = 1 - commissionPct;
    var $shopSellAmt = $('#shopSellAmt');
    var $shopSellUserAmt = $('#shopSellUsrAmt');
    var ss_price = get_ss_price($shopSellAmt.val(), true);
    var price = ($shopSellAmt.val() * 100).toFixed(2);
    var userAmt;
    var $shopSellShowcase = $('#shopSellShowcase');
    var $privateListing = $('#privateListing');
    var $SsScBundle = $('#SsScBundle');
    var $screenshot = $('#screenshot');
    if (event && event.key != "Tab" && $(event.target).attr('id') == 'shopSellUsrAmt') {
        userAmt = Math.round($shopSellUserAmt.val() * 100).toFixed(2);
        price = Math.round(userAmt / userPct);
        if (userAmt == price) {
            price++;
        }
    }
    if (typeof g_HasFreeScreenshot !== 'undefined') {
        if (g_HasFreeScreenshot && !hasUsedPromoAddon(6) && $('.glyphicon-screenshot:visible').length == 0) {
            $('#ss_p_display').html('<u>FREE</u>');
        } else {
            if (ss_price > 0) {
                $('#ss_p_display').html(formatCoins(ss_price));
                $('#screenshotPrice').val(ss_price);
            } else {
                $('#ss_p_display').html(g_ss_percent + '%');
            }
        }
    }
    var commission = Math.round(price * commissionPct);
    if (price > 0 && commission < 1) {
        commission = 1;
    }
    userAmt = price - commission;
    var isFeatured = $shopSellShowcase.is(":checked");
    var isPrivate = $privateListing.is(":checked");
    var isSsSc = $SsScBundle.is(":checked");
    var isScreenshot = $screenshot.is(":checked");
    if (isSsSc) {
        $privateListing.prop("checked", false);
        $privateListing.prop("disabled", true);
        $shopSellShowcase.prop("checked", false);
        $shopSellShowcase.prop("disabled", true);
        $screenshot.prop("checked", false);
        $screenshot.prop("disabled", true);
    } else {
        if (isScreenshot) {
            $SsScBundle.prop("checked", false);
            $SsScBundle.prop("disabled", true);
            $privateListing.prop("disabled", false);
            $shopSellShowcase.prop("disabled", false);
        }
        if (isFeatured) {
            $privateListing.prop("checked", false);
            $privateListing.prop("disabled", true);
            $SsScBundle.prop("disabled", true);
            $SsScBundle.prop("checked", false);
        }
        if (isPrivate) {
            $shopSellShowcase.prop("checked", false);
            $shopSellShowcase.prop("disabled", true);
            $SsScBundle.prop("disabled", true);
            $SsScBundle.prop("checked", false);
        }
    }
    if (!isFeatured && !isPrivate && !isSsSc && !isScreenshot) {
        $privateListing.prop("disabled", false);
        $shopSellShowcase.prop("disabled", false);
        $screenshot.prop("disabled", false);
        $SsScBundle.prop("disabled", false);
    }
    var prevPrice = Math.round($shopSellAmt.val() * 100);
    var prevUserAmt = Math.round($shopSellUserAmt.val() * 100);
    var chkPrice = parseInt(price) / 100;
    if (price != 0 && userAmt != 0 && (price != prevPrice || userAmt != prevUserAmt)) {
        if (event !== undefined && event && $shopSellAmt.val() == chkPrice) {} else {
            $shopSellAmt.val(formatCoins(price, true, true));
        }
        $('#shopSellCom').val(formatCoins(commission) + " - " + commissionPct * 100 + "%");
        $shopSellUserAmt.val(formatCoins(userAmt, true, true));
    }
}

function hasUsedPromoAddon(type) {
    return localStorage['hasUsedPromoAddon' + type] && (Date.now() - localStorage['hasUsedPromoAddon' + type] <= (1000 * 60 * 60 * 24));
}

function getCsrfToken() {
    var cookies = getCookies();
    if (cookies.opskins_csrf_token && cookies.opskins_csrf_token.match(/^2/)) {
        return cookies.opskins_csrf_token;
    }
    var token = '2' + randomString(32);
    opSetCookie("opskins_csrf_token", token, null, '/');
    return token;
}

function randomString(length, charset) {
    charset = charset || "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    var str = '';
    var rando = null;
    if (window.crypto && window.crypto.getRandomValues && typeof Uint8Array === 'function') {
        rando = new Uint8Array(length);
        crypto.getRandomValues(rando);
    }
    for (var i = 0; i < length; i++) {
        str += charset.charAt(rando ? (rando[i] % charset.length) : Math.floor(Math.random() * charset.length));
    }
    return str;
}

function getCookies() {
    var cookies = document.cookie.split(';').filter(function(cookie) {
        return !!cookie.trim();
    });
    var match, cookiesObj = {};
    for (var i = 0; i < cookies.length; i++) {
        match = cookies[i].match(/\s*([^=]+)=([^;]*)\s*/);
        if (cookiesObj[match[1]]) {
            document.cookie = match[1] + "=deleted; expires=" + (new Date(0).toGMTString()) + "; path=/";
        } else {
            cookiesObj[match[1]] = decodeURIComponent(match[2].replace(/\+/g, ' '));
        }
    }
    return cookiesObj;
}

function getBaseDomain() {
    var domain = location.hostname.split('.');
    return domain.slice(domain.length - 2).join('.');
}

function opSetCookie(name, value, expires, path) {
    var cookie = name + "=" + encodeURIComponent(value);
    if (expires && expires instanceof Date) {
        cookie += "; expires=" + expires.toGMTString();
    }
    if (path) {
        cookie += "; path=" + path;
    }
    var domain = getBaseDomain();
    if (expires && expires instanceof Date && expires.getTime() == 0) {
        document.cookie = cookie;
        document.cookie = cookie + "; domain=." + domain;
        return;
    }
    cookie += "; domain=." + domain;
    document.cookie = cookie;
}

function opDeleteCookie(name) {
    var domain = getBaseDomain();
    var cookie = name + "=deleted; expires=Thu, 01 Jan 1970 00:00:00 GMT";
    document.cookie = cookie;
    document.cookie = cookie + "; path=/";
    document.cookie = cookie + "; domain=." + domain;
    document.cookie = cookie + "; path=/; domain=." + domain;
    document.cookie = cookie + "; domain=." + domain;
}

function getSelectedApp() {
    var cookie = getCookies().selectedApp;
    if (!cookie) {
        return {
            "appid": 730,
            "contextid": 2
        };
    }
    cookie = cookie.split('_');
    return {
        "appid": parseInt(cookie[0], 10),
        "contextid": parseInt(cookie[1], 10)
    };
}

function setSelectedApp(appid, contextid) {
    $('.appnav:not(.appnav_' + appid + ')').hide();
    $('.appnav_' + appid).show();
    $('.appbtn:not(#appbtn-' + appid + '_' + contextid + ')').removeClass('selected_app');
    $('#appbtn-' + appid + '_' + contextid).addClass('selected_app');
    opSetCookie('selectedApp', appid + '_' + contextid, null, '/');
}

function fixWeaponDropdown(e) {
    var wn_ddo = $('#weapon-navbar').find('.dropdown.open');
    if (typeof e != 'undefined') {
        wn_ddo = $(e.currentTarget);
        $('body').addClass('nav-no-scr');
    }
    if (wn_ddo.length) {
        var anchor = wn_ddo.find('> .dropdown-toggle');
        var panel = wn_ddo.find('.dropdown-menu');
        var ddRight = panel.hasClass('pull-right');
        var ddRightOverflow = (anchor.offset().left + panel.outerWidth() > $(window).innerWidth());
        if (ddRightOverflow) {
            if (!ddRight) {
                panel.addClass('pull-right');
            }
        } else {
            if (ddRight) {
                panel.removeClass('pull-right');
            }
        }
    }
}

function fixWeaponNav() {
    var topNavBarHeight = $('nav.navbar-fixed-top').outerHeight();
    var weaponNav = $('#weapon-navbar');
    var weaponNavHeight = 0;
    var windowW = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
    var extraMargin = (windowW <= 992) ? 25 : 0;
    var bodyMarTop = 50 + extraMargin;
    if (windowW <= 767) {
        topNavBarHeight = 80 + extraMargin;
    }
    if (weaponNav.is(':visible')) {
        weaponNav.css('top', topNavBarHeight - 1 + 'px');
        weaponNavHeight = weaponNav.outerHeight();
    }
    $('.content-fluid.nav-push').css('height', (topNavBarHeight + weaponNavHeight - bodyMarTop + 10 + extraMargin) + 'px');
    fixWeaponDropdown();
}
var stopScroll;
var openedMenu;
var lastY;

function preventDefaultS(e) {
    e = e || window.event;
    var overMenu = $.contains(openedMenu[0], e.target);
    var delta = e.deltaY;
    if (typeof delta == 'undefined') {
        var currentY = e.touches[0].clientY;
        delta = lastY - currentY;
        lastY = currentY;
    }
    var menu = $(openedMenu[0]);
    if (overMenu) {
        stopScroll = 0;
        if (delta < 0 && menu.scrollTop() <= 0) {
            stopScroll = 1;
        }
        if (delta > 0 && menu.scrollTop() + menu.innerHeight() >= menu[0].scrollHeight) {
            stopScroll = 1;
        }
    }
    if (overMenu && !stopScroll) {
        e.returnValue = true;
    } else {
        if (e.preventDefault) {
            e.preventDefault();
        }
        e.returnValue = false;
    }
}
$(document).ready(function() {
    function checkCookieAlert() {
        var cookieAlert = getCookies().CookieAlert;
        if (cookieAlert) {
            opDeleteCookie('CookieAlert');
            cookieAlert = JSON.parse(cookieAlert);
            var type = cookieAlert.type || 'success';
            sendAlert(type, cookieAlert.message);
        }
    }

    function checkKeysIncrementCookies() {
        var keysIncrement = getCookies().keysIncrement;
        var keysBalance = getCookies().keysBalance;
        if (keysIncrement) {
            opDeleteCookie('keysIncrement');
            opDeleteCookie('keysBalance');
            var keysBadge = $('#nav-keys-balance-container .badge');
            var newKeysValue = parseInt(keysBalance);
            keysBadge.html(newKeysValue);
            $('span#key-balance').html(newKeysValue);
        }
    }
    checkCookieAlert();
    checkKeysIncrementCookies();
    $("a[href^='https://blog.opskins.com']").on('click', function() {
        $.ajax({
            url: '/ajax/quests.php',
            method: 'POST',
            data: {
                action: 'perform',
                qtype: 7
            }
        });
    });

    function bodyScroll(enable, menu) {
        if (enable) {
            $('body').removeClass('nav-no-scr');
            openedMenu = null;
            if (window.removeEventListener)
                window.removeEventListener('DOMMouseScroll', preventDefaultS, false);
            window.onmousewheel = document.onmousewheel = null;
            window.onwheel = null;
            window.ontouchmove = null;
        } else {
            $('body').addClass('nav-no-scr');
            openedMenu = menu;
            if (window.addEventListener)
                window.addEventListener('DOMMouseScroll', preventDefaultS, false);
            window.onwheel = preventDefaultS;
            window.onmousewheel = document.onmousewheel = preventDefaultS;
            window.ontouchmove = preventDefaultS;
        }
    }

    function dSMenu(element) {
        if ($(window).width() <= 768) {
            return $('#top-nav-bar');
        }
        return element;
    }

    function scrollToSubMenu(item) {
        if ($(window).width() > 768) {
            return false;
        }
        $('#top-nav-bar').animate({
            scrollTop: item.offset().top - item.closest('ul').offset().top
        }, 400);
    }
    $('#weapon-navbar').on('show.bs.dropdown', '.dropdown', function(e) {
        fixWeaponDropdown(e);
        bodyScroll(false, dSMenu($(this).find('> .dropdown-menu')));
    }).on('hide.bs.dropdown', '.dropdown', function() {
        bodyScroll(true);
    });
    $('#top-nav-bar').on('shown.bs.collapse', function() {
        bodyScroll(false, dSMenu($(this).find('> .dropdown-menu')));
    }).on('hide.bs.collapse', function() {
        bodyScroll(true);
    }).on('show.bs.dropdown', '.dropdown', function() {
        bodyScroll(false, dSMenu($(this).find('> .dropdown-menu')));
        scrollToSubMenu($(this));
    }).on('hide.bs.dropdown', '.dropdown', function() {
        if ($(window).width() > 768) {
            bodyScroll(true);
        }
    });
    var OpgiftsNewsInterval;
    var newsOpBanner = $('#opgifts-new-f');
    var newsOpBox = $('#opgifts_nav_i');
    if (!getCookies().news_opgifts_f && $('#opgifts-new-f').length) {
        $('#opgifts-new-f').on('click', function() {
            OpgiftsNewsDown();
        });
        $('#nav-opgift-container > a').on('click', function() {
            OpgiftsNewsDown();
        });
        OpgiftsNewsInterval = window.setInterval(function() {
            newsOpBox.addClass('pulse-effect-4');
            if (newsOpBanner.hasClass('in')) {
                removeOpgiftsNewsBanner();
            } else {
                newsOpBanner.addClass('in');
            }
            setTimeout(function() {
                newsOpBox.removeClass('pulse-effect-4');
            }, 4000)
        }, 10000);
    }

    function removeOpgiftsNewsBanner() {
        newsOpBanner.removeClass('in');
        setTimeout(function() {
            newsOpBanner.remove();
        }, 200)
    }

    function OpgiftsNewsDown() {
        $('#opgifts-new-f').remove();
        $('#nav-opgift-container > a').off('click');
        if (typeof setInterval != 'undefined') {
            window.clearInterval(OpgiftsNewsInterval);
        }
    }
    $('.content-block-overlay').on('mousedown touchstart', function() {
        $('#top-nav-bar.in').collapse('hide');
        $('#top-nav-bar .dropdown.open, #weapon-navbar .dropdown.open').each(function() {
            $(this).closest('.dropdown-toggle').dropdown('collapse');
        });
        fixWeaponNav();
    });
    fixWeaponNav();
    $('#shopSellAmt').keydown(function(e) {
        var val = $(this).val();
        if ($.inArray(e.keyCode, [8, 46, 9, 27, 13, 110]) !== -1 || (e.keyCode >= 112 && e.keyCode <= 123) || (e.keyCode == 65 && e.ctrlKey) || (e.keyCode >= 35 && e.keyCode <= 39) || (!e.shiftKey && e.keyCode == 190 && val.length > 0 && val.indexOf('.') == -1)) {
            return;
        }
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
    $(".dropdown-menu li a").click(function() {
        var selText = $(this).text();
        $(this).parents('.drop-group').find('.dropdown-toggle').html(selText + ' <span class="caret"></span>');
    });
    $('#alert-box').click(function(e) {
        if (e.target.tagName != 'A') {
            dismissAlert();
        }
    });
    $('a.op-help-anchor').click(function(e) {
        e.preventDefault();
        var ele = $(this).attr("href").replace('#', '');
        var weapBar = $('#weapon-navbar').height();
        var navBar = $('.navbar:first').height();
        $('html, body').animate({
            scrollTop: $('a[name=' + ele + ']').offset().top - weapBar - navBar - 15
        }, 1000);
    });
    $('.help-nav-mobile a, .help-nav-dt a').click(function(e) {
        e.preventDefault();
        scrollTarget($(this), 30);
    });

    function scrollTarget(anchor, offset) {
        var target = anchor.attr("href").replace('#', '');
        var a_name = $('a[name=' + target + ']');
        var el_id = $('*[id=' + target + ']');
        if (!a_name.length && !el_id.length) {
            return false;
        }
        offset = typeof offset != 'undefined' ? offset : 0;
        var target_el = a_name.length ? a_name : el_id;
        $('html, body').scrollTop(target_el.offset().top - $('#weapon-navbar:visible').height() - $('nav.navbar').height() - offset);
    }
    var today = new Date();
    var jan = new Date(today.getFullYear(), 0, 1);
    var jun = new Date(today.getFullYear(), 6, 1);
    var stdOffset = Math.max(jan.getTimezoneOffset(), jun.getTimezoneOffset());
    var offset = today.getTimezoneOffset();
    var dst = offset < stdOffset;
    opSetCookie("timezone_offset", -(offset / 60) + "," + (dst ? 1 : 0), new Date(Date.now() + 31536000000), "/");
    var $searchApp = $('.search_app');
    $searchApp.change(function() {
        var app = $(this).val();
        $('.search_app').val(app);
        checkSearchFields(app);
    });
    checkSearchFields($searchApp.val());
    var cookieComplianceAccept = getCookies().eu_cookie_accepted;
    var euCountries = ["AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR", "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK", "SI", "ES", "SE", "GB"];
    if (!cookieComplianceAccept) {
        getCountry(function(err, loc) {
            if (err) {
                console.log("Cannot get Cloudflare trace loc: " + err.message);
                return;
            }
            if (euCountries.indexOf(loc) != -1) {
                $('#eu-cookie-stuff').slideDown();
                $('#eu-cookie-stuff-accept').click(function() {
                    $('#eu-cookie-stuff').slideUp();
                    opSetCookie("eu_cookie_accepted", "1", new Date(Date.now() + (1000 * 60 * 60 * 24 * 365 * 10)), "/");
                });
            } else {
                opSetCookie("eu_cookie_accepted", "auto", new Date(Date.now() + (1000 * 60 * 60 * 24 * 14)), "/");
            }
        });
    }
    var $carousel = $('.slick_carousel');
    if ($carousel && $carousel.length > 0 && $carousel.slick) {
        $carousel.slick({
            dots: true,
            infinite: true,
            speed: 500,
            slidesToShow: 5,
            slidesToScroll: 4,
            arrows: false,
            autoplay: true,
            autoplaySpeed: 3000,
            responsive: [{
                breakpoint: 1880,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 4
                }
            }, {
                breakpoint: 1269,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3
                }
            }, {
                breakpoint: 963,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            }, {
                breakpoint: 659,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }]
        });
    }
    $('#shopSellAmt').on('change keyup', function(event) {
        updateCom(event);
    });
    $('#shopSellUsrAmt').on('change keyup', function(event) {
        updateCom(event);
    });
    $('.img-fallback').error(function() {
        var $this = $(this);
        if ($this.attr('src') == $this.data('fallback')) {
            return;
        }
        $this.attr('src', $this.data('fallback'));
    });
    $('input:file').change(function() {
        $('input:submit').attr('disabled', !$(this).val());
    });
    var isOptInAnswer = false;
    if ($('#optinQuestionModal').length) {
        $('#optin-confirm-modal-form, #optin-question-modal-form').ajaxForm({
            beforeSubmit: function(arr, $form, options) {
                for (var i in arr) {
                    if (arr[i].name == 'answer') {
                        isOptInAnswer = parseInt(arr[i].value);
                        break;
                    }
                }
            },
            success: function() {
                $('#optoutConfirmModal').modal('hide');
                $('#optinQuestionModal').modal('hide');
                if (isOptInAnswer == '1') {
                    setTimeout(function() {
                        $('#doubleOptinSentModal').modal('show');
                        var optin = $('input[name=optin]');
                        var warning = $('#optinWarning');
                        if (optin.length && warning.length) {
                            optin.attr('checked', 'checked');
                            warning.slideDown('fast');
                        }
                    }, 600);
                }
            }
        });
        $('#optinQuestionModalBtnCancel').on('click', function() {
            $('#optoutConfirmModal').modal('show');
        });
        setTimeout(function() {
            $('#optinQuestionModal').modal('show');
        }, 4000);
    }
    initAsyncImages();
    $(".search-reset").click(function() {
        var form = $(this).closest('form');
        var curApp = form.find('select.search_app').val();
        form.find($('input[type=text], input[type=number], select')).val('');
        form.find($('input[type=checkbox]')).attr('checked', false);
        form.find($('select.search_app')).val(curApp);
        form.find($('select.sort')).val('f');
        form.find($('.stickers_added .label')).remove();
        event.stopPropagation();
    });
});
$(window).resize(function() {
    fixWeaponNav();
});
$(document).on('click', 'a[href^="steam://rungame/"]', function() {
    if (localStorage.getItem('has_steam_installed'))
        return true;
    if (!confirm(LANG.trans('shop.confirm_steam_installed')))
        return false;
    localStorage.setItem('has_steam_installed', true);
});
$(document).on('mouseleave', '.copy-url', function(e) {
    $(e.currentTarget).tooltip('destroy');
});
var copyShortUrl = new Clipboard('.copy-url', {
    target: function(trigger) {
        return trigger.nextElementSibling;
    }
});
copyShortUrl.on('success', function(e) {
    showTooltip(e.trigger, LANG.trans('shop.copied'));
});
copyShortUrl.on('error', function(e) {
    showTooltip(e.trigger, copyFallbackMessage());
});

function showTooltip(elem, msg) {
    $(elem).attr('data-original-title', msg).tooltip('fixTitle').tooltip('show');
}

function copyFallbackMessage() {
    var actionMsg = '';
    if (/iPhone|iPad/i.test(navigator.userAgent)) {
        actionMsg = LANG.trans('shop.copied_unsupported');
    } else if (/Mac/i.test(navigator.userAgent)) {
        actionMsg = LANG.trans('shop.copied_fallback', {
            key: 'вЊ'
        })
    } else {
        actionMsg = LANG.trans('shop.copied_fallback', {
            key: 'Ctrl'
        })
    }
    return actionMsg;
}

function checkSearchFields(app) {
    $('[data-search-apps]').each(function() {
        var $this = $(this);
        var apps = $this.data('search-apps').split(' ');
        var show = apps.indexOf(app) != -1;
        show ? $this.show() : $this.hide();
        if ($this.attr('name') || $this.attr('data-name')) {
            removeNameIfNeeded($this, show);
        }
        $this.find('[name], [data-name]').each(function() {
            removeNameIfNeeded($(this), show);
        });
    });

    function removeNameIfNeeded($this, show) {
        if (show && !$this.attr('name')) {
            $this.attr('name', $this.attr('data-name'));
            $this.attr('data-name', null);
        } else if (!show && $this.attr('name')) {
            $this.attr('data-name', $this.attr('name'));
            $this.attr('name', null);
        }
    }
}

function sendAlert(type, text) {
    var $alert = $('#alert-box');
    if ($alert.is(':visible')) {
        dismissAlert(100, function() {
            sendAlert(type, text);
        });
        return;
    }
    if (typeof text === 'string' && !type.match(/[<>]/)) {
        text = '<div class="alert alert-' + type + '">' + text + '</div>';
    } else {
        text = type;
    }
    if (text.match(/you cannot trade in the game/)) {
        text = text.replace('</div>', ' <a href="/kb/trade-denied" class="alert-link">' + LANG.trans('shop.more_info') + '</a></div>');
    }
    if (/data-uncheck-phone_ver/.test(text)) {
        $('input[name=phone_ver]').prop('checked', false);
    }
    $alert.html(text);
    if (type.indexOf('<script>location.reload();</script>') === -1) {
        $alert.slideDown();
    }
}

function dismissAlert() {
    var $alertBox = $('#alert-box');
    $alertBox.slideUp.apply($alertBox, arguments);
}

function getURLParameter(name) {
    return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [null, ''])[1].replace(/\+/g, '%20')) || null;
}

function addToCart(item, appid, amount) {
    var loc = getURLParameter('loc');
    if (loc === null) {
        loc = 'home';
    }
    var internal_search = getURLParameter('search_internal');
    if (g_UID == 0) {
        sendAlert('<div class="alert alert-warning">' + LANG.trans('shop.signin_before_add_item') + '</div>');
        return;
    }
    if (appid && amount) {
        ga('send', {
            'hitType': 'event',
            'eventCategory': 'Add to Cart',
            'eventAction': 'Skin',
            'eventLabel': appid,
            'eventValue': amount
        });
    }
    apiRequest("POST", "ICart", "AddToCart", 1, {
        "saleid": item,
        "location": loc,
        "amount": amount,
        "internal_search": internal_search
    }, function(errCode, msg, res) {
        if (errCode) {
            sendAlert('warning', msg || LANG.trans('shop.internal_error'));
            return;
        }
        if (amount && res && res.price && res.price > amount) {
            var acceptPrice = confirm(LANG.trans('shop.price_confirm', {
                "from_price": formatCoins(amount),
                "to_price": formatCoins(res.price)
            }));
            if (!acceptPrice) {
                removeItem(item, amount, true);
                return;
            }
        }
        sendAlert('success', LANG.trans("shop.item_added"));
        if (typeof res.cart_count !== 'undefined') {
            $('#cartCount').html(res.cart_count);
            $('#cartCountMobile').html(res.cart_count);
        } else {
            cart_counter();
        }
        var $cartContainer = $('#nav-cart-container');
        var $cart = $('.fa-shopping-cart');
        var v = $cartContainer.is(":visible");
        if (v == false) {
            $cart.css({
                'color': '#ac4e22',
                'font-size': '20px'
            });
            $cartContainer.fadeIn();
            $cart.fadeTo(500, 0.6, function() {
                $cart.animate({
                    fontSize: "40px",
                    opacity: 1
                }, 1500).css({
                    'color': 'white'
                });
            });
        }
    });
}

function removeItem(item, amount, silent) {
    apiRequest("POST", "ICart", "RemoveFromCart", 1, {
        "saleid": item
    }, function(errCode, msg, res) {
        if (errCode) {
            if (!silent) {
                sendAlert('warning', msg || LANG.trans('shop.internal_error'));
            }
            return;
        }
        if (!silent) {
            sendAlert('success', LANG.trans('shop.item_removed'));
        }
        $('#cartItem' + item).hide();
        var $totalCart = $('#totalCart');
        if ($totalCart && $totalCart.length > 0) {
            var total = $totalCart.html().replace(/\D/g, '');
            total = total - amount;
            var nCount = $totalCart.html() - 1;
            $totalCart.html(nCount);
            $('#cartCountMobile').html(nCount);
            if (nCount == 1) {
                $totalCart.html(LANG.trans('shop.total_cost_will_be', {
                    "total": total
                }));
            } else {
                $totalCart.html(LANG.trans('shop.total_cost_for_all_will_be', {
                    "count": nCount,
                    "total": total
                }));
            }
            if (total > 0) {
                $totalCart.html('$' + (total / 100).toFixed(2).replace(/./g, function(c, i, a) {
                    return i && c !== "." && ((a.length - i) % 3 === 0) ? ',' + c : c;
                }));
            } else {
                $totalCart.html('');
                $totalCart.hide();
                $totalCart.html("<span class='btn btn-lg btn-warning disabled' style='margin-left:auto;margin-right:auto;display: block;' id='ajaxLoader'>" + LANG.trans('shop.cart_is_empty') + "</span>");
            }
        }
        if (typeof res.cart_count !== 'undefined') {
            $('#cartCount').html(res.cart_count);
            $('#cartCountMobile').html(res.cart_count);
        } else {
            cart_counter();
        }
    });
}

function cart_counter() {
    $.ajax({
        type: 'GET',
        url: 'ajax/ui_updates.php',
        data: {
            type: 'cart_count'
        },
        success: function(result) {
            $('#cartCount').html(result);
            $('#cartCountMobile').html(result);
        }
    });
}

function updateBalance(master) {
    if (!g_UID) {
        return;
    }
    if (!master && localStorage.balance && localStorage.credits) {
        var balance = JSON.parse(localStorage.balance);
        var credits = JSON.parse(localStorage.credits);
        if (balance.uid == g_UID && Date.now() - balance.time < 60000) {
            $('.op-count').text(balance.text.replace('$', ''));
            $('.op-credits-count').html(credits.text);
        }
        return;
    }
    $.get("/ajax/ui_updates.php", {
        "type": "balance",
        "master": master ? 1 : 0
    }, function(response) {
        localStorage.balance = JSON.stringify({
            "uid": g_UID,
            "time": Date.now(),
            "text": response.balance
        });
        localStorage.credits = JSON.stringify({
            "uid": g_UID,
            "time": Date.now(),
            "text": response.credits
        });
        $('.op-count').text(response.balance.replace('$', ''));
        $('.op-credits-count').html(response.credits);
    });
}

function updateOsiCount(master) {
    if (!g_UID) {
        return;
    }
    $.get("/ajax/ui_updates.php", {
        "type": "osi_count",
        "master": master ? 1 : 0
    }, function(count) {
        $('#top-nav-bar').find('a[href*="loc=inventory"] .badge').text(count)[count == 0 ? 'hide' : 'show']();
    });
}

function formatCoins(coins, forInput, noTrailingZeroes) {
    var out = (coins / 100).toLocaleString(undefined, {
        "style": "currency",
        "currency": "USD"
    });
    if (forInput) {
        out = (coins / 100).toFixed(2);
    }
    if (noTrailingZeroes) {
        out = out.replace(/0*$/, '').replace(/\.$/, '');
    }
    return out;
}

function formatCredits(coins, withIcon) {
    if (typeof withIcon === 'undefined') {
        withIcon = true;
    }
    var formatted = formatCoins(coins, true);
    if (withIcon) {
        formatted = '<i class="icon-logo icon-logo-credits"></i> ' + formatted;
    }
    return formatted;
}

function ShowTradeOffer(tradeOfferID) {
    var winOffer = window.open('https://steamcommunity.com/tradeoffer/' + tradeOfferID + '/', '', 'height=1120,width=1028,resize=yes,scrollbars=yes');
    winOffer.focus();
}

function resendTrade(saleID) {
    if (g_RequestsInFlight > 0) {
        return;
    }
    ajaxAlertRequest('POST', '/ajax/resend_offer.php', {
        "saleid": saleID
    });
}

function showDiscount() {
    if (localStorage.hideGoodDealTags == 1) {
        return;
    }
    var minProfitPercent = 10;
    $('.featured-item:not(.scanned)').each(function(i, e) {
        var $amount = $(this).find('.item-amount');
        if (!$amount || $amount.length < 1) {
            return;
        }
        var price = $amount.html(),
            suggested = $(this).find('.suggested-price');
        if (price) {
            price = parseFloat(price.replace(/\$/g, '').replace(/,/g, ''));
        } else {
            return;
        }
        $(e).addClass('scanned');
        if (suggested.length > 0) {
            suggested = parseFloat(suggested.html().replace(/\$/g, '').replace(/,/g, ''));
            if (!suggested) {
                return;
            }
        } else {
            return;
        }
        var profitPct = 100 * (1 - (price / suggested));
        if (profitPct >= minProfitPercent) {
            $(e).find('.item-warning').after('<div class="good-deal-discount-pct"><span class="label label-success">' + Math.round(profitPct) + '% ' + LANG.trans('shop.percent_off') + '</span></div>');
        }
    });
}
$(document).ready(function() {
    $('#cPrefs').addClass('make-it-glow');
    setTimeout(function() {
        $('#cPrefs').removeClass('make-it-glow');
    }, 6000);
    showDiscount();

    function hideTooltips() {
        $('*[data-toggle="tooltip"][aria-describedby]').tooltip('hide');
    }
    $('*[data-toggle="tooltip"]').tooltip({
        trigger: 'hover focus'
    });
    $(window).resize(function() {
        hideTooltips();
    });
    $('body').keydown(function(e) {
        if (e.keyCode == 80) {
            $('#live-listing-pause').click();
        }
    });
    $('#graph_days_control').change(function() {
        var data = $('#graph_days_changer').serialize() + '&type=' + g_curGraphType;
        $('#histCanvas').html('<div class="text-center"><img src="/images/opskins-loading.gif" alt="Loading" style="height: 350px;"></div>');
        $.post('/ajax/sale_graph.php', data, function(data) {
            if (data.status == 1) {
                var $saleHistoryModal = $('#saleHistoryModal');
                if ($saleHistoryModal.length > 0) {
                    $saleHistoryModal.modal('show');
                    $saleHistoryModal.on('shown.bs.modal', function() {
                        if (data.hasOwnProperty("response")) {
                            eval(data.response);
                        } else {
                            $('#histCanvas').html('<div style="height:350px;" class="text-center"><h1>No sale data</h1></div>');
                        }
                    });
                } else {
                    if (data.hasOwnProperty("response")) {
                        eval(data.response);
                    } else {
                        $('#histCanvas').html('<div style="height:350px;" class="text-center"><h1>No sale data</h1></div>');
                    }
                }
            }
        });
    });
});

function showGraphFromId(id, days) {
    $.post('/ajax/sale_graph.php', {
        type: g_curGraphType,
        saleid: id,
        days: days
    }, function(data) {
        if (data.status == 1) {
            var $histCanvas = $('#histCanvas');
            $histCanvas.html('<div class="text-center"><img src="/images/opskins-loading.gif" alt="Loading" style="height: 350px;"></div>');
            var $saleHistoryModal = $('#saleHistoryModal');
            if ($saleHistoryModal.length > 0) {
                $saleHistoryModal.modal('show');
                if ($saleHistoryModal.is(':visible')) {
                    if (data.hasOwnProperty("response")) {
                        eval(data.response);
                    } else {
                        $histCanvas.html('<div style="height:350px;" class="text-center"><h1>No sale data</h1></div>');
                    }
                } else {
                    $saleHistoryModal.on('shown.bs.modal', function() {
                        if (data.hasOwnProperty("response")) {
                            eval(data.response);
                        } else {
                            $histCanvas.html('<div style="height:350px;" class="text-center"><h1>No sale data</h1></div>');
                        }
                    });
                }
            } else {
                if (data.hasOwnProperty("response")) {
                    eval(data.response);
                } else {
                    $histCanvas.html('<div style="height:350px;" class="text-center"><h1>No sale data</h1></div>');
                }
            }
        }
    });
}

function changeGraphDays(days) {
    var saleId = $('#lastSaleGraphId').val();
    showGraphFromId(saleId, days);
}

function toggleGraphType() {
    if (g_curGraphType == 1) {
        g_curGraphType = 2;
    } else {
        g_curGraphType = 1;
    }
    changeGraphDays($('#lastSaleGraphDays').val());
}

function confirmNotification() {
    $.ajax({
        type: 'POST',
        url: 'ajax/user_notifications.php',
        data: {
            type: 1
        },
        success: function(response) {
            sendAlert('<div class="alert alert-success">' + response + '</div>');
            $('#notificationModal').modal('hide');
        },
        error: function(response) {
            sendAlert('<div class="alert alert-danger">' + response + '</div>');
        }
    });
}

function substringMatcher(strs) {
    return function findMatches(q, cb) {
        var matches;
        matches = [];
        var substrRegex = new RegExp(q, 'i');
        $.each(strs, function(i, str) {
            if (substrRegex.test(str)) {
                matches.push(str);
            }
        });
        cb(matches);
    };
}

function addSearchSticker(defindex, stickerName) {
    var newElSearch, newElSidebar;
    if ($('input[type="hidden"][name="stickers[]"]:not(.stickers_onload)').filter(function() {
            return this.value == defindex
        }).length > 0) {
        return;
    }
    if ($('.sticker-search-param').length >= 8) {
        sendAlert('<div class="alert alert-danger">' + LANG.trans('shop.max_stickers_applied') + '</div>');
        return;
    }
    if (!stickerName) {
        for (var key in stickerData) {
            if (stickerData.hasOwnProperty(key) && stickerData[key] == defindex) {
                stickerName = key;
                break;
            }
        }
    }
    newElSidebar = $('<div class="label label-primary" onclick="$(this).remove();event.stopPropagation();"><i class="glyphicon glyphicon-remove"></i> <span class="sticker-search-param">' + stickerName + '</span><input type="hidden" name="stickers[]" value="' + defindex + '"></div>');
    newElSearch = $('<div class="label label-primary" onclick="$(this).remove();event.stopPropagation();" style="white-space:initial;margin-top:3px;"><i class="glyphicon glyphicon-remove"></i> <span class="sticker-search-param">' + stickerName + '</span><input type="hidden" name="stickers[]" value="' + defindex + '"></div>');
    $('#search_modal .stickers_added').append(newElSearch);
    $('#sidebar').find('.stickers_added').append(newElSidebar);
}
$(document).ready(function() {
    var $sticker_search = $('.sticker_search');
    if ($sticker_search && $sticker_search.length > 0 && $sticker_search.typeahead && typeof stickerData !== 'undefined' && typeof stickerNames !== 'undefined') {
        $sticker_search.typeahead({
            hint: true,
            highlight: true,
            minLength: 1
        }, {
            name: 'stickerNames',
            source: stickerNames,
            limit: 10
        }).on('typeahead:selected', function(ev, suggestion) {
            var stickerName = suggestion,
                defindex = stickerData[stickerName];
            addSearchSticker(defindex, stickerName);
        }).on('typeahead:close', function() {
            $('input.sticker_search').val('');
        }).on('typeahead:change', function() {
            $('input.sticker_search').val('');
        });
        $('span.twitter-typeahead').addClass('clearfix');
    }
    var $stickersOnload = $('input.stickers_onload');
    if ($stickersOnload.length > 0) {
        var found = [];
        $stickersOnload.each(function() {
            var val = $(this).val();
            if (found.indexOf(val) === -1) {
                found.push(val);
                addSearchSticker(val);
            }
            $(this).remove();
        });
    }
});
if (typeof stickerData !== 'undefined') {
    var stickerNames = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.whitespace,
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        local: stickerData ? Object.keys(stickerData) : []
    });
}

function showScreenshot(id, name, price, wear, patternIndex, webm) {
    analytics("screenshot", {
        "saleid": id
    });
    var $modal = createModal();
    $modal.find('.modal-title').text(name);
    $modal.find('.modal-dialog').addClass('modal-lg');
    $modal.find('.modal-content').addClass('ssModalContainer');
    var $body = $modal.find('.modal-body');
    var $expand = $('<span />');
    $expand.addClass('ssExpand').addClass('glyphicon').addClass('glyphicon-fullscreen').css('cursor', 'pointer');
    $expand.click(function() {
        $expand.remove();
        $modal.find('.modal-dialog').width('90%');
    });
    if (typeof webm !== 'undefined' && webm > 0 && !navigator.userAgent.match(/(Edge\/|MSIE |Trident\/)/)) {
        var $vid = '<video id="video1" autoplay loop class="img-responsive">\
            <source src="https://files.opskins.media/file/opskins-screenshots/' + id + '.webm" type="video/webm" />\
        </video>';
        $body.append($vid);
    } else {
        $body.append($expand);
        var $img;
        for (var i = 1; i <= 2; i++) {
            $img = $('<img />');
            $img.attr('alt', name);
            $img.addClass('img-responsive').addClass('screenshot-images');
            $img.attr('src', 'https://files.opskins.media/file/opskins-screenshots/' + id + '_' + i + '.jpg');
            $body.append($img);
        }
    }
    var $footer = $modal.find('.modal-footer');
    var $lcol = $('<span />');
    $lcol.addClass('ssModalFooter').addClass('pull-left');
    var $addToCartBtn = $('<button />');
    $addToCartBtn.addClass('btn').addClass('btn-orange').attr('type', 'button');
    $addToCartBtn.click(function() {
        addToCart(id, 730, price);
    });
    $addToCartBtn.text(LANG.trans('shop.add_to_cart'));
    $lcol.append($addToCartBtn);
    if (g_UID > 0) {
        var $buyNowBtn = $('<button />');
        $buyNowBtn.addClass('btn').addClass('btn-success').attr('type', 'button');
        $buyNowBtn.click(function() {
            oneClickBuy(id, price);
        });
        $buyNowBtn.text(LANG.trans('shop.buy_now'));
        $lcol.append($buyNowBtn);
    }
    var $price = $('<span />');
    $price.css('margin-left', '20px');
    $price.html(LANG.trans('shop.price') + ': <strong>' + formatCoins(price) + '</strong>');
    $lcol.append($price);
    $footer.html($lcol);
    var $rcol = $('<span />');
    $rcol.addClass('ssModalFooter');
    $rcol.html(LANG.trans('shop.wear') + ': <strong>' + (wear || LANG.trans('shop.unknown')) + '</strong>');
    $footer.append($rcol);
    $modal.modal();
}

function expandSSmodal() {
    $('#ssModalBody').width('90%');
    $('.ssExpand').hide();
}

function get_ss_price(amount, preListing) {
    if (!preListing && typeof g_HasFreeScreenshot !== 'undefined' && g_HasFreeScreenshot && !hasUsedPromoAddon(6) && $('.glyphicon-screenshot:visible').length - 1 == 0) {
        return 0;
    }
    var price = Math.ceil(Math.round(amount * g_ss_percent));
    if (price > g_ss_max_price) {
        price = g_ss_max_price;
    }
    if (price < g_ss_min_price) {
        price = g_ss_min_price;
    }
    return price;
}

function swapScreenshot() {
    var $ssImg = $('#ssImg');
    var $ssImgVal = $('#ssImgVal');
    var ss = $ssImgVal.val();
    if (ss == 1) {
        $ssImg.attr("src", $('#ssImg2').val());
        $ssImgVal.val('2');
        return;
    }
    $ssImg.attr("src", $('#ssImg1').val());
    $ssImgVal.val('1');
}

function buyAddon(saleID, addonType, price, numberFree, skipConfirm) {
    if (g_RequestsInFlight > 0) {
        return;
    }
    if (numberFree == 0 && !skipConfirm && !confirm(LANG.trans('shop.purchase_addon_confirmation', {
            price: formatCoins(price)
        }))) {
        return;
    }
    ajaxJsonRequest("POST", "/ajax/buy_addon.php", {
        "saleid": saleID,
        "type": addonType,
        "wants_free": numberFree > 0 ? 1 : 0
    }, function(errCode, response) {
        if (errCode) {
            switch (errCode) {
                case ErrorCode.NO_MORE_FREE_USES:
                    if (response.price && confirm(LANG.trans('shop.have_not_any_more_uses_addon_price', {
                            price: formatCoins(response.price)
                        }))) {
                        buyAddon(saleID, addonType, price, 0, true);
                    } else if (!response.price) {
                        sendAlert('<div class="alert alert-warning">' + LANG.trans('shop.have_not_any_more_uses_addon_refresh_page') + '</div>');
                    }
                    break;
                case ErrorCode.NOT_ENOUGH_COINS:
                    sendAlert('<div class="alert alert-warning">' + LANG.trans('shop.have_enough_wallet_funds') + '</div>');
                    break;
                case ErrorCode.ALREADY_IN_THAT_STATE:
                    sendAlert('<div class="alert alert-warning">' + LANG.trans('shop.item_already_has_addon') + '</div>');
                    break;
                case ErrorCode.UNACCEPTABLE_ITEM:
                    sendAlert('<div class="alert alert-warning">' + LANG.trans('shop.can_not_apply_addon_to_item') + '</div>');
                    break;
                case ErrorCode.BAD_STATE:
                    sendAlert('<div class="alert alert-warning">' + LANG.trans('shop.item_not_on_sale_cannot_apply_addon') + '</div>');
                    break;
                default:
                    sendAlert('<div class="alert alert-danger">' + LANG.trans('shop.unexpected_error_occurred_code', {
                        code: errCode
                    }) + '</div>');
            }
        } else {
            $('#buyaddon-' + saleID + '-' + addonType).remove();
            sendAlert('<div class="alert alert-success">' + (response.message || LANG.trans('shop.item_added_successfully')) + '</div>');
        }
    });
}

function repairSale(saleid) {
    apiRequest('POST', 'ISupport', 'RepairItem', 1, {
        "saleid": saleid
    }, function(errCode, message, response) {
        if (errCode) {
            if (message) {
                sendAlert('<div class="alert alert-warning">' + message + '</div>');
            } else {
                var strCode = errCode.toString();
                var errorMessage = LANG.keywordExists('steam_error_codes.' + strCode) ? LANG.trans('steam_error_codes.' + strCode) : LANG.trans('error_occurred_code', {
                    code: strCode
                });
                sendAlert('<div class="alert alert-warning">' + errorMessage + '</div>');
            }
            return;
        }
        var itemType = response.type || "item";
        if (response.repaired) {
            sendAlert('<div class="alert alert-success">' + LANG.trans('shop.we_able_to_repair_item_type', {
                item_type: itemType
            }) + '</div>');
        } else {
            sendAlert('<div class="alert alert-warning">' + LANG.trans('shop.we_not_able_to_repair_item_type', {
                item_type: itemType,
                href_prefix: '<a href="/?loc=support_new_ticket&amp;department=' + response.supportDepartment + '&amp;saleid=' + saleid + '" class="alert-link">'
            }) + '</div>');
            $('#selfrepair-' + saleid).remove();
        }
        (response.repairedSaleids || []).forEach(function(id) {
            $('#sale-' + id + '-actions').html('<a class="btn btn-default" href="javascript:resendTrade(' + id + ')">' + LANG.trans('shop.resend_trade_offer') + '</a>');
            $('#osi-actions-' + id).html(generateOsiActions(id));
        });
    });

    function generateOsiActions(itemid) {
        return '<button class="btn btn-success add-to-return" type="button" onclick="addToReturns(this, ' + itemid + ')">' + LANG.trans('shop.add_to_returns') + '</button> ' + '<button class="btn btn-warning remove-from-return" type="button" onclick="removeFromReturns(this, ' + itemid + ')" style="display: none">' + LANG.trans('shop.remove_from_returns') + '</button> ' + '<a class="btn btn-orange re-sell" href="/?loc=shop_view_item&amp;item=' + itemid + '&amp;uid=' + g_UID + '">Sell</a>';
    }
}

function returnToInventory(saleIds, shouldWithdraw) {
    var items = saleIds.join(',');
    apiRequest('POST', 'ISales', 'ReturnItemsToInventory', 1, {
        "items": items
    }, function(errCode, msg, res) {
        if (errCode) {
            sendAlert('danger', msg || LANG.trans('error_occurred_code', {
                "code": errCode
            }));
            return;
        }
        if (shouldWithdraw) {
            withdrawSales(saleIds, {
                "checkout": 1
            });
        } else {
            $('#form-modify-item').remove();
            sendAlert('success', LANG.trans('shop_view_item.modal.return_item.delisted_successfully'));
            setTimeout(function() {
                location.href = '/?loc=inventory';
            }, 5000)
        }
    });
}

function withdrawSales(saleIds, data) {
    $('.mystery-reveal').addClass('mystery-done');
    var numConcurrentOffers = 3;
    data = data || {};
    data.filter_ids = saleIds.join(',');
    apiRequest('GET', 'ISales', 'GetSales', 1, data, function(errCode, msg, res) {
        if (errCode) {
            sendAlert('danger', msg || LANG.trans('error_occurred_code', {
                "code": errCode
            }));
            return;
        }
        var bots = {};
        var isOsiWithdrawal = null;
        res.forEach(function(item) {
            if (saleIds.indexOf(item.id) != -1) {
                bots[item.bot] = bots[item.bot] || [];
                bots[item.bot].push(item.id);
                var isWithdrawal = item.state == 7;
                if (isOsiWithdrawal !== null && isWithdrawal != isOsiWithdrawal) {
                    sendAlert('danger', LANG.trans('error_occurred_code', {
                        "code": "10"
                    }));
                    throw "whups";
                } else {
                    isOsiWithdrawal = isWithdrawal;
                }
            }
        });
        var botsQueue = Object.keys(bots).sort(function(a, b) {
            return parseInt(a, 10) < parseInt(b, 10) ? -1 : 1;
        });
        var initialQueueLength = botsQueue.length;
        var isInventoryPage = location.search.indexOf("loc=inventory") != -1;
        var isAccountPage = location.search.indexOf("loc=store_account") != -1;
        var $modal = createModal(LANG.trans('inventory.withdraw_modal.title'));
        $modal.find('.modal-dialog').addClass('modal-lg');
        $modal.find('.modal-content').addClass('ssModalContainer').addClass('infoModal');
        var $body = $modal.find('.modal-body');
        $modal.find('.modal-footer').html('<button type="button" class="btn btn-default" data-dismiss="modal">' + LANG.trans('inventory.withdraw_modal.dismiss') + '</button>');
        $body.html('<p>' + LANG.trans('inventory.withdraw_modal.caption') + '</p>');
        var botDataElements = {};
        var $dl = $('<dl class="dl-horizontal" />');
        botsQueue.forEach(function(botID) {
            var paddedBotID = botID.toString();
            while (paddedBotID.length < 4) {
                paddedBotID = '0' + paddedBotID;
            }
            $dl.append('<dt>' + LANG.trans('inventory.withdraw_modal.bot_title', {
                "id": paddedBotID
            }) + '</dt>');
            var $dd = $('<dd />');
            $dd.html('<i>' + LANG.trans('inventory.withdraw_modal.pending') + '</i>');
            $dl.append($dd);
            botDataElements[botID] = $dd;
        });
        $body.append($dl);
        if (initialQueueLength > 1) {
            $modal.modal();
        }
        var numRunningWorkers = 0;
        var numUntradable = 0;
        var hasErrors = false;
        for (var i = 0; i < numConcurrentOffers; i++) {
            numRunningWorkers++;
            sendOffer(i);
        }

        function sendOffer(workerNum) {
            if (botsQueue.length == 0) {
                if (--numRunningWorkers == 0) {
                    if (hasErrors && !isInventoryPage && !isAccountPage) {
                        $body.find('p').addClass('text-danger').text(LANG.trans('inventory.withdraw_modal.' + (isOsiWithdrawal ? 'resend_from_osi' : 'resend_from_account_page')));
                    } else {
                        $body.find('p').remove();
                    }
                }
                $('#form-modify-item').remove();
                return;
            }
            var botID = botsQueue.splice(0, 1)[0];
            if (numUntradable >= 5) {
                hasErrors = true;
                botDataElements[botID].text(LANG.trans('inventory.withdraw_modal.failed'));
                sendOffer(workerNum);
                return;
            }
            botDataElements[botID].html('<i class="fa fa-spin fa-refresh"></i> ' + LANG.trans('inventory.withdraw_modal.sending'));
            apiRequest('POST', isOsiWithdrawal ? 'IInventory' : 'ISales', isOsiWithdrawal ? 'Withdraw' : 'ReturnItems', 1, {
                "items": bots[botID].join(',')
            }, function(errCode, msg, res) {
                if (errCode && !(res && res.offers && res.offers[0] && res.offers[0].tradeoffer_error)) {
                    hasErrors = true;
                    botDataElements[botID].text(msg || LANG.trans('error_occurred_code', {
                        "code": errCode
                    }));
                    if (initialQueueLength == 1) {
                        sendAlert('warning', msg || LANG.trans('error_occurred_code', {
                            "code": errCode
                        }));
                    }
                    sendOffer(workerNum);
                    return;
                }
                var offer = res.offers[0];
                if (offer.tradeoffer_error) {
                    if (offer.tradeoffer_error.indexOf("Your Trade URL is invalid") != -1) {
                        numUntradable++;
                    }
                    hasErrors = true;
                    botDataElements[botID].text(offer.tradeoffer_error);
                    if (initialQueueLength == 1) {
                        sendAlert('warning', offer.tradeoffer_error + (!isInventoryPage ? '<br />' + LANG.trans('inventory.withdraw_modal.' + (isOsiWithdrawal ? 'resend_from_osi' : 'resend_from_account_page')) : ''));
                    }
                } else {
                    botDataElements[botID].html('<a href="javascript:ShowTradeOffer(\'' + offer.tradeoffer_id + '\')">' + LANG.trans('inventory.withdraw_modal.offer_sent') + '</a>');
                    if (initialQueueLength == 1 && res.offer_link) {
                        sendAlert('success', res.offer_link);
                    }
                }
                sendOffer(workerNum);
            }, function() {
                hasErrors = true;
                botDataElements[botID].text(LANG.trans('error_occurred'));
                sendOffer(workerNum);
                if (initialQueueLength == 1) {
                    sendAlert('danger', LANG.trans('error_occurred'));
                }
            });
        }
    });
}

function modalConfirm(title, body, okButton, callback, noCloseButton, cancelBtn, customClass) {
    if (typeof okButton === 'function') {
        callback = okButton;
        okButton = 'OK';
    }
    var $modal = createModal(title, noCloseButton);
    $modal.find('.modal-body').html(body);
    if (customClass) {
        $modal.addClass(customClass);
    }
    var $footer = $modal.find('.modal-footer');
    if (typeof cancelBtn === 'undefined' || cancelBtn === null) {
        $footer.html('<button type="button" class="btn btn-default" data-dismiss="modal">' + LANG.trans('caption.cancel') + '</button>');
    } else {
        $footer.html(cancelBtn);
    }
    if (okButton !== undefined) {
        var $ok = $('<button type="button" class="btn btn-primary" data-dismiss="modal"></button>');
        $ok.html(okButton);
        $ok.click(callback);
    }
    $footer.append($ok);
    $modal.modal();
    return $modal;
}

function securityPrompt(callback) {
    if (!g_UID) {
        return;
    }
    var $modal = createModal("<i class=\"fa fa-lock\"></i> " + LANG.trans('shop.security_conf_required_modal_title'));
    var $body = $modal.find('.modal-body');
    var $footer = $modal.find('.modal-footer');
    var $info = $('<p>' + LANG.trans('shop.security_conf_required_modal_info') + '</p>');
    $body.html($info);
    var captchaWidgetId = null;
    if (g_Has2FA) {
        var formId = randomId();
        var $form = $('<form id="' + formId + '" style="margin-bottom: 10px" />');
        var $group = $('<div class="form-group" />');
        var id = randomId();
        $group.append('<label for="' + id + '">' + LANG.trans('shop.two_factor_auth_code') + '</label>');
        var $input = $('<input type="text" class="form-control" id="' + id + '" placeholder="' + LANG.trans('shop.enter_current_code_from_app') + '" required />');
        $group.append($input);
        $form.append($group);
        $body.append($form);
        $footer.html('<button type="submit" form="' + formId + '" class="btn btn-primary">' + LANG.trans('caption.confirm') + '</button>');
        $modal.on('shown.bs.modal', function() {
            $input.focus();
        });
        $form.submit(function() {
            var code = $input.val();
            var captcha = "";
            if (!code) {
                err(LANG.trans('shop.provide_current_two_factor_code'));
                return false;
            }
            if (!code.match(/^\d{6}$/)) {
                err(LANG.trans('shop.cannot_backup_code_here'));
                return false;
            }
            if (!g_CanSpecialActions) {
                if (captchaWidgetId === null) {
                    err(LANG.trans('shop.wait_security_check'));
                    return false;
                }
                captcha = grecaptcha.getResponse(captchaWidgetId);
                if (!captcha) {
                    err(LANG.trans('complete_captcha'));
                    return false;
                }
            }
            $modal.modal('hide');
            callback({
                "captcha": captcha,
                "twoFactorCode": code
            });
            return false;
        });
    } else {
        $footer.remove();
    }
    if (!g_CanSpecialActions) {
        var $captcha = $('<div />');
        $body.append($captcha);
        var captchaCallback = randomId();
        window[captchaCallback] = function() {
            captchaWidgetId = grecaptcha.render($captcha[0], {
                "sitekey": g_ReCaptchaSiteKey,
                "callback": function(res) {
                    if (!g_Has2FA) {
                        $modal.modal('hide');
                        callback({
                            "captcha": res,
                            "twoFactorCode": ""
                        });
                    }
                }
            });
        };
        if (typeof grecaptcha !== 'undefined') {
            window[captchaCallback]();
        } else {
            $.getScript("https://www.google.com/recaptcha/api.js?render=explicit&onload=" + captchaCallback);
        }
    }
    $modal.modal();

    function randomId() {
        var id;
        do {
            id = randomString(16, "abcdefghijklmnopqrstuvwxyz");
        } while (document.getElementById(id) || window[id]);
        return id;
    }

    function err(msg) {
        $info.css('color', '#f00');
        $info.css('font-weight', 'bold');
        $info.text(msg);
    }
}

function oneClickBuy(saleid, price) {
    var loc = getURLParameter('loc');
    if (loc === null) {
        loc = 'home';
    }
    var internal_search = getURLParameter('search_internal') ? 1 : 0;
    apiRequest("POST", "ICart", "QuickBuy", 1, {
        "saleid": saleid,
        "total": price,
        "location": loc,
        "internal_search": internal_search
    }, function(errCode, msg, res) {
        if (errCode) {
            if (errCode == ErrorCode.ACCESS_DENIED) {
                oneClickUnavailable(!res.oneclick_authorized);
            } else {
                sendAlert('warning', msg || LANG.trans('error_occurred_code', {
                    "code": errCode
                }));
            }
            return;
        }
        sendAlert('success', LANG.trans('checkout.one_click.success'));
        updateOsiCount(true);
        if (res.dataLayer && typeof dataLayer === 'object' && dataLayer.push) {
            dataLayer.push(res.dataLayer);
        }
        if (res.googleAnalytics) {
            var $div = $('<div />');
            $div.html(res.googleAnalytics);
            $('body').append($div);
        }
    });
}

function oneClickUnavailable(needsBc) {
    var $modal = createModal(LANG.trans('one_click.unavailable_title'));
    $modal.find('.modal-body').html('<p>' + LANG.trans('one_click.description') + '</p>').append('<p>' + LANG.trans('one_click.' + (needsBc ? 'bc_required' : 'must_enable')) + '</p>');
    var $enableBtn = $('<button class="btn btn-primary" type="button" />');
    if (needsBc) {
        $enableBtn.html(LANG.trans('one_click.get_bc_button'));
        $enableBtn.click(function() {
            location.href = "/?loc=subscriptions";
        });
    } else {
        $enableBtn.html(LANG.trans('one_click.enable_button'));
        $enableBtn.click(function() {
            $modal.modal('hide');
            ajaxAlertRequest('POST', '/ajax/account_options.php', {
                "type": "enable_one_click"
            });
        });
    }
    $modal.find('.modal-footer').prepend($enableBtn);
    $modal.modal();
}
var MITypes = {
    "CSGO_KNIFE": 1,
    "CSGO_PISTOL": 2,
    "CSGO_RIFLE": 3,
    "CSGO_SMG": 4,
    "CSGO_MG": 5,
    "CSGO_GLOVE": 6,
    "CSGO_SHOTGUN": 7,
    "CSGO_STICKER": 8,
    "CSGO_GRAFFITI": 27,
    "H1Z1_KOTK_CHEST": 9,
    "H1Z1_KOTK_ARMOR": 10,
    "H1Z1_KOTK_FEET": 11,
    "H1Z1_KOTK_HANDS": 12,
    "H1Z1_KOTK_HEAD": 13,
    "H1Z1_KOTK_WEAPON": 14,
    "H1Z1_KOTK_LEGS": 15,
    "H1Z1_KOTK_BACK": 16,
    "H1Z1_KOTK_FACE": 17,
    "H1Z1_JS_CHEST": 18,
    "H1Z1_JS_ARMOR": 19,
    "H1Z1_JS_FEET": 20,
    "H1Z1_JS_HANDS": 21,
    "H1Z1_JS_HEAD": 22,
    "H1Z1_JS_WEAPON": 23,
    "H1Z1_JS_LEGS": 24,
    "H1Z1_JS_BACK": 25,
    "H1Z1_JS_FACE": 26
};

function getMinMax(lvl) {
    if (typeof lvl === 'object') {
        lvl = lvl.newValue;
    }
    g_MiLvl = lvl;
    switch (lvl) {
        case 0:
            var low = g_MiMinPrice.LOW;
            var high = g_MiMaxPrice.LOW;
            g_MiPlayLvl = 1;
            mysteryLast.g_MiPlayLvl = 1;
            break;
        case 1:
            var low = g_MiMinPrice.MEDIUM;
            var high = g_MiMaxPrice.MEDIUM;
            g_MiPlayLvl = 2;
            mysteryLast.g_MiPlayLvl = 2;
            break;
        case 2:
            var low = g_MiMinPrice.ALL;
            var high = g_MiMaxPrice.ALL;
            g_MiPlayLvl = 0;
            mysteryLast.g_MiPlayLvl = 0;
            break;
        default:
            var low = 0;
            var high = 0;
    }
    var minmax = '';
    if (low > 0 && high > 0) {
        var minmax = 'Prices ranging from ' + formatCoins(low) + " to " + formatCoins(high);
    }
    $('#minMaxText').html(minmax);
    return minmax;
}
g_MiLvl = 1;
g_MiPlayLvl = 2;
var mysteryLast = {
    type: '',
    price: '',
    min: '',
    max: ''
};

function MysteryItemCheckout(type, price, min, max) {
    mysteryLast = {
        type: type,
        price: price,
        min: min,
        max: max,
        g_MiPlayLvl: g_MiPlayLvl
    };
    var mname = getMysteryItemFriendlyName(type);
    var mimg = getMysteryItemImage(type);
    g_MiMinPrice = min;
    g_MiMaxPrice = max;
    var minmax = getMinMax(g_MiLvl);
    var body = "<link href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/9.8.0/css/bootstrap-slider.min.css' rel='stylesheet'><script src='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/9.8.0/bootstrap-slider.min.js' type='text/javascript'></script><div class='mystery-modal'>" + "<div class='mystery-item-inner'></div>" + "<img class='item-img' style='width:80%; max-width:256px;' src='" + mimg + "' alt='" + mname + "'>" + "</div>" + "<div class='mystery-how-works'><a href='#'>" + LANG.trans('mystery_item.desc_title') + "</a>" + "<div class='mystery-how-desc'>" + LANG.trans('mystery_item.description') + "</div></div>" + "<div class='mystery-price-header'><span class='label-mysteryness'>Choose Your Mysteriousness</span><span class='label-price'>" + LANG.trans('shop.price') + "</span></div>" + "<div class='mystery-price-info'><div class='mystery-slider'><input id='MiLvlSlider' type='text' data-provide='slider' data-slider-ticks='[0, 1, 2]' data-slider-ticks-labels='[\"low\", \"medium\", \"high\"]' data-slider-min='0' data-slider-max='2' data-slider-step='1' data-slider-value='" + g_MiLvl + "' data-slider-tooltip='hide' /><span id='minMaxText'>" + minmax + "</span></div><div class='mystery-price'><span class='price-value'>" + formatCoins(price) + "</span><span class='price-desc'>" + LANG.trans('mystery_item.desc_note') + "</span></div></div>" + "<script>$('#MiLvlSlider').slider({id:'mislide'});$('#MiLvlSlider').on('change',function(slideEvt){getMinMax(slideEvt.value);});$('.confirmModal').on('hidden.bs.modal', function (e) {$('.confirmModal').remove();});$('.mystery-how-works a').on('click', function(e){ e.preventDefault(); $('.mystery-how-desc').toggleClass('active');$('.modal-backdrop').css('position', 'fixed'); })</script>";
    modalConfirm(LANG.trans('mystery_item.modal_title', {
        item_name: mname
    }), body, LANG.trans('mystery_item.modal_submit'), function() {
        $('.confirmModal').remove();
        displayOverlayBar('', type);
        var $olb = $('#OP_overlayBar');
        var $olbm = $('#olbMsg');
        var $olbd = $('#olbBody');
        apiRequest('POST', 'IMysteryItems', 'BuyMysteryItem', 1, {
            'type': type,
            'sub_type': g_MiPlayLvl
        }, function(errCode, msg, res) {
            $olb.append('<img src="/images/alert-close.png" style="position: absolute;top: 10px;right: 10px;cursor:pointer;" onclick="closeOverlayBar()">');
            if (!errCode) {
                incrementOSIBadge();
                var statClass = '';
                var statTrak = '';
                if (res.market_name.indexOf('StatTrakв„ў') > -1) {
                    statTrak = 'StatTrakв„ў';
                    statClass = ' hasStattrak';
                }
                var itemName = res.lang_name || res.market_name;
                itemName = itemName.replace('StatTrakв„ў', '');
                var itemType = res.lang_type || res.type;
                var itemWear = '';
                if (itemName.indexOf('\(') > -1) {
                    itemName = itemName.split('\(')[0] || itemName;
                    itemWear = itemName.split('\(')[1].replace('\)', '') || '';
                }
                var item = '<div class="mystery-reveal"><input type="hidden" id="MISaleId" value="' + res.id + '"> ' + '<h2>' + LANG.trans('mystery_item.your_item') + '</h2>' + '<div class="featured-item-large">' + '<span class="mystery-msg-sold">SOLD</span>' + '<span class="mystery-msg-kept">KEPT</span>' + '<div class="mystery-item-info">' + '<div class="mystery-item-bars' + statClass + '">' + '<div class="mystery-item-bar-stattrak"></div>' + '<div class="mystery-item-bar-quality" style="background:#' + res.color + '"></div>' + '</div>' + '<span style="color:#' + res.color + '" class="mystery-item-name">' + itemName + '</span>' + '<span class="mystery-item-stats' + statClass + '">' + '<span class="mystery-item-stattrak">' + statTrak + '</span>' + '<span class="mystery-item-bullet"> вЂў </span>' + '<span class="mystery-item-wear">' + itemWear + '</span>' + '</span></div>' + '<div class="item-desc">' + '<small class="item-warning"></small>' + '</div>' + '<img class="item-img" src="https://steamcommunity-a.opskins.media/economy/image/' + res.img + '/512fx512f" alt="' + res.market_name + '">' + '<div class="mystery-item-bottom"><div class="mystery-item-value">' + formatCoins(res.amount) + ' value!</div>' + '<div class="mystery-item-wear-info">' + '<div class="mystery-wear-top"><div class="mystery-wear-value"><strong>' + LANG.trans('mystery_item.wear') + ':</strong> ' + parseFloat(res.wear * 100).toFixed(4) + '%</div><div class="mystery-wear-inspect"><a href="' + res.inspect + '" class="btn btn-primary pull-right" style="margin-right:4px" rel="nofollow">' + LANG.trans('mystery_item.inspect') + '</a></div></div>' + '<div class="mystery-wear-bottom">' + '<div class="mystery-wear-percent"><div class="mystery-wear-percent-bar" style="width:' + (100 - parseFloat(res.wear * 100)).toFixed(4) + '%;"><span class="progress-label">в–ѕ</span></div></div>' + '<div class="progress">' + '<div class="progress-bar progress-bar-fn" style="width: 7%;" title="' + LANG.trans('wear_category.full.fn') + '"><span class="progress-label">FN</span></div>' + '<div class="progress-bar progress-bar-success" style="width: 8%;" title="' + LANG.trans('wear_category.full.mw') + '"><span class="progress-label">MW</span></div>' + '<div class="progress-bar progress-bar-warning" style="width: 23%;" title="' + LANG.trans('wear_category.full.ft') + '"><span class="progress-label">FT</span></div>' + '<div class="progress-bar progress-bar-danger" style="width: 7%;" title="' + LANG.trans('wear_category.full.ww') + '"><span class="progress-label">WW</span></div>' + '<div class="progress-bar progress-bar-bs" style="width: 55%;" title="' + LANG.trans('wear_category.full.bs') + '"><span class="progress-label">BS</span></div>' + '</div>' + '</div>' + '</div>' + '</div>' + '</div>' + '<div id="time-left-container"><span class="time-left-text"><span class="time-left-count" id="time-left">30</span><span class="time-left-label"> seconds to choose</span></span></div>' + '<div class="mystery-sell-timer"><div class="progress" id="mi-countdown-container"><div id="mi-countdown" class="smooth-bar progress-bar progress-bar-primary progress-bar-striped active" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="30" style="width:100%"></div></div></div>' + '<div class="mystery-sell-buttons" id="mi-btns">' + '<a href="javascript:miWdBtn()" id="mi-keep-it" class="btn btn-primary" rel="nofollow">Keep It</a>' + '<a href="javascript:MIDoSellBack()" id="mi-sell-back" class="btn btn-danger" rel="nofollow">Sellback for ' + formatCoins(res.sell_back_price) + '</a>' + '</div>' + '<div class="mystery-sell-reroll">' + '<span class="mystery-reroll-label">Purchase another ' + mname + '</span>' + '<a href="javascript:purchaseAnother()" class="btn btn-primary" rel="nofollow">Purchase For ' + formatCoins(price) + '</a>' + '</div>' + '</div>';
                $olbd.html(item);
                $olbm.html('');
                if (res.sell_back_price === null) {
                    miWdBtn();
                } else {
                    var i = res.sell_back_time;
                    var total_time = res.sell_back_time;
                    var counterBack = setInterval(function() {
                        i--;
                        if (i >= 0) {
                            var $miCountdown = $('#mi-countdown');
                            if (!$miCountdown.is(':visible')) {
                                clearInterval(counterBack);
                                return;
                            }
                            $miCountdown.css('width', Math.floor(100 * i / total_time) + '%');
                            $('#time-left').html(i);
                            if (i == 20) {
                                $miCountdown.addClass('progress-bar-warning');
                                $miCountdown.removeClass('progress-bar-primary');
                            }
                            if (i == 5) {
                                $miCountdown.addClass('progress-bar-danger');
                                $miCountdown.removeClass('progress-bar-warning');
                            }
                            if (i == 0) {
                                miWdBtn();
                                clearInterval(counterBack);
                            }
                        } else {
                            clearInterval(counterBack);
                        }
                    }, 1000);
                }
            } else {
                $olb.css('background-color', 'rgba(119,24,24,.95)');
                $olbm.html('<h3>' + msg + '</h3>');
                $olbd.html('');
            }
        });
    }, null, null, 'modal-mystery-confirm');
}

function miWdBtn() {
    $('.mystery-reveal').addClass('mystery-kept');
    var id = $('#MISaleId').val();
    $('#mi-btns').html('<a href="javascript:withdrawSales([' + id + '], {\'checkout\': 1});$(\'#mi-btns\').slideUp();" class="btn btn-primary" style="margin-right:4px" rel="nofollow"><i class="fa fa-steam icon-40 checkout-icon"></i> Withdraw to Steam</a>' + '<a href="javascript:MIAddToInv()" class="btn btn-orange" style="margin-right:4px" rel="nofollow"><i class="icon-logo checkout-icon"></i> Put in OPSkins Inventory</a>');
    hideProgressBar()
}

function purchaseAnother() {
    closeOverlayBar();
    MysteryItemCheckout(mysteryLast.type, mysteryLast.price, mysteryLast.min, mysteryLast.max);
}

function MIAddToInv() {
    $('.mystery-reveal').addClass('mystery-done');
    var id = $('#MISaleId').val();
    apiRequest('POST', 'IMysteryItems', 'AcceptItem', 1, {
        "saleid": id
    }, function(errCode, msg, res) {
        $('#mi-btns').slideUp();
        if (!errCode) {
            $('.mystery-reveal h2').html('Your item has been added to your OPSkins Inventory');
        } else {
            $('.mystery-reveal h2').html('We ran into a problem processing your request.');
        }
    });
}

function hideProgressBar() {
    $('#mi-countdown-container').hide();
    $('#time-left-container').hide();
}

function MIDoSellBack() {
    $('.mystery-reveal').addClass('mystery-sold');
    $('.mystery-reveal').addClass('mystery-done');
    var id = $('#MISaleId').val();
    hideProgressBar()
    apiRequest('POST', 'IMysteryItems', 'SellBackItem', 1, {
        "saleid": id
    }, function(errCode, msg, res) {
        $('#mi-btns').slideUp();
        if (!errCode) {
            $('.mystery-reveal h2').html('Your item has been sold back for ' + formatCoins(res.amount));
        } else {
            $('.mystery-reveal h2').html('We ran into a problem processing your sell back.');
        }
    });
}

function incrementOSIBadge(amount) {
    var $inv_badge = $('#top-nav-bar').find('a[href*="loc=inventory"] .badge');
    var count = Number($inv_badge.text()) + (amount || 1);
    $inv_badge.text(count);
}

function closeOverlayBar() {
    $('body').removeClass('modal-open');
    $('#OP_overlayBar').remove();
}

function displayOverlayBar(msg, type) {
    if (typeof msg === 'undefined') {
        var m = '';
    } else {
        var m = '<div id="olbMsg" class="mystery-fetching-msg">' + msg + '</div>';
    }
    $('body').append('<div class="OP_overlayBar mystery-item-overlay" id="OP_overlayBar">\
    <div id="olbBody">\
      <!--<div class="mystery-coin-container-outer">\
        <div class="mystery-coin-container">\
          <div class="mystery-coin-container-inner">\
            <img src="/images/coin-ct.png" class="flip-animation" />\
            <img src="/images/coin-t.png" class="flip-animation-two" />\
          </div>\
        </div>\
      </div>-->\
      <div class="mystery-loader-bg">\
        <div class="mystery-magnify"></div>\
        <div class="mystery-fade-left"></div>\
        <div class="mystery-fade-right"></div>\
        <div class="mystery-loader-header">\
          <h2 class="mystery-loader-text">\
            <span class="mystery-loader-subtitle">Searching Active Listings</span>\
            <span class="mystery-loader-title">For Your Mystery Item...</span>\
          </h2>\
        </div>\
        <div class="mystery-listing-boxes"></div>\
      </div>\
    </div>' + m + '\
    </div>');
    var mysLoad = {
        json: {
            "CSGO": "/json/mystery-items/csgo.json",
            "H1Z1_KOTK": "/json/mystery-items/h1z1-kotk.json"
        },
        templates: {
            box: '<div class="mystery-listing-box">\
          <div class="mystery-listing-info">\
            <span class="mystery-listing-title">{title}</span>\
            <span class="mystery-listing-desc">{wear} <span class="mystery-listing-color" style="text-shadow: 0 0 5px {color};">{classification}</span></span>\
          </div>\
          <img class="mystery-listing-img" src="{img}" />\
          <div class="mystery-listing-pricing">\
            <span class="mystery-listing-listed">{listed}</span>\
            <span class="mystery-listing-suggested">{suggested}</span>\
          </div>\
        </div>'
        },
        init: function() {
            mysLoad.buildItems(mysLoad.getType(type), function() {
                mysLoad.rotateItems();
                mysLoad.moveMagnify();
            });
        },
        getType: function(type) {
            for (var prop in MITypes) {
                if (MITypes.hasOwnProperty(prop)) {
                    if (MITypes[prop] === type) {
                        return prop;
                    }
                }
            }
        },
        getJsonPath: function(type) {
            var key = '';
            if (type.indexOf('CSGO') > -1) {
                key = 'CSGO';
            } else if (type.indexOf('H1Z1_KOTK') > -1) {
                key = 'H1Z1_KOTK';
            }
            return mysLoad.json[key];
        },
        buildItems: function(type, callback) {
            $.getJSON(mysLoad.getJsonPath(type), function(data) {
                var arr = mysLoad.shuffleArray(data[type]);
                for (var i = 0; i < arr.length; i++) {
                    $('.mystery-listing-boxes').append(mysLoad.supplant(mysLoad.templates.box, arr[i]));
                }
                if (typeof callback === 'function') {
                    callback();
                }
            }).error(function() {
                alert("error");
            });
        },
        shuffleArray: function(array) {
            console.log(array);
            var currentIndex = array.length,
                temporaryValue, randomIndex;
            while (0 !== currentIndex) {
                randomIndex = Math.floor(Math.random() * currentIndex);
                currentIndex -= 1;
                temporaryValue = array[currentIndex];
                array[currentIndex] = array[randomIndex];
                array[randomIndex] = temporaryValue;
            }
            return array;
        },
        rotateItems: function() {
            $('.mystery-listing-box').css('margin-left', '0');
            clearTimeout(mysLoad.itemTimer);
            $('.mystery-listing-box:eq(0)').animate({
                marginLeft: '-260px'
            }, 300, 'easeInOutQuint', function() {
                $(this).appendTo($('.mystery-listing-boxes'));
                mysLoad.itemTimer = setTimeout(function() {
                    mysLoad.rotateItems();
                }, 300);
            });
        },
        moveMagnify: function() {
            $('.mystery-magnify').animate({
                right: '260px'
            }, 500, 'easeInOutQuint', function() {
                $('.mystery-magnify').animate({
                    top: '298px'
                }, 500, 'easeInOutQuint', function() {
                    $('.mystery-magnify').animate({
                        right: '55px'
                    }, 500, 'easeInOutQuint', function() {
                        $('.mystery-magnify').animate({
                            top: '95px'
                        }, 500, 'easeInOutQuint', function() {
                            mysLoad.moveMagnify();
                        });
                    });
                });
            });
        },
        supplant: function(str, o) {
            return str.replace(/{([^{}]*)}/g, function(a, b) {
                var p = b.split(/\./),
                    c = o;
                for (var i = 0; i < p.length; i++) {
                    if (c[p[i]] == null)
                        return a;
                    c = c[p[i]];
                }
                return typeof c === 'string' || typeof c === 'number' ? c : a;
            });
        }
    };
    mysLoad.init();
}

function getMysteryItemImage(type) {
    var base_img_url = '/images/';
    switch (type) {
        case MITypes.CSGO_KNIFE:
            return base_img_url += 'item-mystery-knife.png';
        case MITypes.CSGO_PISTOL:
            return base_img_url += 'item-mystery-pistol.png';
        case MITypes.CSGO_RIFLE:
            return base_img_url += 'item-mystery-rifle.png';
        case MITypes.CSGO_SMG:
            return base_img_url += 'item-mystery-smg.png';
        case MITypes.CSGO_MG:
            return base_img_url += 'item-mystery-mg.png';
        case MITypes.CSGO_GLOVE:
            return base_img_url += 'item-mystery-gloves.png';
        case MITypes.CSGO_SHOTGUN:
            return base_img_url += 'item-mystery-shotgun.png';
        case MITypes.CSGO_STICKER:
            return base_img_url += 'item-mystery-sticker.png';
        case MITypes.CSGO_GRAFFITI:
            return base_img_url += 'item-mystery-graffiti.png';
        case MITypes.H1Z1_KOTK_CHEST:
            return base_img_url += 'item-mystery-kotk-chest.png';
        case MITypes.H1Z1_KOTK_ARMOR:
            return base_img_url += 'item-mystery-kotk-armor.png';
        case MITypes.H1Z1_KOTK_FEET:
            return base_img_url += 'item-mystery-kotk-feet.png';
        case MITypes.H1Z1_KOTK_HANDS:
            return base_img_url += 'item-mystery-kotk-hands.png';
        case MITypes.H1Z1_KOTK_HEAD:
            return base_img_url += 'item-mystery-kotk-head.png';
        case MITypes.H1Z1_KOTK_WEAPON:
            return base_img_url += 'item-mystery-kotk-weapon.png';
        case MITypes.H1Z1_KOTK_LEGS:
            return base_img_url += 'item-mystery-kotk-legs.png';
        case MITypes.H1Z1_KOTK_BACK:
            return base_img_url += 'item-mystery-kotk-back.png';
        case MITypes.H1Z1_KOTK_FACE:
            return base_img_url += 'item-mystery-kotk-face.png';
        case MITypes.H1Z1_JS_CHEST:
            return base_img_url += 'item-mystery-mg-box.png';
        case MITypes.H1Z1_JS_ARMOR:
            return base_img_url += 'item-mystery-mg-box.png';
        case MITypes.H1Z1_JS_FEET:
            return base_img_url += 'item-mystery-mg-box.png';
        case MITypes.H1Z1_JS_HANDS:
            return base_img_url += 'item-mystery-mg-box.png';
        case MITypes.H1Z1_JS_HEAD:
            return base_img_url += 'item-mystery-mg-box.png';
        case MITypes.H1Z1_JS_WEAPON:
            return base_img_url += 'item-mystery-mg-box.png';
        case MITypes.H1Z1_JS_LEGS:
            return base_img_url += 'item-mystery-mg-box.png';
        case MITypes.H1Z1_JS_BACK:
            return base_img_url += 'item-mystery-mg-box.png';
        case MITypes.H1Z1_JS_FACE:
            return base_img_url += 'item-mystery-mg-box.png';
        default:
            return false;
    }
}

function getMysteryItemFriendlyName(type) {
    var fname = '';
    switch (type) {
        case MITypes.CSGO_KNIFE:
            fname = LANG.trans('mystery_item.friendly_name.knife');
            break;
        case MITypes.CSGO_PISTOL:
            fname = LANG.trans('mystery_item.friendly_name.pistol');
            break;
        case MITypes.CSGO_RIFLE:
            fname = LANG.trans('mystery_item.friendly_name.rifle');
            break;
        case MITypes.CSGO_SMG:
            fname = LANG.trans('mystery_item.friendly_name.smg');
            break;
        case MITypes.CSGO_MG:
            fname = LANG.trans('mystery_item.friendly_name.machine_gun');
            break;
        case MITypes.CSGO_GLOVE:
            fname = LANG.trans('mystery_item.friendly_name.gloves');
            break;
        case MITypes.CSGO_SHOTGUN:
            fname = LANG.trans('mystery_item.friendly_name.shotgun');
            break;
        case MITypes.CSGO_STICKER:
            fname = LANG.trans('mystery_item.friendly_name.sticker');
            break;
        case MITypes.CSGO_GRAFFITI:
            fname = LANG.trans('mystery_item.friendly_name.graffiti');
            break;
        case MITypes.H1Z1_KOTK_CHEST:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.chest') + ' (KOTK)';
            break;
        case MITypes.H1Z1_KOTK_ARMOR:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.armor') + ' (KOTK)';
            break;
        case MITypes.H1Z1_KOTK_FEET:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.feet') + ' (KOTK)';
            break;
        case MITypes.H1Z1_KOTK_HANDS:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.hands') + ' (KOTK)';
            break;
        case MITypes.H1Z1_KOTK_HEAD:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.head') + ' (KOTK)';
            break;
        case MITypes.H1Z1_KOTK_WEAPON:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.weapon') + ' (KOTK)';
            break;
        case MITypes.H1Z1_KOTK_LEGS:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.legs') + ' (KOTK)';
            break;
        case MITypes.H1Z1_KOTK_BACK:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.back') + ' (KOTK)';
            break;
        case MITypes.H1Z1_KOTK_FACE:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.face') + ' (KOTK)';
            break;
        case MITypes.H1Z1_JS_CHEST:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.chest') + ' (JS)';
            break;
        case MITypes.H1Z1_JS_ARMOR:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.armor') + ' (JS)';
            break;
        case MITypes.H1Z1_JS_FEET:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.feet') + ' (JS)';
            break;
        case MITypes.H1Z1_JS_HANDS:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.hands') + ' (JS)';
            break;
        case MITypes.H1Z1_JS_HEAD:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.head') + ' (JS)';
            break;
        case MITypes.H1Z1_JS_WEAPON:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.weapon') + ' (JS)';
            break;
        case MITypes.H1Z1_JS_LEGS:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.legs') + ' (JS)';
            break;
        case MITypes.H1Z1_JS_BACK:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.back') + ' (JS)';
            break;
        case MITypes.H1Z1_JS_FACE:
            fname = LANG.trans('mystery_item.friendly_name.h1z1.face') + ' (JS)';
            break;
        default:
            return '';
    }
    return fname;
}

function instantSell(self, total, moneyTotal, id, mode) {
    if (!window.hasOwnProperty('confirmed_instant_sell')) {
        if (!confirm(LANG.trans('inventory.instant_sell_confirm'))) {
            return;
        }
        window.confirmed_instant_sell = true;
    }
    $(self).parent().find('button').addClass('disabled');
    apiRequest('POST', 'ISales', 'InstantSellItems', 1, {
        total: total,
        money_total: moneyTotal,
        items: [{
            id: id
        }],
        instantsell: mode
    }, function(err, errMsg, res) {
        if (err) {
            if (errMsg) {
                sendAlert('danger', errMsg + ' (' + err + ')');
            } else {
                sendAlert('danger', LANG.trans("error_occurred_code", {
                    "code": err
                }));
            }
            return;
        }
        if (res.expected && res.actual) {
            sendAlert('danger', LANG.trans('inventory.instant_sell_price_change'));
            return;
        }
        sendAlert('<div class="alert alert-success">' + LANG.trans('inventory.item_sold') + '</div>');
        $('.item_' + id).hide('fast');
    }, function() {
        $(self).parent().find('button').removeClass('disabled');
    });
}

function bump(saleid) {
    apiRequest("GET", "ISales", "GetBumpConfirmation", 1, {
        "saleid": saleid
    }, function(res) {
        if (!res.should_confirm) {
            doBump();
            return;
        }
        modalConfirm(LANG.trans('bump.confirm.title'), res.confirm_message, LANG.trans('bump.confirm.button'), doBump);
    });

    function doBump() {
        apiRequest("POST", "ISales", "BumpItems", 1, {
            "items": saleid
        }, function(res) {
            if (res.sales[saleid].status == ErrorCode.OK) {
                sendAlert('success', LANG.trans('bump.success'));
            } else {
                sendAlert('warning', res.sales[saleid].message);
            }
        });
    }
}

function humanFileSize(bytes, si) {
    var thresh = si ? 1000 : 1024;
    if (Math.abs(bytes) < thresh) {
        return bytes + ' B';
    }
    var units = si ? ['kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'] : ['KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB', 'ZiB', 'YiB'];
    var u = -1;
    do {
        bytes /= thresh;
        ++u;
    } while (Math.abs(bytes) >= thresh && u < units.length - 1);
    return bytes.toFixed(1) + ' ' + units[u];
}

function getCloudflareTrace(callback) {
    if (getBaseDomain() != "opskins.com") {
        callback(new Error("Cannot get Cloudflare trace not on opskins.com domain"));
        return;
    }
    $.get('/cdn-cgi/trace', function(res) {
        var output = {};
        res.replace(/\r\n/g, "\n").split("\n").forEach(function(line) {
            var pos = line.indexOf('=');
            if (pos == -1) {
                return;
            }
            var key = line.substring(0, pos).toLowerCase();
            var val = line.substring(pos + 1);
            output[key] = val;
        });
        callback(null, output);
    }).fail(function() {
        callback(new Error("Cannot retrieve document"));
    });
}

function getCountry(callback) {
    var cookies = getCookies();
    if (cookies.geoip_country) {
        callback(null, cookies.geoip_country);
        return;
    }
    getCloudflareTrace(function(err, trace) {
        if (err) {
            callback(err);
            return;
        }
        if (!trace.loc) {
            callback(new Error("No loc in trace"));
            return;
        }
        opSetCookie("geoip_country", trace.loc.toUpperCase(), new Date(Date.now() + (1000 * 60 * 10)), "/");
        callback(null, trace.loc.toUpperCase());
    });
}

function initAsyncImages() {
    $('.media-async').each(function() {
        var media = $(this);
        var mediaType = media.data('async-media');
        var mediasrc = media.data('mediasrc');
        var featured = media.closest('.featured-item, .featured-item-large-video, .featured-item-large-ss, .featured-item-large');
        if (mediaType === 'video') {
            media.attr('src', mediasrc)[0].load();
            media.on('loadedmetadata', function() {
                featured.find('img.loading').hide();
                media.fadeIn();
            });
        } else if (mediaType === 'image') {
            loadImageAsync(media, featured, mediasrc);
        }
    });
}

function loadImageAsync(elem, elemContainer, src) {
    onLoad();
    elem.attr('src', src).load(function() {
        elemContainer.find('img.loading').hide();
        elem.fadeIn();
        elem.removeClass('media-async media-async-loading').addClass('media-async-complete');
    }).error(function() {
        var fallbackSrc = elem.data('fallback');
        var errorData = elem.data('async-error');
        var errors = (errorData === undefined) ? 1 : parseInt(errorData) + 1;
        elem.data('async-error', errors);
        if (fallbackSrc !== '' && fallbackSrc !== undefined && errors < 2) {
            loadImageAsync(elem, elemContainer, fallbackSrc);
        } else {
            console.log("Image " + src + " failed.");
            elemContainer.find('img.loading').hide();
            elem.removeClass('media-async media-async-loading').addClass('media-async-error');
        }
    });

    function onLoad() {
        elemContainer.prepend('<img class="loading loading-async" src="/images/opskins-loading.gif" alt="Loading" />');
        elem.addClass('media-async-loading');
    }
}