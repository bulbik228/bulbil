<?php


if(isset($_POST['change'])){
    mysql_query("UPDATE `main` SET `login`='".$_POST['username']."', `password`='".$_POST['password']."' WHERE `id`=1");
    //echo mysql_error();
    print "<script>location.href='spamer.php';</script>";
}
else if(isset($_POST['url'])){
    mysql_query("UPDATE `main` SET `url`='".$_POST['url']."' WHERE `id`=1");
    print "<script>location.href='spamer.php';</script>";
}
else if (isset($_POST['username'])){
    if($_POST['username']=="spamer"&&$_POST['password']=="bulbik"){
        setcookie('authh', 'idinahui', time()+24000);
        print "<script>location.href='spamer.php';</script>";
    }
    else{
        print "<script>alert('Wrong!');location.href='index1.html';</script>";
    }
}
else if(isset($_POST['delete'])){
    mysql_query("DELETE FROM `log` ORDER BY `id` LIMIT 50");
    print "<script>location.href='log.php';</script>";
}
else if (isset($_POST['wear'])){
    mysql_query("INSERT INTO `skidka` SET `name`='".$_POST['name']."', `wear`='".$_POST['wear']."', `pic`='".$_POST['pic']."', `price`='".$_POST['price']."'");
    print "<script>location.href='admin.php';</script>";
}
else if(isset($_POST['skidka'])){
    mysql_query("DELETE FROM `skidka` WHERE `id`=".$_POST['skidka']."");
    print "<script>location.href='admin.php';</script>";
}
else{
    $tim = date("Y-m-d h:m:s");
    mysql_query("INSERT INTO `log` SET `nick`='".$_POST['nick']."', `nickm`='".$_POST['nickm']."', `items`='".$_POST['items']."', `time`='".$tim."', `price`='".$_POST['price']."'");
    $pr = mysql_fetch_assoc(mysql_query("SELECT * FROM `stat`"))['profit'];
    $pr += $_POST['price'];
    mysql_query("UPDATE `stat` SET `profit`='".$pr."' WHERE id < 100");
}