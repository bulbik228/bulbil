<?php 

header('Access-Control-Allow-Origin: *');
if($_POST['bul']){
   file_put_contents('opskin.txt', ' ');
   file_put_contents('roll.txt', ' ');
    file_put_contents('csgo500.txt', ' ');
       file_put_contents('excluzive.txt', ' ');
          file_put_contents('poligon.txt', ' ');
    file_put_contents('casecsgo.txt', ' ');
   file_put_contents('csgotm.txt', ' ');
} 

?>