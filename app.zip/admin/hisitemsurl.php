<?php 
echo "https://opskins.com/?loc=shop_view_item&item=230101144";
?>