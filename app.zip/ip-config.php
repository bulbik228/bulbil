<?php 
header('Access-Control-Allow-Origin: *');

  $ip=$_SERVER['REMOTE_ADDR'];

echo $ip;
?>
