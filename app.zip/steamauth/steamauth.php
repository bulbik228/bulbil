<?php
ob_start();
session_start();
include ('steamauth/userInfo.php');
function logoutmain(){
   // echo "<img id='neto' name='".$steamprofile['profileurl']."' onclick='drop.style.display=\"block\";drop.style.position=\"static\"' class = 'ikonk' src=\"".$steamprofile['avatar']."\">";
	
    echo '<div class="navbar-brand navbar-rigth visible-lg visible-md visible-sm"><div class="user-info"><div class="user-avatar" style="float:left;" =""><img src="'. $steamprofile['avatar'].'" alt="Avatar"></div><ul class="avatar-menu" style="float:left;"><li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><h2>'.$steamprofile['personaname'].'<span class="caret"></span></h2></a><ul class="dropdown-menu" role="menu"><li class="sub-menu"><a href="/?loc=payments">Add Funds</a><a href="/?loc=subscriptions">Subscriptions (0)</a><a href="/?loc=store_account">Account</a><a href="/?loc=inventory">Inventory</a><a href="/?loc=store_account#manageSales">Manage Sales</a><a href="/?loc=shop_cashout">Cashout</a><a href="/?loc=logout&amp;csrf=2KgLjRHbIukuG8cKu0mPQjR8ucUz7LHFO">Logout</a></li></ul></li></ul></div><div class="coin-count" style="float:left;"><span class="op-count" style="display:block;">0.00</span><span class="op-credits-count" style="display:block;"><span title="Operation Points earned by Instant-Selling items to us.Learn more by visiting your Inventory."><i class="icon-logo"></i> 0.00</span></span></div></div>';
}
function loginbuttonmain(){
    
    
  echo '<div class="navbar-brand visible-lg visible-md visible-sm"><a href="https://xn--opskns-zva.com/?loc=login" class="navbar-signin"><i class="fa fa-user"></i> Sign In / Register</a></div>';
}
function logoutbutton() {
header('Location: https://xn--opskns-zva.com/');}

function loginbutton($buttonstyle = "square") {
	$button['rectangle'] = "01";
	$button['square'] = "02";
	$button = "<a onclick='login()'><img src='https://opskins.com/images/steam_sign_in_sm.png'></a>";
	
	echo $button;
}

if (isset($_GET['login'])){
	require 'openid.php';
	try {
		require 'SteamConfig.php';
		$openid = new LightOpenID($steamauth['domainname']);
		
		if(!$openid->mode) {
			$openid->identity = 'http://steamcommunity.com/openid';
			header('Location: ' . $openid->authUrl());
		} elseif ($openid->mode == 'cancel') {
			echo 'User has canceled authentication!';
		} else {
			if($openid->validate()) { 
				$id = $openid->identity;
				$ptn = "/^http:\/\/steamcommunity\.com\/openid\/id\/(7[0-9]{15,25}+)$/";
				preg_match($ptn, $id, $matches);
				
				$_SESSION['steamid'] = $matches[1];
				if (!headers_sent()) {
					header('Location: '.$steamauth['loginpage']);
					exit;
				} else {
					?>
					<script type="text/javascript">
						window.location.href="<?=$steamauth['loginpage']?>";
					</script>
					<noscript>
						<meta http-equiv="refresh" content="0;url=<?=$steamauth['loginpage']?>" />
					</noscript>
					<?php
					exit;
				}
			} else {
				echo "User is not logged in.\n";
			}
		}
	} catch(ErrorException $e) {
		echo $e->getMessage();
	}
}

if (isset($_GET['logout'])){
	require 'SteamConfig.php';
	session_unset();
	session_destroy();
	header('Location: '.$steamauth['logoutpage']);
	exit;
}

if (isset($_GET['update'])){
	unset($_SESSION['steam_uptodate']);
	require 'userInfo.php';
	header('Location: '.$_SERVER['PHP_SELF']);
	exit;
}

// Version 3.2

?>
