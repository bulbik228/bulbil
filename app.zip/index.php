<?php 
if (isset($_GET['loc'])){
    if($_GET['loc']=='login'){
	require 'login.php';
	exit();
    }
    if($_GET['loc']=='featured'){
	require 'featured.php';
	exit();
    }
    if($_GET['loc']=='game'){
	require 'game.php';
	exit();
    }
     if($_GET['loc']=='shop_browse'){
	require 'shop_browse.php';
	exit();
    }
}

	require 'main.php';

?>
